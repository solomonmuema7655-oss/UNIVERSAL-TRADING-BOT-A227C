# A227C Research & Integration Blueprint

Version: 1.1 | Product: UNIVERSAL-TRADING-BOT-A227C | Owner: SIYOMA / SiyomaCodingPrograms

## 1. Product contract (non-negotiable)

A227C is a signal-only market-analysis product. It does not place, modify, close, or manage broker orders; it does not log into broker trading permissions; and it does not control a broker account. The live decision engine is deterministic and rule-based. No AI agent, LLM, machine-learning prediction, or AI-generated confidence is used for live decisions. BUY, SELL, and WAIT are valid outputs, with WAIT mandatory whenever evidence or data quality is insufficient.

Initial MT5/Exness market universe: XAUUSD, USTECH100, GBPJPY, GBPUSD, USDJPY. Provider symbol names are configuration, not assumptions. Deriv is a separate provider namespace; a synthetic symbol is never silently equated with a broker CFD, cash index, or FX instrument.

## 2. Deployment topology

- **Windows VPS/dedicated Windows host:** installed and logged-in MT5 terminal, MetaTrader5 Python package, MT5 adapter, analysis engine, journal, and FastAPI service.
- **Deriv public market-data adapter:** independent WebSocket client and provider-specific symbol namespace.
- **Fundamental-data adapter:** Trading Economics calendar and macro observations, using server-side credentials.
- **Secure edge/reverse proxy:** terminates TLS and exposes HTTPS/WSS to the mobile client; restricts inbound access to the backend.
- **Android client:** dashboard, live state, charts, signal evidence, history, journal and research controls. Android is not the continuous market-data host.

The MT5 Python package communicates with an installed terminal using inter-process communication. This is why the MT5 connector belongs on a supported Windows MT5 host. The Android APK alone cannot provide the MT5 terminal or the backend service.

## 3. Provider integration contracts

### MT5 / Exness

Use the official MetaTrader5 Python module against an installed MT5 terminal. Required operations include terminal initialization, symbol selection, tick retrieval, and closed OHLC bar retrieval for M15/M30/H1/H4. Verify each broker symbol in Market Watch and record the actual provider symbol, point size, digits, swap values and timestamps. A configured symbol is not considered connected merely because `symbol_select` returned true; the feed must produce fresh valid quotes and sufficient closed-bar history.

No trading methods (`order_send`, order modification, close-position methods) are called by A227C.

### Deriv

Use the current public market-data WebSocket endpoint:

`wss://api.derivws.com/trading/v1/options/ws/public`

The public endpoint requires no account authentication for public market data. Discover symbols with `active_symbols: "brief"`, then subscribe using `ticks` and `subscribe: 1`. Public market data can also be requested with `ticks_history`. The adapter validates quote and epoch fields and preserves provider symbol identity. This endpoint is not an account-trading connection. No `buy`, `sell`, `proposal`, or account-scoped operation is implemented.

Deriv data remains separate from the five MT5 market feeds. If a future Deriv strategy pipeline is added, it must have its own candle construction, history integrity, market identity, strategy validation and acceptance tests. Tick display alone is not strategy integration.

### Trading Economics

The provider supports REST economic-calendar retrieval and authenticated streaming for calendar/market data. Current implementation uses server-side REST polling for upcoming calendar events and macro observations. Configure credentials only on the backend (environment variable preferred). Verify provider plan entitlement, exact country/indicator identifiers, observation dates, update times, currency mapping, and event importance values. Missing or stale news/macro context must remain unavailable and block dependent decisions; never fill it with guessed values.

## 4. Event-driven data lifecycle

1. Receive a provider tick or completed OHLC bar.
2. Preserve provider, provider symbol, source timestamp and local receive timestamp.
3. Validate finite positive prices, bid/ask ordering, spread, timestamp ordering and freshness.
4. Detect duplicate, out-of-order and missing updates; reconnect and backfill where supported.
5. Keep provider-specific time series isolated.
6. Build/update candles while marking the forming candle separately from completed candles.
7. Evaluate indicators and market structure only on the appropriate completed bars.
8. Evaluate market-assigned strategy modules.
9. Apply macro/news, correlation, spread, volatility and data-quality gates.
10. Apply the H4 → H1 → M30 → M15 protocol; M15 is the final entry gate.
11. Publish explainable BUY/SELL/WAIT state, evidence, source timestamps, invalidation and reference SL/TP.
12. Persist immutable signal snapshots and monitor invalidation transitions.

A provider being connected is not sufficient: each instrument must independently pass symbol mapping, tick freshness, history depth, closed-candle integrity and spread checks.

## 5. Strategy modules and current assignment

- **Trend pullback to support/resistance:** USDJPY. H4/H1 directional context, confirmed structure/levels, pullback and completed M15 rejection/continuation gate.
- **London/New York session breakout:** GBPUSD and XAUUSD. Timestamped Asian/Tokyo range, qualifying close outside range, range/body expansion, retest, spread/volatility and news checks.
- **Liquidity / SMC:** XAUUSD. Objective swing/equal-high/equal-low liquidity candidates, sweep/reclaim, displacement, break-of-structure and objective retest/zone candidate. This is a mechanical proxy, not a claim to observe institutional orders.
- **Carry context:** USDJPY. Verified policy-rate differential, government-yield differential and broker-specific swap context. Macro context only; never an M15 entry trigger.

GBPJPY and USTECH100 remain in the five-market monitor but have no primary strategy assignment until market-specific rules are researched and validated. Do not invent assignments or copy performance from another instrument. EURUSD and AUDJPY are not added to the initial universe.

## 6. Analytical and decision layers

The existing implementation includes regime classification, HH/HL/LH/LL structure and BOS, EMA trend context, RSI/MACD/ROC momentum, ATR/volatility, support/resistance, liquidity sweep/reclaim, session logic, news risk, correlation context, spread/data-quality filters and reference risk levels. Indicators are evidence inputs, not autonomous signal generators. The explanation must show why BUY, SELL or WAIT was selected.

The evidence score is not a probability of winning. A confirmed signal requires a defined invalidation/protective reference. SL/TP are analytical references only and do not create or manage a broker order.

## 7. Research and validation

The current OHLC walk-forward harness supports selected implemented combinations and splits chronologically into in-sample and out-of-sample segments. It requires a positive full-spread assumption and resolves same-bar stop/target ambiguity conservatively (stop first). It currently does not fully model variable historical spread, commissions, slippage, financing/swap, market impact or all broker execution constraints. Its outputs are research observations, not profitability proof.

Before any strategy is called validated: collect adequate instrument-specific data; freeze rule definitions; prevent look-ahead and survivorship leakage; use point-in-time event data; include realistic costs; evaluate chronological out-of-sample and rolling walk-forward periods; report sample size, expectancy, profit factor, drawdown, MAE/MFE, regime/session splits and uncertainty; compare against sensible baselines; and conduct live shadow observation without executing trades. No win-rate or profitability claim is allowed without reproducible evidence.

## 8. Android and connection lifecycle

The mobile app connects to the deployed backend using `wss://.../ws` and the backend API token. The backend owns continuous scanning and reconnect/backfill. The app displays actual provider/instrument status and last-update age; it must not show fabricated prices or imply a feed is live when disconnected. If the phone disconnects, the backend continues scanning; the app requests a fresh snapshot on reconnect. Android background execution limits mean the phone must not be relied upon as the always-on market engine.

## 9. Secrets and transport security

- Never put MT5 passwords, Trading Economics credentials, or the backend API token in the APK or public repository.
- Use a long unique backend token, environment/secret storage, TLS/WSS reverse proxy, restricted firewall, least-privilege host account and log redaction.
- Do not expose the plain backend port directly to the public internet.
- Do not disable Android Play Protect or bypass warnings. A successful build is not a malware/security certification.
- The sample API token is deliberately unusable and must be replaced at deployment.

## 10. Operational acceptance gates

A227C is not declared live-operational until all applicable checks pass:

1. Windows host, MT5 terminal and MT5 Python package are installed and stable.
2. All five MT5 provider symbols are verified against the actual account/feed.
3. Fresh ticks and sufficient closed bars are received for every assigned market/timeframe.
4. Deriv public endpoint connects, discovers configured symbols and delivers valid timestamps/quotes.
5. News/calendar and macro provider credentials/entitlements and indicator mappings are verified.
6. H4/H1/M30/M15 candle integrity and M15 gate tests pass.
7. All four strategy modules have deterministic unit tests and instrument-specific research.
8. Android WSS authentication, reconnect, snapshot, chart/history and signal updates pass on a physical device.
9. Unauthorized access is rejected; secrets are absent from APK/repository; TLS is verified.
10. Release APK signing, distribution and Play Protect status are separately verified.

A CI build passing does not satisfy any external-provider deployment gate by itself.

## 11. Current build boundary

This source package contains the Android client and a deployable backend source tree. This revision corrects the Deriv public endpoint/request contract and adds adapter validation tests. It does not provision a Windows VPS, create provider credentials, install/log into MT5, register a Deriv app for account features, configure Trading Economics subscription access, deploy TLS, or prove market profitability. Those steps require the operator's hosting/provider access and must be tested on the actual deployment.


## 12. Deployment automation and newly verified engineering constraints

Revision 1.2 adds a Windows installation script, DPAPI-protected local credentials, a user-session backend launcher, an optional logon/restart scheduled task, and a Caddy TLS reverse-proxy template. This reduces manual setup but does not provision a host, domain, DNS, provider subscription, or MT5 account. The MT5 Python bridge requires an installed and available terminal; official MetaQuotes documentation describes `initialize()` connecting to that terminal and `copy_rates_range()` retrieving terminal history. See the official [initialize reference](https://www.mql5.com/en/docs/python_metatrader5/mt5initialize_py) and [copy_rates_range reference](https://www.mql5.com/en/docs/python_metatrader5/mt5copyratesrange_py).

Trading Economics REST API access uses a provider API key and a subscribed plan. Its official docs describe API key authentication and the country/indicator and calendar endpoints. The backend now queries the provider indicator catalog for each configured country and requires exact category-name matches before fetching the latest observations. Exact indicator names, entitlement and observation freshness must still be verified against the actual key; the example names `Interest Rate` and `Government Bond 10Y` are configurable candidate mappings, not a claim that a specific account has access. Requests are paced to remain within the provider documented general 5-requests-per-second limit. The API key is stored server-side with Windows DPAPI by the deployment installer. Calendar streaming is available separately with client credentials; this revision uses REST polling and does not claim to have implemented streaming. See [Trading Economics authentication](https://docs.tradingeconomics.com/get_started/), [calendar streaming](https://docs.tradingeconomics.com/economic_calendar/streaming/) and [historical market data](https://docs.tradingeconomics.com/markets/historical/).

MT5 swap values are not universally denominated in account cash. The official symbol specification exposes `swap_mode` and defines points, symbol currency, margin currency, deposit currency, interest and reopen modes. The carry evaluator therefore accepts a positive swap only when MT5 identifies `CURRENCY_DEPOSIT`; other units fail closed. See [MQL5 symbol information](https://www.mql5.com/en/docs/python_metatrader5/mt5symbolinfo_py) and [swap calculation modes](https://www.mql5.com/en/book/automation/symbols/symbols_swaps).

Deriv public market-data APIs document active-symbol discovery and historical tick retrieval. A configured Deriv feed remains a separate data universe and is not substituted for MT5/Exness quotes. See [active symbols](https://developers.deriv.com/docs/data/active-symbols/) and [ticks history](https://developers.deriv.com/docs/data/ticks-history/).

Android requires secure TLS transport for remote credentials and backend communication. The client must use a trusted WSS endpoint; the backend listens only on loopback behind Caddy. See [Android network security configuration](https://developer.android.com/privacy-and-security/security-config).

### What is still not experimentally established

- No actual Trading Economics key was supplied, so live API entitlement, exact indicator mappings, quota/rate limits and the four live macro observations have not been exercised.
- No Windows VPS, domain or DNS zone was supplied, so no production host was provisioned and no trusted TLS certificate/WSS endpoint was deployed.
- No MT5 terminal/account was available in this build environment. The five broker symbol mappings and quote freshness remain unverified.
- No provider historical export from the user's Exness MT5 terminal was available. The local backtest tests use deterministic synthetic fixtures only for software correctness; they are not market research results.
- The OHLC backtest currently covers the implemented trend-pullback, session-breakout and liquidity/SMC rules for their documented market/timeframe assignments. Carry is macro context, not an independent OHLC entry strategy; a valid carry historical study additionally requires point-in-time policy/yield observations and historical broker swap data with its calculation mode.
- No physical Android device was available to this build process. Android WSS handshake, certificate trust, reconnect and end-to-end live display still require a real deployed endpoint and device test.

These are explicit acceptance gates, not permission to invent results or generate signals without data.

## 13. Real-history acquisition and carry point-in-time research (Revision 1.3)

The backend now includes `a227c.research.mt5_history_export`, a read-only Windows/MT5 history exporter. It exports completed M15/M30/H1/H4 bars for the exact configured provider symbols, validates UTC timestamps, monotonicity, duplicate timestamps, finite positive OHLC and candle geometry, and writes a manifest recording provider symbol identity and coverage. Example from `backend/`:

```powershell
python -m a227c.research.mt5_history_export --symbols '{"XAUUSD":"XAUUSD","USTECH100":"USTEC","GBPJPY":"GBPJPY","GBPUSD":"GBPUSD","USDJPY":"USDJPY"}' --bars 20000 --output research_data/mt5
```

The exact broker symbols must be checked in MT5 Market Watch first; the example `USTEC` is not guaranteed to match every Exness server/account. The exporter intentionally fails rather than fabricate history if MT5 is unavailable or the provider returns invalid bars.

A separate `a227c.research.carry_study` performs backward as-of joins using each macro observation's `available_at` timestamp and each broker swap record's `available_at` timestamp. It never uses a macro observation before it was available. A valid carry study requires point-in-time policy rates, yields, and historical broker swap values including swap calculation mode. Current/latest values must not be backfilled across past dates. This study reports context states only; it does not create independent trade entries or claim carry profitability.

Run backend tests with `python -m pytest -q`. Exported data and its manifest should be archived immutably with broker/server identity, extraction timestamp, timezone, timeframe, and symbol contract details. Before strategy evaluation, freeze strategy rules, reserve a chronological untouched holdout, apply an embargo at least as long as the maximum holding horizon between train/test segments, and include variable historical spread, commissions, slippage and swap where source data permits. If these cost inputs are unavailable, label the result incomplete and do not call it validated.

## 14. Research evaluation hardening (Revision 1.4)

The research harness now reports disjoint chronological OOS folds rather than only one 60/40 split. Full prior history is retained as indicator/context warm-up for every fold, while signal generation is restricted to that fold's test interval and open positions are closed at the fold boundary. MAE/MFE and holding duration are recorded per trade and aggregated. The fixed-rule runner does not tune parameters; it reports the initial in-sample baseline separately from the combined OOS folds.

Run the reproducible matrix from `backend/` after exporting the real MT5 history and preparing a broker-calibrated cost file:

```powershell
python -m a227c.research.run_research --data research_data/mt5 --costs research_data/costs.json --output research_data/a227c_research_report.json --folds 4
```

The cost file is keyed by e.g. `USDJPY_H1` and must provide `spread_price_units` greater than zero; optional `commission_round_turn_price_units` and `slippage_round_turn_price_units` are explicit round-turn deductions in price units. They must be calibrated using the actual broker symbol contract, account currency, volume convention and commission schedule. The current OHLC harness still does not model time-varying bid/ask spread, quote-level execution, market impact, financing/swap accrual or intrabar path beyond the conservative stop-first same-bar rule. A fixed spread plus optional cost deductions is a sensitivity model, not a complete execution simulator.

The runner covers only the implemented fixed-rule assignments: USDJPY trend pullback on H1/H4, XAUUSD liquidity/SMC on M15, and GBPUSD/XAUUSD session breakout on M15/M30. Carry remains a point-in-time macro/swap context study for USDJPY, not an OHLC entry strategy. GBPJPY and USTECH100 are deliberately excluded from strategy-performance claims until independently researched and assigned. Missing datasets or missing costs are explicit BLOCKED statuses; no synthetic fallback is permitted.

For robust claims, a further research protocol is required beyond these chronological folds: freeze all rules before inspecting the final holdout; reserve a later untouched period; account for the maximum trade holding horizon at boundaries; log every strategy/rule variant tried to control multiple-testing selection bias; compare against simple baselines; report confidence intervals and regime/session breakdowns; and validate a live shadow stream. Bailey et al. show why repeated strategy selection inflates backtest results and motivate Probability of Backtest Overfitting / Deflated Sharpe Ratio diagnostics. These statistical checks are not yet implemented in this revision and should not be implied by the current OOS fold report.

## Revision 1.5 — Exness quote archive and point-in-time macro acquisition

### Exness bid/ask tick archive

Exness publishes historical tick downloads as ZIP files containing CSV columns `Exness,Symbol,Timestamp,Bid,Ask`. The operator downloads the required instrument/date archives from the Exness Tick History page. A227C does not automate the website download or bypass its UI. The importer `a227c.research.exness_tick_history` validates timestamps, positive/non-crossed bid/ask quotes, removes duplicate timestamps deterministically, records the original archive SHA-256, reports spread distribution, and creates separate BID/ASK OHLC bars for M15/M30/H1/H4. These are indicative historical quotes, not actual individual execution records; Exness notes that tick histories from servers may differ slightly.

Command:

```powershell
python -m a227c.research.exness_tick_history --archive "C:\\A227C\\incoming\\XAUUSD.zip" --symbol XAUUSD --output research_data/exness_ticks
```

The research runner prefers paired `SYMBOL_TIMEFRAME_BID.csv` and `SYMBOL_TIMEFRAME_ASK.csv` files when present. In that mode BUY entries use ask and BUY exits use bid; SELL entries use bid and SELL exits use ask. OHLC intrabar sequencing remains unknowable, so same-bar stop/target collisions resolve stop-first. This is a quote-side OHLC model, not a tick-by-tick execution simulator.

### ALFRED vintage acquisition

`a227c.research.fred_alfred_vintages` can retrieve configured FRED series with output type 2 (observations by vintage date). The user must supply a registered `FRED_API_KEY` and a reviewed series mapping file. Since a vintage date alone does not establish intraday release time, the importer conservatively sets `available_at` to 00:00 UTC on the following day. This avoids same-day look-ahead but may be later than actual release availability. Series mappings must be reviewed for country, unit, frequency and economic meaning; do not assume a U.S. series represents Japan.

Example config:

```json
{
  "series": [
    {"series_id": "DFF", "role": "US_POLICY_RATE", "observation_start": "2000-01-01"}
  ]
}
```

Command:

```powershell
$env:FRED_API_KEY="YOUR_REGISTERED_KEY"
python -m a227c.research.fred_alfred_vintages --config config/fred_series.json --output research_data/macro_alfred
```

FRED/ALFRED is a source for U.S. and other covered series, not a complete direct Bank of Japan release archive. For Japanese policy decisions, use reviewed Bank of Japan source data with actual publication timestamps; for 10-year yields, record the actual source, quote date and publication/availability time. Treasury daily yield curves are available as official historical CSVs for U.S. yields, but the observation date is not automatically an intraday availability timestamp.

### Carry data freshness

The carry study now blocks stale macro observations older than 120 days and broker swap observations older than 7 days by default. These are conservative operational defaults, not economic laws; changes require a documented research decision. Broker swap mode, long/short values, triple-swap day, contract size and account currency still need provider-specific verification. Carry remains context only, never a standalone M15 trigger.

### Research holdout and statistics

The chronological evaluation now separates development out-of-sample folds from a final 15% holdout segment. The holdout is not included in development-fold aggregate metrics. Once it has been inspected and used to make a strategy change, it is no longer an untouched holdout; a later unseen period is required. Per-trade expectancy has a deterministic bootstrap interval for descriptive uncertainty only; it does not correct for multiple testing or strategy selection.

### Explicit cost-evidence requirement

The research runner requires an explicit round-turn commission and slippage value for every evaluated symbol/timeframe, plus a non-empty evidence-basis note for each. Zero is allowed only when the chosen account type's schedule or documented observation supports zero. A fixed spread assumption is required when paired Exness bid/ask quote bars are unavailable. The runner does not silently treat unknown commissions or slippage as zero.

The MT5 historical exporter now records a current symbol-contract metadata snapshot (contract size, tick size/value, profit/base/margin currencies, current swap long/short, swap mode, triple-swap day and related symbol constraints). The manifest labels it `CURRENT_SNAPSHOT_ONLY_NOT_HISTORICAL`; it must not be backfilled into earlier years as though contract terms never changed.

### Explicit cost-evidence requirement

The research runner requires an explicit round-turn commission and slippage value for every evaluated symbol/timeframe, plus a non-empty evidence-basis note for each. Zero is allowed only when the chosen account type's schedule or documented observation supports zero. A fixed spread assumption is required when paired Exness bid/ask quote bars are unavailable. The runner does not silently treat unknown commissions or slippage as zero.

The MT5 historical exporter now records a timestamped current broker symbol-contract metadata snapshot (contract size, tick size/value, profit/base/margin currencies, current swap long/short, swap mode, triple-swap day and related symbol constraints). The manifest labels it `CURRENT_SNAPSHOT_ONLY_NOT_HISTORICAL`; it must not be backfilled into earlier years as though contract terms never changed.

## Revision 1.6 — Exness archive integrity and batch acquisition hardening

The Exness importer now requires the provider `Symbol` field and exactly one provider symbol per archive. An optional explicit `provider_symbol` assertion prevents silently mapping a provider instrument to the wrong internal market. It rejects malformed rows instead of dropping them, requires timezone-qualified timestamps before UTC normalization, retains distinct quote updates that share a millisecond timestamp, and removes only exact duplicate records. Spread OHLC is now computed from each tick's actual `ask - bid` series rather than subtracting independently timed bid/ask extrema.

For a multi-instrument import, prepare `config_exness_archives.example.json` as `config_exness_archives.json`, put the downloaded ZIPs in the referenced incoming folder, verify every provider symbol against the selected Exness instrument, then run from `backend/`:

```powershell
python -m a227c.research.exness_tick_history --batch-config ..\config_exness_archives.json --output research_data/exness_ticks
```

The importer creates one subfolder per internal market and an `EXNESS_BATCH_MANIFEST.json` containing source archive hashes and resolved provider symbols. The example provider symbol `USTEC` is illustrative only and must be replaced with the exact symbol present in the actual Exness archive. Do not assume that USTECH100 maps to USTEC across accounts or product types.

The Exness download itself remains a provider-operated archive selection/download step. Exness documents instrument/date selection and ZIP download through its Tick History interface; no stable public bulk-download API is documented in the reviewed official materials. The application does not scrape private endpoints or bypass access controls. Exness tick history is indicative quote history and can differ by server; it is not an execution ledger. The exact account-type/server feed must be considered when interpreting results.

### Revised research integrity controls

- A malformed row blocks the archive rather than silently shrinking the dataset.
- Timestamps without an explicit timezone are rejected; valid timestamps are normalized to UTC.
- Same-timestamp but different bid/ask updates are retained; exact duplicates are counted and removed.
- Tick-level spread is resampled directly from `ask - bid` observations.
- Provider symbol identity is recorded and can be asserted against the expected symbol.
- The batch manifest preserves source archive and config hashes.

These controls strengthen acquisition reproducibility; they do not establish that a downloaded archive has complete date coverage, matches a particular account server, or captures individual fills. Coverage and server/account comparability still require independent assessment.
