import numpy as np
import pandas as pd
from a227c.core.indicators import rsi
from a227c.core.decision import analyze
from a227c.core.strategies import session_breakout, evaluate_strategies

def frames_fixture():
    now=pd.Timestamp.now(tz='UTC'); out={}
    for tf,mins in [('M15',15),('M30',30),('H1',60),('H4',240)]:
        idx=pd.date_range(end=now-pd.Timedelta(minutes=mins),periods=260,freq=f'{mins}min')
        close=np.linspace(100,110,len(idx))+np.sin(np.arange(len(idx))/4)*.1
        out[tf]=pd.DataFrame({'open':close-.03,'high':close+.1,'low':close-.1,'close':close,'tick_volume':100},index=idx)
    return out,now

def test_rsi_handles_zero_losses():
    s=pd.Series(np.arange(1,80,dtype=float))
    assert rsi(s).iloc[-1] == 100.0

def test_breakout_fails_closed_without_asian_range():
    f,_=frames_fixture()
    from a227c.core.indicators import enrich
    result=session_breakout(enrich(f['M15']),active_session='LONDON')
    assert result['direction']=='WAIT'
    assert 'Asian range' in result['reason']

def test_unassigned_market_does_not_get_fabricated_strategy():
    f,_=frames_fixture()
    from a227c.core.indicators import enrich
    enriched={k:enrich(v) for k,v in f.items()}
    result=evaluate_strategies('GBPJPY',enriched)
    assert result[0]['direction']=='WAIT'
    assert result[0]['name']=='UNASSIGNED'

def test_missing_news_context_blocks_confirmed_signal():
    f,now=frames_fixture()
    tick={'time':now.isoformat(),'bid':109.999,'ask':110.001}
    result=analyze('USDJPY',f,tick=tick,source='TEST',news_risk='UNKNOWN',threshold=75,min_bars=205)
    assert result['direction']=='WAIT'
    assert any('news gate' in x.lower() for x in result['reasons'])

def test_signal_journal_and_research_metrics(tmp_path, monkeypatch):
    from a227c import storage
    monkeypatch.setattr(storage, 'DB', tmp_path/'journal.sqlite3')
    signal={'symbol':'XAUUSD','bar_timestamp':'2026-11-21T00:00:00+00:00','timestamp':'2026-11-21T00:15:00+00:00',
            'direction':'BUY','score':82,'quality':'HIGH','source':'TEST','data_health':'VALIDATED'}
    signal_id=storage.save_signal(signal)
    assert signal_id is not None
    storage.record_outcome(signal_id,'WIN',1.5,'manual test result')
    report=storage.research()
    assert report['by_market']['XAUUSD']['wins']==1
    assert report['by_market']['XAUUSD']['expectancy_r']==1.5

def test_backtest_requires_cost_assumption_and_uses_chronological_split():
    from a227c.research.backtest import walk_forward
    idx=pd.date_range('2026-01-01',periods=700,freq='h',tz='UTC')
    close=np.linspace(100,105,700)+np.sin(np.arange(700)/5)*.15
    df=pd.DataFrame({'open':close-.02,'high':close+.12,'low':close-.12,'close':close,'tick_volume':100},index=idx)
    import pytest
    with pytest.raises(ValueError): walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0)
    report=walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0.01)
    assert report['in_sample'] is not None and report['out_of_sample'] is not None
    assert 'not a forecast' not in report['validation_note'].lower()

def test_carry_context_requires_rate_yield_and_positive_swap():
    from a227c.core.strategies import carry_context
    incomplete={'rate_differential_available':True,'base_minus_quote_rate':3.0,'yield_differential':1.0}
    assert carry_context(incomplete)['direction']=='WAIT'
    complete={**incomplete,'broker_swap_long':2.5,'broker_swap_mode':'CURRENCY_DEPOSIT'}
    assert carry_context(complete)['direction']=='BUY'


def test_stale_higher_timeframe_candle_blocks_analysis():
    now=pd.Timestamp.now(tz='UTC'); frames,_=frames_fixture()
    old=frames['H4'].copy(); old.index=old.index-pd.Timedelta(hours=12); frames['H4']=old
    result=analyze('USDJPY',frames,tick={'time':now.isoformat(),'bid':109.99,'ask':109.991},source='TEST',news_risk='LOW',threshold=75,min_bars=205)
    assert result['direction']=='WAIT'
    assert result['data_health']=='STALE_CANDLE_HISTORY'


def test_deriv_public_market_data_symbol_and_tick_validation():
    from a227c.adapters.deriv_adapter import extract_active_symbols, normalize_tick, PUBLIC_MARKET_DATA_ENDPOINT
    symbols = extract_active_symbols({'active_symbols': [{'symbol': '1HZ100V'}, {'symbol': 'R_100'}]})
    assert symbols == {'1HZ100V', 'R_100'}
    assert PUBLIC_MARKET_DATA_ENDPOINT == 'wss://api.derivws.com/trading/v1/options/ws/public'
    tick = normalize_tick({'symbol': 'R_100', 'quote': '123.45', 'epoch': 1795260000}, {'DERIV_R100': 'R_100'})
    assert tick['internal_symbol'] == 'DERIV_R100' and tick['quote'] == 123.45
    assert normalize_tick({'symbol': 'R_100', 'quote': 'nan', 'epoch': 1795260000}, {}) is None
    assert normalize_tick({'symbol': 'R_100', 'quote': '-1', 'epoch': 1795260000}, {}) is None
    assert normalize_tick({'symbol': 'R_100', 'quote': '123.45', 'epoch': 0}, {}) is None

def test_deriv_api_error_is_not_treated_as_empty_symbol_list():
    import pytest
    from a227c.adapters.deriv_adapter import extract_active_symbols
    with pytest.raises(RuntimeError, match='Invalid request'):
        extract_active_symbols({'error': {'message': 'Invalid request'}})


def test_backend_api_token_prefers_environment_secret(monkeypatch):
    from a227c import server
    monkeypatch.setenv('A227C_API_TOKEN', 'env-secret-for-test')
    assert server._configured_token() == 'env-secret-for-test'
    monkeypatch.delenv('A227C_API_TOKEN')
    assert server._configured_token() is None  # example placeholder must never authenticate


def test_carry_requires_swap_in_account_deposit_currency():
    from a227c.core.strategies import carry_context
    base={'rate_differential_available':True,'base_minus_quote_rate':3.0,'yield_differential':1.0,
          'broker_swap_long':2.5,'broker_swap_short':-1.0}
    assert carry_context(base)['direction']=='WAIT'
    verified={**base,'broker_swap_mode':'CURRENCY_DEPOSIT'}
    assert carry_context(verified)['direction']=='BUY'

def test_trading_economics_latest_indicator_uses_parsed_date_order(monkeypatch):
    from a227c.adapters.news_adapter import TradingEconomicsCalendar
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return [
                {'LatestValue':1.0,'LatestValueDate':'01/01/2025','Unit':'%','Frequency':'Monthly'},
                {'LatestValue':2.0,'LatestValueDate':'11/01/2026','Unit':'%','Frequency':'Monthly'}
            ]
    class Session:
        headers={}
        def get(self,*args,**kwargs): return Response()
    provider=TradingEconomicsCalendar('test-key'); provider.session=Session()
    result=provider.latest_indicator('United States','Interest Rate')
    assert result['value']==2.0 and result['unit']=='%'


def test_trading_economics_indicator_catalog_normalizes_categories(monkeypatch):
    from a227c.adapters.news_adapter import TradingEconomicsCalendar
    class Response:
        def raise_for_status(self): pass
        def json(self): return [{'Category':'Interest Rate'},{'Category':'Government Bond 10Y'},{'Title':'Other'}]
    class Session:
        headers={}
        def get(self,*args,**kwargs): return Response()
    provider=TradingEconomicsCalendar('test-key'); provider.session=Session()
    assert provider.indicator_catalog('Japan') == {'Interest Rate','Government Bond 10Y','Other'}

def test_trading_economics_calendar_parses_provider_12_hour_timestamp():
    from a227c.adapters.news_adapter import TradingEconomicsCalendar
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return [{'Country':'Japan','Date':'11/21/2026 09:30:00 AM','Event':'Policy Decision',
                     'Importance':3,'Currency':'JPY','Actual':'0.5','Forecast':'0.25','Previous':'0.25'}]
    class Session:
        headers={}
        def get(self,*args,**kwargs): return Response()
    provider=TradingEconomicsCalendar('test-key'); provider.session=Session()
    events=provider.upcoming()
    assert len(events)==1 and events[0]['currency']=='JPY'
    assert events[0]['timestamp'].endswith('+00:00')

def test_mt5_history_export_rejects_bad_candles_and_accepts_valid_utc():
    import pandas as pd, pytest
    from a227c.research.mt5_history_export import validate_ohlc
    idx=pd.date_range('2026-01-01',periods=3,freq='h',tz='UTC')
    good=pd.DataFrame({'open':[1,1,1],'high':[2.0,2.0,2.0],'low':[.5,.5,.5],'close':[1.5,1.5,1.5]},index=idx)
    assert validate_ohlc(good)['ohlc_geometry']=='VALID'
    bad=good.copy(); bad.iloc[0,bad.columns.get_loc('high')]=.9
    with pytest.raises(ValueError,match='geometry'): validate_ohlc(bad)

def test_carry_study_uses_only_point_in_time_available_macro_and_swap():
    import pandas as pd
    from a227c.research.carry_study import point_in_time_carry_study
    macro=pd.DataFrame([
        {'available_at':pd.Timestamp('2026-01-02T00:00:00Z'),'base_rate':4.0,'quote_rate':1.0,'base_yield_10y':4.2,'quote_yield_10y':1.2}
    ])
    swaps=pd.DataFrame([
        {'available_at':pd.Timestamp('2026-01-02T00:00:00Z'),'swap_long':2.0,'swap_short':-1.0,'swap_mode':'CURRENCY_DEPOSIT'}
    ])
    times=pd.to_datetime(['2026-01-01T23:00:00Z','2026-01-02T01:00:00Z'])
    result=point_in_time_carry_study(times,macro,swaps)
    assert result.direction.tolist()==['WAIT','BUY']
    assert result.iloc[0].macro_available_at is pd.NaT or pd.isna(result.iloc[0].macro_available_at)

def test_backtest_reports_mae_mfe_and_applies_round_turn_costs():
    from a227c.research.backtest import _metrics
    trades=[{'r_multiple':1.0,'mae_r':0.4,'mfe_r':1.8,'holding_bars':3},
            {'r_multiple':-0.5,'mae_r':1.1,'mfe_r':0.2,'holding_bars':2}]
    m=_metrics(trades)
    assert m['average_mae_r']==0.75
    assert m['average_mfe_r']==1.0
    assert m['average_holding_bars']==2.5
    assert m['max_drawdown_r']==0.5


def test_walk_forward_has_disjoint_oos_folds_and_retains_history_context():
    from a227c.research.backtest import walk_forward
    import pandas as pd, numpy as np
    idx=pd.date_range('2024-01-01',periods=1200,freq='h',tz='UTC')
    close=100+np.arange(len(idx))*0.002+np.sin(np.arange(len(idx))/7)*0.2
    df=pd.DataFrame({'open':close-0.01,'high':close+0.12,'low':close-0.12,'close':close,'tick_volume':100},index=idx)
    result=walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0.01,folds=4,
                        commission_price_units=0.002,slippage_price_units=0.001)
    folds=result['out_of_sample_folds']
    assert len(folds)==4
    assert all(folds[i]['test_end'] < folds[i+1]['test_start'] for i in range(3))
    assert result['out_of_sample'] is not None
    assert 'average_mae_r' in result['out_of_sample']

def test_research_runner_never_fabricates_missing_datasets(tmp_path):
    from a227c.research.run_research import run
    report=run(tmp_path,tmp_path/'report.json',costs={})
    assert report['datasets']=={}
    assert all(x['status']=='BLOCKED_MISSING_REAL_DATASET' for x in report['results'])
    assert (tmp_path/'report.json').exists()


def test_research_runner_blocks_unpriced_real_dataset(tmp_path):
    from a227c.research.run_research import run
    import pandas as pd
    idx=pd.date_range('2025-01-01',periods=700,freq='h',tz='UTC')
    close=100+pd.Series(range(700)).to_numpy()*0.001
    frame=pd.DataFrame({'time_utc':idx,'open':close,'high':close+0.1,'low':close-0.1,'close':close})
    frame.to_csv(tmp_path/'USDJPY_H1.csv',index=False)
    report=run(tmp_path,tmp_path/'report.json',costs={})
    item=next(x for x in report['results'] if x['symbol']=='USDJPY' and x['timeframe']=='H1')
    assert item['status']=='BLOCKED_INVALID_OR_INSUFFICIENT_DATA'
    assert 'commission/slippage' in item['error']

def test_exness_tick_archive_import_preserves_bid_ask_and_spread(tmp_path):
    import zipfile, pandas as pd
    from a227c.research.exness_tick_history import load_exness_archive, resample_quote_bars
    csv='Exness,Symbol,Timestamp,Bid,Ask\nExness,EURUSD,2026-01-01T00:00:00.000Z,1.10000,1.10020\nExness,EURUSD,2026-01-01T00:05:00.000Z,1.10010,1.10030\nExness,EURUSD,2026-01-01T00:10:00.000Z,1.10020,1.10040\n'
    archive=tmp_path/'ticks.zip'
    with zipfile.ZipFile(archive,'w') as z: z.writestr('ticks.csv',csv)
    ticks,meta=load_exness_archive(archive)
    bid,ask,spread=resample_quote_bars(ticks,'M15')
    assert meta['ticks']==3 and len(bid)==1 and len(ask)==1
    assert round(float(ask.iloc[0].open-bid.iloc[0].open),6)==0.0002
    assert float(spread.iloc[0].spread_open)>0


def test_exness_tick_import_rejects_crossed_market(tmp_path):
    import zipfile, pytest
    from a227c.research.exness_tick_history import load_exness_archive
    archive=tmp_path/'bad.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('ticks.csv','Exness,Symbol,Timestamp,Bid,Ask\nExness,EURUSD,2026-01-01T00:00:00Z,1.2,1.1\n')
    with pytest.raises(ValueError,match='Crossed market'): load_exness_archive(archive)


def test_backtest_keeps_final_holdout_separate():
    from a227c.research.backtest import walk_forward
    idx=pd.date_range('2024-01-01',periods=1400,freq='h',tz='UTC')
    close=100+np.arange(len(idx))*0.002+np.sin(np.arange(len(idx))/7)*0.2
    df=pd.DataFrame({'open':close-0.01,'high':close+0.12,'low':close-0.12,'close':close,'tick_volume':100},index=idx)
    result=walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0.01,folds=4)
    assert len(result['out_of_sample_folds'])==4
    assert result['final_holdout']['status']=='SEPARATE_FINAL_HOLDOUT_NOT_USED_IN_FOLD_METRICS'
    assert result['final_holdout']['start'] > result['out_of_sample_folds'][-1]['test_end']


def test_quote_aware_backtest_requires_exact_bid_ask_alignment():
    import pytest
    from a227c.research.backtest import run_bar_backtest
    idx=pd.date_range('2026-01-01',periods=300,freq='h',tz='UTC')
    close=np.linspace(100,101,300)
    bid=pd.DataFrame({'open':close-.01,'high':close+.1,'low':close-.1,'close':close},index=idx)
    ask=bid+0.02
    with pytest.raises(ValueError,match='indexes must match'):
        run_bar_backtest(bid,'TREND_PULLBACK','USDJPY','H1',ask_frame=ask.iloc[1:])


def test_alfred_vintage_availability_is_conservatively_shifted_to_next_utc_day():
    from a227c.research.fred_alfred_vintages import fetch_vintages
    class Response:
        def raise_for_status(self): pass
        def json(self):
            return {'observations':[{'date':'2020-01-01','realtime_start':'2020-02-15','realtime_end':'2020-03-01','value':'1.25'}]}
    class Session:
        def get(self,*args,**kwargs): return Response()
    result=fetch_vintages('DFF','fake-key',session=Session())
    assert result.iloc[0].available_at == '2020-02-16T00:00:00+00:00'


def test_carry_study_blocks_stale_swap_observations():
    import pandas as pd
    from a227c.research.carry_study import point_in_time_carry_study
    macro=pd.DataFrame([{'available_at':pd.Timestamp('2026-01-02T00:00:00Z'),'base_rate':4.0,'quote_rate':1.0,'base_yield_10y':4.2,'quote_yield_10y':1.2}])
    swaps=pd.DataFrame([{'available_at':pd.Timestamp('2026-01-02T00:00:00Z'),'swap_long':2.0,'swap_short':-1.0,'swap_mode':'CURRENCY_DEPOSIT'}])
    result=point_in_time_carry_study(pd.to_datetime(['2026-01-20T00:00:00Z']),macro,swaps)
    assert result.iloc[0].direction=='WAIT'
    assert 'stale' in result.iloc[0].reason.lower()


def test_research_runner_accepts_exness_bid_ask_pair_without_mt5_file(tmp_path):
    from a227c.research.run_research import run
    idx=pd.date_range('2024-01-01',periods=700,freq='15min',tz='UTC')
    close=2000+np.arange(700)*0.01+np.sin(np.arange(700)/8)*0.2
    bid=pd.DataFrame({'open':close-.01,'high':close+.1,'low':close-.1,'close':close},index=idx)
    ask=bid+0.03
    bid.to_csv(tmp_path/'XAUUSD_M15_BID.csv',index_label='time_utc')
    ask.to_csv(tmp_path/'XAUUSD_M15_ASK.csv',index_label='time_utc')
    report=run(tmp_path,tmp_path/'report.json',{'XAUUSD_M15':{'commission_round_turn_price_units':0.0,'slippage_round_turn_price_units':0.0,'commission_basis':'test fixture zero commission','slippage_basis':'test fixture zero slippage'}})
    row=next(x for x in report['results'] if x['symbol']=='XAUUSD' and x['timeframe']=='M15' and x['strategy']=='LIQUIDITY_SMC')
    assert row['status']=='SIMULATED_REAL_HISTORY'
    assert row['quote_source']=='EXNESS_HISTORICAL_BID_ASK_ARCHIVE'


def test_exness_import_preserves_distinct_ticks_with_same_timestamp_and_checks_symbol(tmp_path):
    import zipfile, pytest
    from a227c.research.exness_tick_history import load_exness_archive
    archive=tmp_path/'same_ms.zip'
    csv=('Exness,Symbol,Timestamp,Bid,Ask\n'
         'Exness,USDJPY,2026-01-01T00:00:00.100Z,150.001,150.003\n'
         'Exness,USDJPY,2026-01-01T00:00:00.100Z,150.002,150.004\n')
    with zipfile.ZipFile(archive,'w') as z: z.writestr('ticks.csv',csv)
    ticks,meta=load_exness_archive(archive,expected_provider_symbol='USDJPY')
    assert len(ticks)==2 and meta['distinct_same_timestamp_quotes_retained']==2
    with pytest.raises(ValueError,match='symbol mismatch'):
        load_exness_archive(archive,expected_provider_symbol='USDJPYm')


def test_exness_import_fails_closed_on_malformed_rows(tmp_path):
    import zipfile, pytest
    from a227c.research.exness_tick_history import load_exness_archive
    archive=tmp_path/'malformed.zip'
    csv=('Exness,Symbol,Timestamp,Bid,Ask\n'
         'Exness,USDJPY,2026-01-01T00:00:00Z,150.001,150.003\n'
         'Exness,USDJPY,not-a-date,150.002,150.004\n')
    with zipfile.ZipFile(archive,'w') as z: z.writestr('ticks.csv',csv)
    with pytest.raises(ValueError,match='Malformed rows'):
        load_exness_archive(archive)


def test_exness_import_rejects_unzoned_timestamps(tmp_path):
    import zipfile, pytest
    from a227c.research.exness_tick_history import load_exness_archive
    archive=tmp_path/'naive.zip'
    with zipfile.ZipFile(archive,'w') as z:
        z.writestr('ticks.csv','Exness,Symbol,Timestamp,Bid,Ask\nExness,USDJPY,2026-01-01 00:00:00,150.001,150.003\n')
    with pytest.raises(ValueError,match='timezone must be explicit'):
        load_exness_archive(archive)


def test_exness_batch_import_creates_single_batch_manifest(tmp_path):
    import zipfile, json
    from a227c.research.exness_tick_history import import_batch
    incoming=tmp_path/'incoming'; incoming.mkdir()
    for sym in ('GBPUSD','USDJPY'):
        with zipfile.ZipFile(incoming/f'{sym}.zip','w') as z:
            z.writestr('ticks.csv',f'Exness,Symbol,Timestamp,Bid,Ask\nExness,{sym},2026-01-01T00:00:00Z,1.1000,1.1002\nExness,{sym},2026-01-01T00:05:00Z,1.1001,1.1003\n')
    config=tmp_path/'batch.json'
    config.write_text(json.dumps({'archives':[{'internal_symbol':'GBPUSD','archive_path':'incoming/GBPUSD.zip','provider_symbol':'GBPUSD'}, {'internal_symbol':'USDJPY','archive_path':'incoming/USDJPY.zip','provider_symbol':'USDJPY'}]}))
    result=import_batch(config,tmp_path/'out')
    assert len(result['imports'])==2
    assert (tmp_path/'out'/'EXNESS_BATCH_MANIFEST.json').exists()
