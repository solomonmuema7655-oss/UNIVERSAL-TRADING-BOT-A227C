"""Import Exness historical bid/ask tick ZIP/CSV archives into validated quote bars.

The public archive is downloaded by the operator from Exness Tick History. This tool
never guesses instruments or fabricates prices. It preserves the original archive hash
and emits separate BID and ASK OHLC bars so spread is observable per bar.
"""
from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path
from io import BytesIO
import pandas as pd

REQUIRED = {"Timestamp", "Bid", "Ask", "Symbol"}

def _normal_symbol(value: str) -> str:
    return ''.join(ch for ch in str(value).upper() if ch.isalnum())

def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _read_csv_bytes(raw: bytes) -> pd.DataFrame:
    # Exness archive files may have a provider/instrument prefix before the header.
    from io import StringIO
    text = raw.decode("utf-8-sig", errors="strict")
    lines = text.splitlines()
    header = next((i for i, line in enumerate(lines) if all(k in line for k in ("Timestamp", "Bid", "Ask"))), None)
    if header is None:
        raise ValueError("No Exness tick CSV header containing Timestamp, Bid and Ask was found")
    frame = pd.read_csv(StringIO("\n".join(lines[header:])))
    frame.columns = [str(c).strip().strip('"') for c in frame.columns]
    missing = REQUIRED.difference(frame.columns)
    if missing: raise ValueError(f"Tick CSV missing columns: {sorted(missing)}")
    return frame

def load_exness_archive(path: Path, expected_provider_symbol: str | None = None) -> tuple[pd.DataFrame, dict]:
    """Load Exness ticks without silently dropping malformed rows or distinct same-ms ticks."""
    raw=path.read_bytes(); source_hash=_sha256(raw); pieces=[]
    if zipfile.is_zipfile(BytesIO(raw)):
        with zipfile.ZipFile(BytesIO(raw)) as z:
            names=[n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX/')]
            if not names: raise ValueError('ZIP contains no CSV tick files')
            for name in names: pieces.append((name,_read_csv_bytes(z.read(name))))
    elif path.suffix.lower()=='.csv': pieces.append((path.name,_read_csv_bytes(raw)))
    else: raise ValueError('Input must be an Exness ZIP archive or CSV')
    frames=[]; source_files=[]; providers=set(); symbols=set()
    for name,part in pieces:
        x=part.copy()
        raw_time=x['Timestamp'].astype(str).str.strip()
        parsed=pd.to_datetime(raw_time,utc=True,errors='coerce')
        if parsed.isna().any(): raise ValueError(f'Malformed rows in {name}: {int(parsed.isna().sum())} invalid timestamps; refusing partial import')
        has_zone=raw_time.str.contains(r'(?:Z|[+-]\d{2}:?\d{2})$',case=False,regex=True)
        if not has_zone.all(): raise ValueError(f'Naive/unzoned timestamps in {name}; timezone must be explicit')
        x['timestamp']=parsed
        x['bid']=pd.to_numeric(x['Bid'],errors='coerce'); x['ask']=pd.to_numeric(x['Ask'],errors='coerce')
        x['provider']=x['Exness'].astype(str).str.strip() if 'Exness' in x.columns else 'UNSPECIFIED'
        x['provider_symbol']=x['Symbol'].astype(str).str.strip()
        bad=x[['timestamp','bid','ask']].isna().any(axis=1) | x.provider_symbol.eq('')
        if bad.any(): raise ValueError(f'Malformed rows in {name}: {int(bad.sum())} of {len(x)}; refusing partial import')
        if (x[['bid','ask']]<=0).any().any(): raise ValueError(f'Non-positive quote in {name}')
        if (x.ask<x.bid).any(): raise ValueError(f'Crossed market (ask < bid) in {name}')
        providers.update(x.provider.unique().tolist()); symbols.update(x.provider_symbol.unique().tolist())
        x=x[['timestamp','bid','ask','provider_symbol']].copy(); x['_source_order']=range(len(x))
        frames.append(x.sort_values(['timestamp','_source_order'],kind='stable'))
        source_files.append({'name':name,'valid_ticks':len(x)})
    if len(symbols)!=1: raise ValueError(f'Archive must contain exactly one provider symbol; found {sorted(symbols)}')
    provider_symbol=next(iter(symbols))
    if expected_provider_symbol and _normal_symbol(provider_symbol)!=_normal_symbol(expected_provider_symbol):
        raise ValueError(f'Provider symbol mismatch: archive={provider_symbol}, expected={expected_provider_symbol}')
    if any(pv.lower() not in ('exness','') for pv in providers): raise ValueError(f'Unexpected provider values: {sorted(providers)}')
    ticks=pd.concat(frames,ignore_index=True).sort_values(['timestamp','_source_order'],kind='stable')
    before=len(ticks); ticks=ticks.drop_duplicates(['timestamp','bid','ask','provider_symbol'],keep='last')
    duplicates=before-len(ticks); ticks=ticks.set_index('timestamp').sort_index(kind='stable')
    if not ticks.index.is_monotonic_increasing: raise ValueError('Tick timestamps are not ordered')
    ticks['spread']=ticks.ask-ticks.bid
    if (ticks.spread<=0).any(): raise ValueError('Non-positive spread encountered')
    meta={'source':'Exness historical tick archive','archive_file':path.name,'archive_sha256':source_hash,
          'provider_values':sorted(providers),'provider_symbol':provider_symbol,'source_files':source_files,
          'ticks':len(ticks),'exact_duplicate_records_removed':duplicates,
          'distinct_same_timestamp_quotes_retained':int(ticks.index.duplicated(keep=False).sum()),
          'first_tick_utc':ticks.index[0].isoformat(),'last_tick_utc':ticks.index[-1].isoformat(),
          'max_inter_tick_gap_seconds':float(ticks.index.to_series().diff().dt.total_seconds().max() or 0),
          'timestamp_timezone_policy':'Explicit timezone required; normalized to UTC',
          'spread_price_units':{'median':float(ticks.spread.median()),'p90':float(ticks.spread.quantile(.90)),
                                'p95':float(ticks.spread.quantile(.95)),'max':float(ticks.spread.max())},
          'limitations':'Indicative bid/ask quotes, not individual executions. Server/account-type pricing may differ; verify exact symbol and coverage.'}
    return ticks,meta

def resample_quote_bars(ticks: pd.DataFrame, timeframe: str) -> tuple[pd.DataFrame,pd.DataFrame,pd.DataFrame]:
    rule={'M15':'15min','M30':'30min','H1':'1h','H4':'4h'}.get(timeframe)
    if not rule: raise ValueError('Unsupported timeframe; use M15, M30, H1 or H4')
    def bars(series):
        o=series.resample(rule,closed='left',label='left').ohlc().dropna()
        o.columns=['open','high','low','close']; return o
    bid=bars(ticks.bid); ask=bars(ticks.ask)
    common=bid.index.intersection(ask.index); bid=bid.loc[common]; ask=ask.loc[common]
    spread=ticks.spread.resample(rule,closed='left',label='left').ohlc().dropna()
    spread.columns=['spread_open','spread_high','spread_low','spread_close']
    spread=spread.loc[spread.index.intersection(common)]
    if (spread[['spread_open','spread_close']]<=0).any().any(): raise ValueError('Invalid resampled bid/ask spread')
    return bid,ask,spread

def import_archive(path: Path, output: Path, symbol: str, timeframes=('M15','M30','H1','H4'), provider_symbol: str | None = None) -> dict:
    ticks,meta=load_exness_archive(path,expected_provider_symbol=provider_symbol); output.mkdir(parents=True,exist_ok=True); outputs={}
    for tf in timeframes:
        bid,ask,spread=resample_quote_bars(ticks,tf)
        if bid.empty: raise ValueError(f'No {tf} bars were generated')
        for label,frame in [('BID',bid),('ASK',ask),('SPREAD',spread)]:
            dest=output/f'{symbol}_{tf}_{label}.csv'; frame.to_csv(dest,index_label='time_utc')
            outputs[dest.name]={'rows':len(frame),'sha256':_sha256(dest.read_bytes()),
                                'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}
    manifest={**meta,'internal_symbol':symbol,'timeframes':list(timeframes),'outputs':outputs,
              'bar_construction':'UTC-aligned left-closed, left-labelled resampling of source ticks'}
    (output/f'{symbol}_EXNESS_TICK_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def import_batch(config_path: Path, output_root: Path) -> dict:
    """Import a reviewed list of archive files in one reproducible batch."""
    config=json.loads(config_path.read_text(encoding='utf-8'))
    items=config.get('archives',[])
    if not items: raise ValueError('Batch config must contain a non-empty archives list')
    results=[]
    for item in items:
        internal=item['internal_symbol']; archive=Path(item['archive_path'])
        if not archive.is_absolute(): archive=(config_path.parent/archive).resolve()
        provider=item.get('provider_symbol')
        result=import_archive(archive,output_root/internal,internal,provider_symbol=provider)
        results.append({'internal_symbol':internal,'archive_path':str(archive),'provider_symbol':result['provider_symbol'],
                        'ticks':result['ticks'],'archive_sha256':result['archive_sha256']})
    manifest={'schema_version':1,'provider':'Exness','batch_config_sha256':_sha256(config_path.read_bytes()),
              'imports':results,'policy':'Each archive must contain exactly one provider symbol; no silent alias inference.'}
    output_root.mkdir(parents=True,exist_ok=True)
    (output_root/'EXNESS_BATCH_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--archive'); p.add_argument('--symbol',choices=['XAUUSD','USTECH100','GBPJPY','GBPUSD','USDJPY']); p.add_argument('--provider-symbol',help='Expected exact Symbol value in the archive'); p.add_argument('--batch-config'); p.add_argument('--output',default='research_data/exness_ticks')
    a=p.parse_args()
    if a.batch_config: result=import_batch(Path(a.batch_config),Path(a.output))
    else:
        if not a.archive or not a.symbol: p.error('Use --batch-config or provide both --archive and --symbol')
        result=import_archive(Path(a.archive),Path(a.output),a.symbol,provider_symbol=a.provider_symbol)
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
