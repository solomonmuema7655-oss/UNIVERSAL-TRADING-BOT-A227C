# A227C — Final Source Status (research-complete source package)

## Verified in this source tree

- Exactly five logical markets: XAUUSD, USTECH100, GBPJPY, GBPUSD, USDJPY.
- H4 → H1 → M30 → M15 analysis protocol remains enforced; M15 remains the final gate.
- Existing agreed production-oriented families remain implemented: USDJPY trend pullback + carry context; GBPUSD/XAUUSD session breakout; XAUUSD liquidity/SMC.
- GBPJPY now has six executable deterministic research candidates.
- USTECH100 now has six executable deterministic research candidates.
- GBPUSD and XAUUSD now have additional comparative research candidates instead of relying on a single hard-coded family.
- USDJPY now has a comparative research matrix while retaining the original trend/carry architecture.
- Research candidates are visible in analysis output but carry `RESEARCH_ONLY`; the decision engine excludes them from production evidence.
- USTECH100 symbol discovery explicitly distinguishes Exness `USTEC` and `USTEC_x100` and refuses an ambiguous live mapping when both are present.
- Candidate screening supports chronological M15 research using timezone-aware Asian, London and New York session levels, prior-day levels, H1-derived structure, explicit costs and conservative stop-first resolution.
- PBO/CSCV, Deflated Sharpe, tick replay, duration calibration, swap ledger and shadow-validation components remain part of the promotion pipeline.
- No `mt5.order_send()` exists in the source.
- No broker execution path is exposed.
- 52 automated tests pass; only two existing FastAPI deprecation warnings remain.
- Python compilation passes.

## Research limitation that remains deliberately fail-closed

This source package contains the complete deterministic research paths, but no profitability result is claimed without the real provider dataset. Production promotion still requires exact Exness/MT5 symbols, real historical quotes, cost/financing evidence, point-in-time macro/news data where applicable, tick replay, statistical selection-bias checks and live shadow validation.

## Android build boundary

The repository CI remains the authoritative Android build environment (Ubuntu 22.04, Java 17, Gradle 8.7). A full Android Gradle build was not executed in this Linux working environment because the source tree does not contain a Gradle wrapper and the environment does not have the Gradle executable installed. Therefore this status does not claim a locally produced APK.

## Package

The accompanying ZIP is a source artifact. It is not evidence of live provider connectivity, profitability, TLS deployment, Play Protect approval or physical-device acceptance.
