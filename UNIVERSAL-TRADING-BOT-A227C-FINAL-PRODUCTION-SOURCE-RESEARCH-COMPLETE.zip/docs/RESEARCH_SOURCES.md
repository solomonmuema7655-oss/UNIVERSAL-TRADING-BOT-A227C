# A227C Research Sources — Strategy and Provider Basis

## Provider / data sources

1. Exness Help Center — Indices: USTEC and USTEC_x100 contract distinction.
2. Exness Help Center — U.S. daylight-saving trading-hour update for USTEC/USTEC_x100.
3. MQL5 Python Integration — `copy_ticks_range`, including bid/ask tick history.
4. MQL5 Python Integration — `symbol_info` contract and swap metadata.
5. Trading Economics — point-in-time economic calendar for look-ahead-safe historical research.

## Strategy literature / research

1. Holmberg, Lönnbark & Lundström — *Assessing the profitability of intraday opening range breakout strategies* (Finance Research Letters, 2013).
2. Tsai et al. — *Assessing the profitability of timely opening range breakout on index futures markets* (IEEE Access, 2019).
3. Chuk — *Regime-Dependent Opening Range Breakout Returns in Nasdaq-100 Futures* (2026 working paper). Used as recent context, not as a guarantee of performance for Exness CFDs.
4. Burnside, Eichenbaum & Rebelo — *Carry Trade and Momentum in Currency Markets* (Annual Review of Financial Economics, 2011).
5. Dahlquist & Hasseltoft — *Economic Momentum and Currency Returns* (Journal of Financial Economics, 2020).
6. *Dissecting currency momentum* (Journal of Financial Economics, 2022).

## Research-policy implication

The literature establishes that the families are legitimate research hypotheses, not that a particular Exness symbol, timeframe, cost model or 2026 regime will make them profitable. A227C therefore requires provider-specific empirical validation before promotion.
