# A227C — Complete Five-Market Strategy Research Coverage

## Purpose

This document records the deterministic strategy research coverage that is now implemented in the source. It is not a profitability claim and it does not promote a strategy merely because a rule exists in code.

A227C covers exactly five initial logical markets:

- XAUUSD
- USTECH100
- GBPJPY
- GBPUSD
- USDJPY

Every market now has an explicit executable research matrix. Every candidate produces BUY/SELL/WAIT observations from deterministic market rules and carries `RESEARCH_ONLY` status until the promotion evidence gate is satisfied.

## Market matrix

| Market | Existing production-oriented families | Research candidates |
|---|---|---|
| XAUUSD | Liquidity/SMC; London/New York breakout | Liquidity/SMC; session breakout; failed breakout; H1→M15 trend pullback; volatility expansion; prior-day liquidity sweep |
| USTECH100 | None promoted yet | US opening-range breakout; US opening failed breakout; overnight-range breakout; volatility expansion; M15 trend pullback; prior-day liquidity sweep |
| GBPJPY | None promoted yet | Asia-range London breakout; Asia sweep→London reclaim; H1 trend→M15 pullback; volatility breakout; liquidity-sweep continuation; carry-filtered trend |
| GBPUSD | London/New York breakout | Session breakout; failed breakout; H1→M15 trend pullback; volatility expansion; prior-day liquidity sweep |
| USDJPY | Trend pullback; carry/macro context | Trend pullback; carry context; session breakout; Asia sweep→London reclaim; H1→M15 trend pullback; volatility breakout; liquidity-sweep continuation; carry-filtered trend |

## Research conclusions that shaped the rules

### USTECH100

The U.S. opening-range family is now a first-class research path rather than an unimplemented placeholder. Published research supports testing opening-range rules on index futures, while also showing that results can be regime-dependent and sensitive to costs and sample period. Therefore A227C tests multiple opening-range definitions and both continuation and failed-breakout hypotheses instead of assuming one universal ORB parameter is correct.

The Exness instrument mapping is also treated as a contract-selection problem. Exness documents both `USTEC` and `USTEC_x100` with different contract sizes, so A227C resolves the exact MT5 symbol from the live terminal and refuses to silently choose when both variants are present.

### GBPJPY

GBPJPY now has a complete research family around London discovery of the Asian range, sweep/reclaim behavior, H1 directional structure with M15 confirmation, volatility expansion, liquidity continuation, and carry-filtered trend context. Carry is context only: it cannot independently create an M15 signal.

### GBPUSD / XAUUSD

The existing London/New York breakout family remains intact, but it is no longer the only research hypothesis. Failed breakouts, pullbacks, volatility expansion and prior-day liquidity sweeps are available for controlled comparative research. This prevents A227C from selecting one retail rule simply because it was coded first.

### USDJPY

The existing trend-pullback and carry-context design remains intact. Additional research candidates allow comparative testing of session/liquidity/volatility behavior. The carry module remains macro context rather than a short-term entry trigger.

## Evidence pipeline

A candidate can be promoted only when the exact provider-specific evidence pipeline passes:

1. Exact MT5/Exness symbol mapping.
2. Real historical provider data; no generated price history.
3. H4/H1/M30/M15 time-series integrity.
4. Explicit spread, commission and slippage assumptions with provenance.
5. Point-in-time news/macro inputs when a rule uses them.
6. Historical broker financing evidence for overnight/carry exposure.
7. Chronological development/OOS folds plus a separate final holdout.
8. Candidate-family selection-bias analysis using PBO/CSCV and Deflated Sharpe.
9. Quote-level bid/ask tick replay for finalists.
10. Live read-only shadow validation before production eligibility.

A candidate that lacks evidence remains WAIT/RESEARCH_ONLY. The engine never fills missing evidence with fabricated data.

## Current external research basis

- Exness documents NASDAQ-100 as USTEC and distinguishes USTEC from USTEC_x100 by contract size.
- Exness trading-hour changes for USTEC/USTEC_x100 are DST-sensitive, so session rules must use timezone-aware UTC conversion rather than fixed broker-server clock assumptions.
- MQL5's Python integration exposes real terminal ticks with bid/ask fields through `copy_ticks_range`, and symbol metadata through `symbol_info`; A227C uses these capabilities for provider-specific data and cost validation.
- Opening-range breakout has published empirical research, but results vary by market and period; A227C therefore treats ORB as a hypothesis family requiring its own provider-specific validation rather than a guaranteed edge.
- Currency carry and momentum have a substantial academic literature, but carry is exposed to regime and crash/reversal risks; A227C therefore keeps carry as context and requires technical confirmation.

## Non-negotiable distinction

**Implemented research coverage is not the same thing as validated profitability.** The code now contains the complete deterministic research paths. Production promotion still requires real Exness/MT5 history, exact symbol confirmation, cost/financing evidence, tick replay, statistical selection-bias checks and live shadow observations.
