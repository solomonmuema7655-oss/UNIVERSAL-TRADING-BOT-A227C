# SIYOMA UNIVERSAL-TRADING-BOT-A227C — Final Requirement Matrix

This matrix is the acceptance baseline for the final build. A feature is not considered complete merely because a screen or class exists; the source, integration path and tests/deployment checks must support it.

| # | Concept | Final implementation / acceptance |
|---|---|---|
| 1 | Identity / purpose | A227C is a real-time market intelligence and signal-analysis product; signal-only. |
| 2 | Five markets + mapping | XAUUSD, USTECH100, GBPJPY, GBPUSD, USDJPY with explicit broker symbol mapping; production startup refuses a different set. |
| 3 | Provider separation | MT5/Exness analysis namespace and separate Deriv namespace; Deriv never masquerades as an Exness CFD feed. |
| 4 | Online/offline behavior | Android auto-discovery, WSS reconnect, network-change recovery; stale/missing data forces WAIT. |
| 5 | Five-market scanner | MT5 loop refreshes all five markets continuously. |
| 6 | BUY/SELL/NO TRADE | BUY, SELL and WAIT are first-class; no signal when mandatory evidence is missing. |
| 7 | H4→H1→M30→M15 | Deterministic analysis on all four timeframes. |
| 8 | M15 hard gate | Final direction is derived from M15 after higher-timeframe conflict checks. |
| 9 | Timeframe conflicts | Higher-timeframe opposite bias blocks a countertrend signal. |
| 10 | Strategy engine | Strategy modules return objective evidence and WAIT. |
| 11 | Trend pullback | USDJPY strategy implementation and chronological backtest assignment. |
| 12 | London/NY breakout | GBPUSD/XAUUSD session-breakout implementation using Asian range + close/range/volume evidence. |
| 13 | Liquidity/SMC | XAUUSD objective liquidity sweep/displacement/retest implementation. |
| 14 | Carry context | USDJPY macro context only; policy/yield/swap alignment required and never used as an M15 trigger by itself. |
| 15 | Regime-aware applicability | Regime engine and strategy assignment rules; unsupported combinations return WAIT rather than inventing a strategy. |
| 16 | Regime engine | ADX/ATR percentile deterministic classification. |
| 17 | Structure | Swing structure, HH/HL/LH/LL and BOS. |
| 18 | Momentum | RSI, ROC and MACD evidence. |
| 19 | Volatility | ATR and ATR percentile. |
| 20 | Support/resistance | Swing levels + EMA20 pullback logic. |
| 21 | Liquidity | Equal-high/equal-low clustering and sweep logic. |
| 22 | Sessions | Tokyo, London, New York and overlap logic with timezone-aware calculations. |
| 23 | News risk | Trading Economics calendar gate; production install requires the API key; unknown/stale/high risk blocks confirmed signals. |
| 24 | Correlation/exposure | H1 cross-market correlation snapshot is included in every signal. |
| 25 | Spread/execution quality | Live bid/ask freshness and ATR-relative spread gate. |
| 26 | Setup scoring | Deterministic evidence score, never presented as probability. |
| 27 | Confidence vs probability | UI explicitly states evidence score is not win probability. |
| 28 | Confluence | Multi-timeframe + strategy + technical/fundamental gates combine before signal. |
| 29 | Strategy conflicts | Conflicting applicable strategies force WAIT. |
| 30 | Best-opportunity ranking | Server ranks confirmed opportunities across the five MT5 markets. |
| 31 | Expected holding period | Strategy/timeframe-specific bounded observation policy is returned. |
| 32 | Duration is not a blind timer | Holding window is explicitly an observation range; M15 invalidation and fresh analysis supersede it. |
| 33 | Invalidation | Signal is invalidated when validated analysis falls back to WAIT; Android alerts the user. |
| 34 | Independent risk engine | Separate risk module validates entry, SL, TP, R/R and spread before directional output. |
| 35 | NO SL = NO TRADE | Risk engine rejects a directional setup if no valid SL exists. |
| 36 | Operating modes | Original analysis/assisted/automatic concept is superseded by the final signal-only decision: no broker order mode exists in A227C. |
| 37 | Backtesting | Chronological walk-forward engine with explicit spread, commission, slippage and conservative same-bar handling. |
| 38 | Simulation/paper | Research engine supports historical signal simulation; no broker orders are generated. |
| 39 | Demo | Broker demo trading is intentionally outside A227C execution scope; the application only emits signals for manual action. |
| 40 | Live progression | Backtest → simulation → demo → controlled live validation is a validation/deployment process, not automated trade execution. |
| 41 | Trade journal | Android keeps a local manual signal-outcome journal. |
| 42 | Research laboratory | Research endpoints, historical data ingestion and walk-forward analysis are included. |
| 43 | Calibration | Outcome storage and score buckets are included; forward-duration policy is explicit and can be replaced by validated empirical distributions. No fabricated calibration statistics are emitted. |
| 44 | AI/ML | Superseded: no live AI/ML/LLM decision-making. All decisions are deterministic/rule/statistical. |
| 45 | Explainability | Signal includes timeframe states, structures, strategy evidence, news, spread, risk and reasons. |
| 46 | Signal snapshots | SQLite stores immutable signal payload snapshots and outcomes. |
| 47 | Android ↔ engine separation | Android is a control/visualization client; Python engine owns provider data and analysis. |
| 48 | Real-time monitoring | WSS stream, provider health, feed age, spread, invalidation and ranking. |
| 49 | Notifications | Android notifications for confirmed state changes and invalidations. |
| 50 | Security | No broker or A227C API secret is embedded in APK; public stream is read-only, admin/mutation routes remain protected. Android rejects cleartext and requires HTTPS/WSS bootstrap. |
| 51 | Emergency controls | Protected server emergency-stop/resume controls force all signals to WAIT while active. |
| 52 | Decision pipeline | Provider data → validation → indicators → regime/structure → strategies → confluence/conflicts → news/correlation/spread → risk → M15 gate → signal snapshot. |
| 53 | Philosophy | Statistically defensible opportunities only; evidence insufficiency means WAIT. |
| 54 | Core acceptance | Production build must use a real HTTPS bootstrap endpoint, a deployed WSS engine, MT5, exact broker symbols, Trading Economics access and TLS. CI refuses a production APK if the bootstrap URL is absent or non-HTTPS. |

## External acceptance gates

These cannot be fabricated by source code:

1. A continuously available Windows/VPS host.
2. MetaTrader 5 installed and logged into the intended account/session.
3. Exact five broker symbol names verified in MT5 Market Watch.
4. Trading Economics API entitlement/key for calendar + macro data.
5. Public DNS pointing at the host.
6. Caddy/ACME successfully issuing a trusted certificate.
7. The production Android build receiving the real deployed HTTPS bootstrap URL.
8. Physical Android acceptance test confirming WSS, live ticks, candles, stale-feed WAIT, reconnect and notifications.

The final package automates as much of this as the operating system and account ownership permit; it does not invent credentials, domain ownership or broker access.
