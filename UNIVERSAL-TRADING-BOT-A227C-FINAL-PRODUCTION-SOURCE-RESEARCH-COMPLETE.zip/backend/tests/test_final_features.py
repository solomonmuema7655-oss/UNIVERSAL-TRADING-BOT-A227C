import os, json
from datetime import datetime, timezone
import numpy as np, pandas as pd

from a227c.core.calibration import duration_policy
from a227c.core.ranking import rank_opportunities
from a227c.core.risk import build_risk_plan


def frame(n=240):
    idx=pd.date_range('2026-01-01',periods=n,freq='15min',tz='UTC')
    close=np.linspace(100,110,n)
    return pd.DataFrame({'open':close-0.2,'high':close+0.4,'low':close-0.4,'close':close,'atr14':np.full(n,0.8)},index=idx)


def test_risk_engine_never_allows_missing_sl():
    p=build_risk_plan('BUY',frame(),entry=110.0,spread=0.01)
    assert p.valid and p.stop is not None and p.target is not None and p.rr is not None
    w=build_risk_plan('WAIT',frame(),entry=None,spread=0.01)
    assert not w.valid and w.stop is None


def test_risk_engine_rejects_excessive_spread():
    p=build_risk_plan('BUY',frame(),entry=110.0,spread=0.2)
    assert not p.valid and 'Spread' in p.reason


def test_duration_policy_is_bounded_and_not_timer():
    d=duration_policy('XAUUSD','LIQUIDITY_SMC','M15')
    assert d['min_bars'] < d['max_bars']
    assert 'not a blind timer' in d['policy']


def test_opportunity_ranking_excludes_wait():
    snaps={'USDJPY':{'direction':'BUY','score':82,'quality':'HIGH'},'GBPUSD':{'direction':'WAIT','score':0,'quality':'WAIT'},'XAUUSD':{'direction':'SELL','score':91,'quality':'VERY HIGH'}}
    ranked=rank_opportunities(snaps)
    assert [x['symbol'] for x in ranked]==['XAUUSD','USDJPY']
    assert ranked[0]['rank']==1
