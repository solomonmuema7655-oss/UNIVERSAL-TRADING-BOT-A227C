from pathlib import Path
from a227c.research.acceptance import evaluate, validate_https

def test_api_token_uses_constant_time_compare_source():
    s=Path(__file__).parents[1].joinpath('a227c/server.py').read_text()
    assert 'hmac.compare_digest' in s

def test_production_acceptance_blocks_missing_external_gates():
    r=evaluate({})
    assert r['status']=='BLOCKED' and len(r['missing'])==7

def test_https_bootstrap_validation():
    assert validate_https('https://a227c.example.com/bootstrap')
    assert not validate_https('http://a227c.example.com/bootstrap')

def test_no_mt5_order_execution_api_in_source():
    root=Path(__file__).parents[1].joinpath('a227c')
    source='\n'.join(p.read_text(errors='ignore') for p in root.rglob('*.py'))
    assert 'mt5.order_send(' not in source
