from a227c.core.strategy_registry import MARKETS, market_strategies
from a227c.core.research_candidates import evaluate_candidate
from a227c.research.strategy_candidates import complete_matrix
from a227c.research.strategy_research_catalog import research_plan


def test_all_five_markets_have_explicit_research_coverage():
    assert tuple(MARKETS) == ('XAUUSD','USTECH100','GBPJPY','GBPUSD','USDJPY')
    matrix = complete_matrix()
    assert set(matrix) == set(MARKETS)
    assert all(matrix[s] for s in MARKETS)


def test_previously_agreed_primary_strategies_remain_present():
    assert 'TREND_PULLBACK' in market_strategies('USDJPY')
    assert 'CARRY_CONTEXT' in market_strategies('USDJPY')
    assert 'SESSION_BREAKOUT' in market_strategies('GBPUSD')
    assert 'SESSION_BREAKOUT' in market_strategies('XAUUSD')
    assert 'LIQUIDITY_SMC' in market_strategies('XAUUSD')


def test_new_markets_are_executable_research_not_empty_placeholders():
    assert set(market_strategies('GBPJPY')) >= {
        'ASIA_RANGE_LONDON_BREAKOUT','ASIA_SWEEP_LONDON_RECLAIM','H1_TREND_M15_PULLBACK',
        'VOLATILITY_BREAKOUT','LIQUIDITY_SWEEP_CONTINUATION','CARRY_FILTERED_TREND'}
    assert set(market_strategies('USTECH100')) >= {
        'US_OPEN_RANGE_BREAKOUT','US_OPEN_FAILED_BREAKOUT','OVERNIGHT_RANGE_BREAKOUT',
        'VOLATILITY_EXPANSION','M15_TREND_PULLBACK','PRIOR_DAY_LIQUIDITY_SWEEP'}


def test_unpromoted_candidate_is_explicitly_research_only():
    import pandas as pd, numpy as np
    idx=pd.date_range('2026-01-01',periods=220,freq='15min',tz='UTC')
    c=np.linspace(100,110,220)
    df=pd.DataFrame({'open':c-.2,'high':c+.4,'low':c-.4,'close':c,'atr14':np.full(220,.8),
                     'ema20':c,'ema50':c-.1,'ema200':c-.2,'range':np.full(220,.8)},index=idx)
    r=evaluate_candidate('USTECH100','US_OPEN_RANGE_BREAKOUT',{'M15':df}, {'us_open_high':101,'us_open_low':99})
    assert r['production_status'] == 'RESEARCH_ONLY'


def test_research_plan_exposes_all_markets_and_evidence_layers():
    p=research_plan()
    assert set(p['markets']) == set(MARKETS)
    for key in ('provider_symbol','historical_quotes','costs','walk_forward','selection_bias','tick_replay','shadow'):
        assert key in p['evidence_requirements']


def test_ustec_mapping_never_silently_confuses_contract_variants():
    from a227c.providers.symbol_discovery import discover
    class I:
        def __init__(self,name,description='NASDAQ-100',path='Indices'):
            self.name=name; self.description=description; self.path=path
    both=discover('USTECH100',[I('USTEC'),I('USTEC_x100')])
    assert both['status']=='AMBIGUOUS'
    one=discover('USTECH100',[I('USTEC_x100')])
    assert one['status']=='RESOLVED_CANDIDATE'
    assert one['contract_size_expected']==100


def test_research_only_candidates_never_count_as_production_strategy_evidence():
    from a227c.core.decision import analyze
    import pandas as pd, numpy as np
    frames={}
    for tf, freq in {'M15':'15min','M30':'30min','H1':'1h','H4':'4h'}.items():
        idx=pd.date_range('2020-01-01',periods=230,freq=freq,tz='UTC')
        c=np.linspace(100,120,len(idx))
        frames[tf]=pd.DataFrame({'open':c-.1,'high':c+.3,'low':c-.3,'close':c},index=idx)
    # No live tick/news context is supplied, so the final decision must remain WAIT.
    result=analyze('USTECH100',frames,tick=None,news_risk='UNKNOWN')
    assert result['direction']=='WAIT'
    assert all(s.get('production_status') != 'RESEARCH_ONLY' for s in result['strategies'] if s.get('direction') in ('BUY','SELL'))
