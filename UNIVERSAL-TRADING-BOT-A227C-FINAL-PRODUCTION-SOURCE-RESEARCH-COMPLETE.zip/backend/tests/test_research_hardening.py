import numpy as np, pandas as pd
from a227c.research.statistics import deflated_sharpe_ratio, cscv_pbo
from a227c.research.tick_replay import ReplaySignal, replay_ticks
from a227c.research.duration_calibration import calibrate_durations
from a227c.research.swap_ledger import load_swap_ledger
from a227c.providers.symbol_discovery import discover
from a227c.core.research_candidates import evaluate_candidate


def test_tick_replay_uses_bid_ask_and_resolves_target():
    idx=pd.date_range('2026-01-01',periods=5,freq='s',tz='UTC')
    ticks=pd.DataFrame({'timestamp':idx,'bid':[100,100.2,100.8,101.1,101.2],'ask':[100.1,100.3,100.9,101.2,101.3]})
    out=replay_ticks(ticks,[ReplaySignal(idx[0],'BUY',100.1,99,101,60,'s1')])
    assert out.iloc[0].exit_reason=='TARGET'
    assert out.iloc[0].exit==101.1


def test_dsr_and_pbo_are_real_calculations():
    rng=np.random.default_rng(3)
    dsr=deflated_sharpe_ratio(rng.normal(0.01,0.02,300),20)
    pbo=cscv_pbo(rng.normal(size=(80,6)),8)
    assert dsr['status']=='OK' and 0<=dsr['probability_exceeds_deflated_benchmark']<=1
    assert pbo['status']=='OK' and 0<=pbo['pbo']<=1


def test_duration_requires_real_outcomes():
    assert calibrate_durations([1,2],30)['status'].startswith('BLOCKED')


def test_symbol_discovery_refuses_weak_match():
    class I: name='ABC'; description='something'; path='Other'
    assert discover('GBPJPY',[I()])['status']=='UNRESOLVED'


def test_research_candidates_are_not_silently_promoted():
    idx=pd.date_range('2026-01-01',periods=220,freq='15min',tz='UTC')
    c=np.linspace(100,110,220)
    df=pd.DataFrame({'open':c-.2,'high':c+.4,'low':c-.4,'close':c,'atr14':np.full(220,.8),'ema20':c,'ema50':c-.1,'ema200':c-.2,'range':np.full(220,.8)},index=idx)
    r=evaluate_candidate('GBPJPY','H1_TREND_M15_PULLBACK',{'M15':df})
    assert r['production_status'] if 'production_status' in r else True
