from .structure import structure_state, liquidity_pools

def trend_pullback(df):
    if len(df)<205: return {'name':'TREND_PULLBACK','direction':'WAIT','points':0,'reason':'Need at least 205 bars for stable EMA200 context'}
    x=df.iloc[-1]; recent=df.iloc[-8:-1]; st=structure_state(df); tol=max(float(x.atr14)*0.25,1e-12)
    bullish=x.ema20>x.ema50>x.ema200 and st['state']=='BULLISH'
    bearish=x.ema20<x.ema50<x.ema200 and st['state']=='BEARISH'
    support=st.get('swing_low'); resistance=st.get('swing_high')
    support_touch=(support is not None and recent.low.min()<=support+tol and x.close>support)
    resistance_touch=(resistance is not None and recent.high.max()>=resistance-tol and x.close<resistance)
    ema_support=recent.low.min()<=x.ema20+tol and x.close>x.ema20
    ema_resistance=recent.high.max()>=x.ema20-tol and x.close<x.ema20
    if bullish and (support_touch or ema_support) and x.close>x.open and x.rsi14>=50:
        level='confirmed swing support' if support_touch else 'EMA20 dynamic support'
        return {'name':'TREND_PULLBACK','direction':'BUY','points':3,'reason':f'Bullish H4/H1 structure; pullback tested {level} and closed with bullish rejection'}
    if bearish and (resistance_touch or ema_resistance) and x.close<x.open and x.rsi14<=50:
        level='confirmed swing resistance' if resistance_touch else 'EMA20 dynamic resistance'
        return {'name':'TREND_PULLBACK','direction':'SELL','points':3,'reason':f'Bearish H4/H1 structure; pullback tested {level} and closed with bearish rejection'}
    return {'name':'TREND_PULLBACK','direction':'WAIT','points':0,'reason':'No confirmed pullback/rejection at swing support/resistance or EMA20'}

def session_breakout(df, asian_high=None, asian_low=None, active_session='ASIAN_OR_OFF_SESSION'):
    if len(df)<30: return {'name':'SESSION_BREAKOUT','direction':'WAIT','points':0,'reason':'Insufficient session history'}
    if active_session not in ('LONDON','NEW_YORK','LONDON_NEW_YORK_OVERLAP'):
        return {'name':'SESSION_BREAKOUT','direction':'WAIT','points':0,'reason':'Outside the London/New York breakout window'}
    if asian_high is None or asian_low is None:
        return {'name':'SESSION_BREAKOUT','direction':'WAIT','points':0,'reason':'Asian range levels unavailable; session breakout disabled'}
    x=df.iloc[-1]; prev=df.iloc[-21:-1]; avg=float(prev.high.sub(prev.low).mean()); body=float(x.body)
    volume_col='tick_volume' if 'tick_volume' in df.columns else 'volume' if 'volume' in df.columns else None
    volume_note='tick-activity proxy unavailable'
    volume_ok=True
    if volume_col:
        v=float(x.get(volume_col,0) or 0); baseline=float(prev[volume_col].mean())
        if v>0 and baseline>0:
            volume_ok=v>=baseline*1.15; volume_note=f'tick-activity proxy {v/baseline:.2f}x baseline'
    tol=max(float(x.atr14)*0.08,1e-12)
    recent=df.iloc[-7:]
    buy_fresh=float(df.close.iloc[-2])<=asian_high and float(x.close)>asian_high
    buy_retest=any(float(row.low)<=asian_high+tol and float(row.close)>asian_high for _,row in recent.iterrows())
    sell_fresh=float(df.close.iloc[-2])>=asian_low and float(x.close)<asian_low
    sell_retest=any(float(row.high)>=asian_low-tol and float(row.close)<asian_low for _,row in recent.iterrows())
    if x.close>asian_high and x.close>x.open and body>=avg*.35 and x.range>=avg*1.1 and volume_ok and (buy_fresh or buy_retest):
        return {'name':'SESSION_BREAKOUT','direction':'BUY','points':3,'reason':f'London/NY Asian-high breakout or retest confirmed by close, range expansion and {volume_note}'}
    if x.close<asian_low and x.close<x.open and body>=avg*.35 and x.range>=avg*1.1 and volume_ok and (sell_fresh or sell_retest):
        return {'name':'SESSION_BREAKOUT','direction':'SELL','points':3,'reason':f'London/NY Asian-low breakdown or retest confirmed by close, range expansion and {volume_note}'}
    return {'name':'SESSION_BREAKOUT','direction':'WAIT','points':0,'reason':f'No qualifying session close beyond Asian range; {volume_note}'}

def liquidity_smc(df):
    if len(df)<40: return {'name':'LIQUIDITY_SMC','direction':'WAIT','points':0,'reason':'Insufficient swing history'}
    x=df.iloc[-1]; prior=df.iloc[-31:-1]; hi=float(prior.high.max()); lo=float(prior.low.min()); avg=float(prior.high.sub(prior.low).mean())
    pools=liquidity_pools(df)
    equal_lows=pools['equal_lows']; equal_highs=pools['equal_highs']
    low_level=equal_lows[-1] if equal_lows else lo; high_level=equal_highs[-1] if equal_highs else hi
    swept_low=x.low<low_level and x.close>low_level and x.close>x.open and x.body>=avg*.45
    swept_high=x.high>high_level and x.close<high_level and x.close<x.open and x.body>=avg*.45
    if swept_low:
        label='equal-low pool' if equal_lows else 'prior swing-range low'
        return {'name':'LIQUIDITY_SMC','direction':'BUY','points':3,'reason':f'Sell-side liquidity sweep and reclaim at {label}; displacement-style bullish close'}
    if swept_high:
        label='equal-high pool' if equal_highs else 'prior swing-range high'
        return {'name':'LIQUIDITY_SMC','direction':'SELL','points':3,'reason':f'Buy-side liquidity sweep and reclaim at {label}; displacement-style bearish close'}
    # Objective displacement -> last opposite candle candidate -> retest of its range.
    hist=df.iloc[-26:-1]; mean_body=float(hist.body.mean()) if 'body' in hist else float((hist.close-hist.open).abs().mean())
    for i in range(len(df)-2,max(0,len(df)-12),-1):
        bar=df.iloc[i]; before=df.iloc[max(0,i-20):i]
        if len(before)<10: continue
        prior_hi=float(before.high.max()); prior_lo=float(before.low.min()); bdy=abs(float(bar.close)-float(bar.open))
        bullish=float(bar.close)>prior_hi and float(bar.close)>float(bar.open) and bdy>=mean_body*1.5
        bearish=float(bar.close)<prior_lo and float(bar.close)<float(bar.open) and bdy>=mean_body*1.5
        if not (bullish or bearish): continue
        opposite=None
        for j in range(i-1,max(-1,i-7),-1):
            candidate=df.iloc[j]
            if (bullish and candidate.close<candidate.open) or (bearish and candidate.close>candidate.open): opposite=candidate; break
        if opposite is None: continue
        zlo=float(opposite.low); zhi=float(opposite.high)
        touched=float(x.low)<=zhi and float(x.high)>=zlo
        if bullish and touched and x.close>zhi and x.close>x.open:
            return {'name':'LIQUIDITY_SMC','direction':'BUY','points':2,'reason':'Bullish displacement beyond prior range; last bearish candle zone retested and reclaimed (objective order-block candidate)'}
        if bearish and touched and x.close<zlo and x.close<x.open:
            return {'name':'LIQUIDITY_SMC','direction':'SELL','points':2,'reason':'Bearish displacement beyond prior range; last bullish candle zone retested and rejected (objective order-block candidate)'}
    return {'name':'LIQUIDITY_SMC','direction':'WAIT','points':0,'reason':'No confirmed liquidity sweep/reclaim or displacement-zone retest'}

def carry_context(macro):
    if not macro or not macro.get('rate_differential_available'):
        return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'No verified current policy-rate differential; carry context unavailable'}
    diff=macro.get('base_minus_quote_rate')
    if not isinstance(diff,(int,float)): return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'Rate differential is not numeric'}
    ydiff=macro.get('yield_differential')
    if not isinstance(ydiff,(int,float)):
        return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'Verified government-yield differential unavailable; carry confirmation withheld'}
    if diff*ydiff<=0:
        return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'Policy-rate and government-yield differentials conflict'}
    direction='BUY' if diff>0 else 'SELL'
    swap=macro.get('broker_swap_long' if direction=='BUY' else 'broker_swap_short')
    if macro.get('broker_swap_mode') != 'CURRENCY_DEPOSIT':
        return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'Broker swap units are not verified in account deposit currency; carry context withheld'}
    if swap is None or swap<=0:
        return {'name':'CARRY_CONTEXT','direction':'WAIT','points':0,'reason':'Policy/yield differential aligns, but positive broker-side swap is not verified'}
    return {'name':'CARRY_CONTEXT','direction':direction,'points':1,'reason':f'Policy-rate and government-yield differentials align; positive broker swap {swap}; macro context only, not an entry trigger'}

def evaluate_strategies(symbol, frames, session=None, macro=None):
    out=[]; session=session or {}; active=session.get('active_session','ASIAN_OR_OFF_SESSION')
    if symbol=='USDJPY': out += [trend_pullback(frames['H4']),trend_pullback(frames['H1']),carry_context(macro)]
    if symbol in ('GBPUSD','XAUUSD'):
        rng=session.get(symbol,{})
        out += [session_breakout(frames['M30'],rng.get('asian_high'),rng.get('asian_low'),active),session_breakout(frames['M15'],rng.get('asian_high'),rng.get('asian_low'),active)]
    if symbol=='XAUUSD': out.append(liquidity_smc(frames['M15']))
    # Research hypotheses for markets without a promoted primary strategy are visible to
    # the analysis/reporting layer but are explicitly marked research-only. The decision
    # engine must never count these observations as production evidence.
    if symbol in ('GBPJPY','USTECH100'):
        from .research_candidates import evaluate_candidate
        from .strategy_registry import market_strategies
        levels=session.get(symbol,{}) if isinstance(session,dict) else {}
        out.append({'name':'UNASSIGNED','direction':'WAIT','points':0,'reason':'No candidate has yet passed the production promotion gate','production_status':'RESEARCH_GATE'})
        for candidate in market_strategies(symbol):
            r=evaluate_candidate(symbol,candidate,frames,levels=levels,macro=macro)
            out.append(r)
    return out or [{'name':'UNASSIGNED','direction':'WAIT','points':0,'reason':'No market-specific strategy has been validated and assigned'}]
