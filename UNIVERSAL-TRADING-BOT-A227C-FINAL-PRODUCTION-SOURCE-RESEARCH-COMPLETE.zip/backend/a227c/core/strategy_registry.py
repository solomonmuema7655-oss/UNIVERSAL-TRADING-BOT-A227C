"""Single source of truth for A227C market/strategy coverage.

Every strategy in this registry is an executable deterministic research hypothesis.
A strategy becomes production-eligible only after the evidence/promotion gate proves it
on the exact provider symbol and data regime. Registry presence is NOT promotion.
"""
from __future__ import annotations

MARKETS = ("XAUUSD", "USTECH100", "GBPJPY", "GBPUSD", "USDJPY")

STRATEGY_REGISTRY = {
    "XAUUSD": {
        "primary": ("LIQUIDITY_SMC", "SESSION_BREAKOUT"),
        "research": (
            "LIQUIDITY_SMC", "SESSION_BREAKOUT", "SESSION_FAILED_BREAKOUT",
            "H1_TREND_M15_PULLBACK", "VOLATILITY_EXPANSION", "PRIOR_DAY_LIQUIDITY_SWEEP",
        ),
    },
    "USTECH100": {
        "primary": (),
        "research": (
            "US_OPEN_RANGE_BREAKOUT", "US_OPEN_FAILED_BREAKOUT", "OVERNIGHT_RANGE_BREAKOUT",
            "VOLATILITY_EXPANSION", "M15_TREND_PULLBACK", "PRIOR_DAY_LIQUIDITY_SWEEP",
        ),
    },
    "GBPJPY": {
        "primary": (),
        "research": (
            "ASIA_RANGE_LONDON_BREAKOUT", "ASIA_SWEEP_LONDON_RECLAIM",
            "H1_TREND_M15_PULLBACK", "VOLATILITY_BREAKOUT",
            "LIQUIDITY_SWEEP_CONTINUATION", "CARRY_FILTERED_TREND",
        ),
    },
    "GBPUSD": {
        "primary": ("SESSION_BREAKOUT",),
        "research": (
            "SESSION_BREAKOUT", "SESSION_FAILED_BREAKOUT", "H1_TREND_M15_PULLBACK",
            "VOLATILITY_EXPANSION", "PRIOR_DAY_LIQUIDITY_SWEEP",
        ),
    },
    "USDJPY": {
        "primary": ("TREND_PULLBACK", "CARRY_CONTEXT"),
        "research": (
            "TREND_PULLBACK", "CARRY_CONTEXT", "SESSION_BREAKOUT", "ASIA_SWEEP_LONDON_RECLAIM",
            "H1_TREND_M15_PULLBACK", "VOLATILITY_BREAKOUT", "LIQUIDITY_SWEEP_CONTINUATION",
            "CARRY_FILTERED_TREND",
        ),
    },
}


def market_strategies(symbol: str, mode: str = "research") -> tuple[str, ...]:
    if symbol not in STRATEGY_REGISTRY:
        return ()
    return tuple(STRATEGY_REGISTRY[symbol][mode])


def all_research_pairs() -> list[tuple[str, str]]:
    return [(symbol, strategy) for symbol in MARKETS for strategy in market_strategies(symbol)]
