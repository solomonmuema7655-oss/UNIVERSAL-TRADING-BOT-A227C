from __future__ import annotations


def duration_policy(symbol: str, strategy: str, timeframe: str) -> dict:
    """Deterministic starting policy; research can replace it with observed distributions.

    It is deliberately a bounded observation window, not a blind exit timer. Invalidation
    always supersedes the window and a new completed M15 candle triggers reassessment.
    """
    policies={
        ('USDJPY','TREND_PULLBACK','H1'):(2,8),
        ('USDJPY','TREND_PULLBACK','H4'):(1,4),
        ('GBPUSD','SESSION_BREAKOUT','M15'):(2,12),
        ('GBPUSD','SESSION_BREAKOUT','M30'):(2,8),
        ('XAUUSD','SESSION_BREAKOUT','M15'):(2,10),
        ('XAUUSD','SESSION_BREAKOUT','M30'):(2,7),
        ('XAUUSD','LIQUIDITY_SMC','M15'):(2,10),
    }
    lo,hi=policies.get((symbol,strategy,timeframe),(1,8))
    return {'min_bars':lo,'max_bars':hi,'timeframe':timeframe,'unit':'completed '+timeframe+' bars',
            'policy':'Observation window, not a blind timer; M15 invalidation and fresh analysis supersede it',
            'calibration_source':'A227C deterministic strategy policy; replace with validated walk-forward duration distribution when sufficient real history exists'}
