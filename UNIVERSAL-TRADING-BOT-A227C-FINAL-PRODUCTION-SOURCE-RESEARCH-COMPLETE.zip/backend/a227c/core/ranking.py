from __future__ import annotations


def rank_opportunities(snapshots: dict[str, dict]) -> list[dict]:
    ranked=[]
    for symbol, snap in snapshots.items():
        if symbol.startswith('DERIV:') or snap.get('direction') not in ('BUY','SELL'):
            continue
        score=float(snap.get('score',0) or 0)
        quality=snap.get('quality','WAIT')
        ranked.append({
            'symbol':symbol,
            'direction':snap.get('direction'),
            'score':round(score,1),
            'quality':quality,
            'ranking_basis':'Evidence score after all mandatory data, timeframe, strategy, news, spread and risk gates',
        })
    ranked.sort(key=lambda x:(x['score'], x['quality']), reverse=True)
    for i,item in enumerate(ranked,1): item['rank']=i
    return ranked
