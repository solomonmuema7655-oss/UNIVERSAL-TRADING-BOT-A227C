from __future__ import annotations
from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class RiskPlan:
    direction: str
    entry: float | None
    stop: float | None
    target: float | None
    risk_distance: float | None
    reward_distance: float | None
    rr: float | None
    valid: bool
    reason: str


def build_risk_plan(direction: str, frame, *, entry: float | None, spread: float | None,
                    atr_multiple: float = 1.5, target_multiple: float = 2.0,
                    min_rr: float = 1.20, max_spread_atr_fraction: float = 0.05) -> RiskPlan:
    if direction not in ("BUY", "SELL"):
        return RiskPlan(direction, entry, None, None, None, None, None, False, "No directional signal; no risk plan")
    if entry is None or entry <= 0:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "No valid entry reference")
    if frame is None or len(frame) == 0:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "No M15 risk frame")
    atr = float(frame.iloc[-1].get("atr14", 0) or 0)
    if atr <= 0 or atr != atr:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "ATR unavailable; SL cannot be established")
    # Prefer the most recent confirmed swing when it gives a sensible structural stop;
    # otherwise use the ATR floor. This is analysis only, never an order instruction.
    recent_low = float(frame.tail(20).low.min())
    recent_high = float(frame.tail(20).high.max())
    if direction == "BUY":
        structural = recent_low - 0.10 * atr
        stop = min(entry - atr_multiple * atr, structural) if structural < entry else entry - atr_multiple * atr
        target = entry + target_multiple * max(entry - stop, atr)
    else:
        structural = recent_high + 0.10 * atr
        stop = max(entry + atr_multiple * atr, structural) if structural > entry else entry + atr_multiple * atr
        target = entry - target_multiple * max(stop - entry, atr)
    risk = abs(entry - stop); reward = abs(target - entry)
    rr = reward / risk if risk > 0 else None
    if spread is None or spread < 0:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "Live spread unavailable; risk plan rejected")
    if spread > max_spread_atr_fraction * atr:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "Spread is too large for the current M15 ATR; no signal")
    if risk <= 0 or rr is None or rr < min_rr:
        return RiskPlan(direction, entry, None, None, None, None, None, False, "Risk/reward plan failed validation")
    return RiskPlan(direction, entry, stop, target, risk, reward, rr, True, "Validated analysis-only SL/TP reference")
