"""Executable deterministic research hypotheses for every A227C market.

These engines are intentionally separate from the production strategy evaluator.
They can generate BUY/SELL/WAIT research observations, but a research observation is
never a live signal unless the evidence registry has promoted that exact candidate.
"""
from __future__ import annotations
from .structure import structure_state, liquidity_pools
from .strategy_registry import market_strategies


def _wait(name, reason):
    return {'name': name, 'direction': 'WAIT', 'points': 0, 'reason': reason, 'production_status': 'RESEARCH_ONLY'}


def _result(name, direction, points, reason):
    return {'name': name, 'direction': direction, 'points': points, 'reason': reason, 'production_status': 'RESEARCH_ONLY'}


def _range_mean(df, n=20):
    if len(df) < n + 1: return None
    return float(df.iloc[-n-1:-1].high.sub(df.iloc[-n-1:-1].low).mean())


def asia_range_breakout(df, asian_high, asian_low, name='ASIA_RANGE_LONDON_BREAKOUT'):
    if len(df) < 30 or asian_high is None or asian_low is None: return _wait(name, 'Missing Asian range or history')
    x, prev = df.iloc[-1], df.iloc[-2]; avg = _range_mean(df)
    if avg is None: return _wait(name, 'Insufficient range baseline')
    if x.close > asian_high and prev.close <= asian_high and x.close > x.open and x.range >= avg * 1.15:
        return _result(name, 'BUY', 3, 'London-session close above Asian range with range expansion')
    if x.close < asian_low and prev.close >= asian_low and x.close < x.open and x.range >= avg * 1.15:
        return _result(name, 'SELL', 3, 'London-session close below Asian range with range expansion')
    return _wait(name, 'No qualifying Asian-range breakout')


def asia_sweep_reclaim(df, asian_high, asian_low, name='ASIA_SWEEP_LONDON_RECLAIM'):
    if len(df) < 20 or asian_high is None or asian_low is None: return _wait(name, 'Missing Asian range or history')
    x = df.iloc[-1]
    if x.low < asian_low and x.close > asian_low and x.close > x.open:
        return _result(name, 'BUY', 3, 'Sell-side sweep of Asian low followed by bullish reclaim')
    if x.high > asian_high and x.close < asian_high and x.close < x.open:
        return _result(name, 'SELL', 3, 'Buy-side sweep of Asian high followed by bearish reclaim')
    return _wait(name, 'No Asian liquidity sweep/reclaim')


def trend_pullback_mtf(h1, m15, name='H1_TREND_M15_PULLBACK'):
    if h1 is None or m15 is None or len(h1) < 205 or len(m15) < 40:
        return _wait(name, 'H1/M15 history insufficient')
    h, x = h1.iloc[-1], m15.iloc[-1]
    st = structure_state(h1); atr = float(x.atr14) if float(x.atr14) > 0 else 0.0
    if atr <= 0: return _wait(name, 'Invalid M15 ATR')
    if h.ema20 > h.ema50 > h.ema200 and st['state'] == 'BULLISH' and x.low <= x.ema20 + atr*.25 and x.close > x.ema20 and x.close > x.open:
        return _result(name, 'BUY', 3, 'H1 bullish structure with M15 EMA20 pullback/rejection')
    if h.ema20 < h.ema50 < h.ema200 and st['state'] == 'BEARISH' and x.high >= x.ema20 - atr*.25 and x.close < x.ema20 and x.close < x.open:
        return _result(name, 'SELL', 3, 'H1 bearish structure with M15 EMA20 pullback/rejection')
    return _wait(name, 'No aligned H1 trend and M15 pullback')


def volatility_breakout(df, name='VOLATILITY_BREAKOUT'):
    if len(df) < 60: return _wait(name, 'Insufficient volatility history')
    x = df.iloc[-1]; baseline = _range_mean(df)
    if baseline is None or baseline <= 0: return _wait(name, 'Invalid volatility baseline')
    prior = df.iloc[-21:-1]
    if x.range >= baseline * 1.8 and x.close > x.open and x.close >= float(prior.high.max()):
        return _result(name, 'BUY', 2, 'Range expansion above prior 20-bar high')
    if x.range >= baseline * 1.8 and x.close < x.open and x.close <= float(prior.low.min()):
        return _result(name, 'SELL', 2, 'Range expansion below prior 20-bar low')
    return _wait(name, 'No volatility expansion breakout')


def liquidity_continuation(df, name='LIQUIDITY_SWEEP_CONTINUATION'):
    if len(df) < 40: return _wait(name, 'Insufficient liquidity history')
    pools = liquidity_pools(df); x = df.iloc[-1]
    lows, highs = pools['equal_lows'], pools['equal_highs']
    if lows and x.low < lows[-1] and x.close > lows[-1] and x.close > x.open:
        return _result(name, 'BUY', 3, 'Sell-side liquidity sweep and bullish reclaim')
    if highs and x.high > highs[-1] and x.close < highs[-1] and x.close < x.open:
        return _result(name, 'SELL', 3, 'Buy-side liquidity sweep and bearish reclaim')
    return _wait(name, 'No objective liquidity sweep')


def carry_filtered_trend(df, macro, name='CARRY_FILTERED_TREND'):
    if not macro: return _wait(name, 'Carry context unavailable')
    base, y = macro.get('base_minus_quote_rate'), macro.get('yield_differential')
    if not isinstance(base, (int, float)) or not isinstance(y, (int, float)) or base*y <= 0:
        return _wait(name, 'Policy/yield differential unavailable or conflicting')
    x = df.iloc[-1]
    if base > 0 and x.ema20 > x.ema50 > x.ema200: return _result(name, 'BUY', 2, 'Positive carry/yield context aligned with bullish trend')
    if base < 0 and x.ema20 < x.ema50 < x.ema200: return _result(name, 'SELL', 2, 'Negative carry/yield context aligned with bearish trend')
    return _wait(name, 'Carry and trend are not aligned')


def us_open_range_breakout(df, opening_high, opening_low, name='US_OPEN_RANGE_BREAKOUT'):
    if len(df) < 30 or opening_high is None or opening_low is None: return _wait(name, 'Missing US opening range')
    x, p = df.iloc[-1], df.iloc[-2]
    if x.close > opening_high and p.close <= opening_high and x.close > x.open: return _result(name, 'BUY', 3, 'US opening-range upside breakout with completed close')
    if x.close < opening_low and p.close >= opening_low and x.close < x.open: return _result(name, 'SELL', 3, 'US opening-range downside breakout with completed close')
    return _wait(name, 'No opening-range breakout')


def us_failed_breakout(df, opening_high, opening_low, name='US_OPEN_FAILED_BREAKOUT'):
    if len(df) < 10 or opening_high is None or opening_low is None: return _wait(name, 'Missing opening range')
    x = df.iloc[-1]
    if x.high > opening_high and x.close < opening_high and x.close < x.open: return _result(name, 'SELL', 3, 'Failed upside opening-range break and bearish reclaim')
    if x.low < opening_low and x.close > opening_low and x.close > x.open: return _result(name, 'BUY', 3, 'Failed downside opening-range break and bullish reclaim')
    return _wait(name, 'No failed opening breakout')


def overnight_range_breakout(df, overnight_high, overnight_low, name='OVERNIGHT_RANGE_BREAKOUT'):
    return asia_range_breakout(df, overnight_high, overnight_low, name)


def prior_day_liquidity_sweep(df, day_high, day_low, name='PRIOR_DAY_LIQUIDITY_SWEEP'):
    if len(df) < 5 or day_high is None or day_low is None: return _wait(name, 'Missing prior-day levels')
    x = df.iloc[-1]
    if x.low < day_low and x.close > day_low and x.close > x.open: return _result(name, 'BUY', 3, 'Prior-day low sweep and bullish reclaim')
    if x.high > day_high and x.close < day_high and x.close < x.open: return _result(name, 'SELL', 3, 'Prior-day high sweep and bearish rejection')
    return _wait(name, 'No prior-day liquidity sweep')


def session_failed_breakout(df, asian_high, asian_low, name='SESSION_FAILED_BREAKOUT'):
    return us_failed_breakout(df, asian_high, asian_low, name)


def evaluate_candidate(symbol, candidate, frames, levels=None, macro=None):
    levels = levels or {}; macro = macro or {}
    m15, h1 = frames.get('M15'), frames.get('H1')
    if candidate not in market_strategies(symbol):
        return _wait(candidate, f'{candidate} is not registered for {symbol}')
    if candidate == 'H1_TREND_M15_PULLBACK' or candidate == 'M15_TREND_PULLBACK':
        return trend_pullback_mtf(h1, m15, candidate)
    df = m15 if m15 is not None else h1
    if df is None: return _wait(candidate, 'Required frame unavailable')
    if candidate in ('ASIA_RANGE_LONDON_BREAKOUT',): return asia_range_breakout(df, levels.get('asian_high'), levels.get('asian_low'), candidate)
    if candidate in ('ASIA_SWEEP_LONDON_RECLAIM',): return asia_sweep_reclaim(df, levels.get('asian_high'), levels.get('asian_low'), candidate)
    if candidate == 'VOLATILITY_BREAKOUT': return volatility_breakout(df, candidate)
    if candidate == 'VOLATILITY_EXPANSION': return volatility_breakout(df, candidate)
    if candidate == 'LIQUIDITY_SWEEP_CONTINUATION': return liquidity_continuation(df, candidate)
    if candidate == 'CARRY_FILTERED_TREND': return carry_filtered_trend(h1 if h1 is not None else df, macro, candidate)
    if candidate == 'US_OPEN_RANGE_BREAKOUT': return us_open_range_breakout(df, levels.get('us_open_high'), levels.get('us_open_low'), candidate)
    if candidate == 'US_OPEN_FAILED_BREAKOUT': return us_failed_breakout(df, levels.get('us_open_high'), levels.get('us_open_low'), candidate)
    if candidate == 'OVERNIGHT_RANGE_BREAKOUT': return overnight_range_breakout(df, levels.get('overnight_high'), levels.get('overnight_low'), candidate)
    if candidate == 'PRIOR_DAY_LIQUIDITY_SWEEP': return prior_day_liquidity_sweep(df, levels.get('prior_day_high'), levels.get('prior_day_low'), candidate)
    if candidate == 'SESSION_BREAKOUT': return asia_range_breakout(df, levels.get('asian_high'), levels.get('asian_low'), candidate)
    if candidate == 'SESSION_FAILED_BREAKOUT': return session_failed_breakout(df, levels.get('asian_high'), levels.get('asian_low'), candidate)
    if candidate == 'LIQUIDITY_SMC': return liquidity_continuation(df, candidate)
    if candidate == 'TREND_PULLBACK': return trend_pullback_mtf(h1, m15, candidate)
    return _wait(candidate, 'No deterministic implementation registered')
