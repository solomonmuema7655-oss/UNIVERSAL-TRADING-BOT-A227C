"""Deterministic MT5 broker-symbol discovery; never silently guesses a mapping.

USTECH100 is intentionally special-cased because Exness documents both USTEC and
USTEC_x100 with different contract sizes. A227C accepts either only when the live
terminal proves which exact contract is present; if both are available the mapping is
ambiguous and production startup must stop until the intended contract is selected.
"""
from __future__ import annotations

EXPECTED={
    'XAUUSD':('xauusd','gold'),
    'USTECH100':('ustec','ustec_x100','nasdaq-100','nasdaq 100','ustech100'),
    'GBPJPY':('gbpjpy',), 'GBPUSD':('gbpusd',), 'USDJPY':('usdjpy',)
}
USTEC_VARIANTS={'ustec':1,'ustec_x100':100}


def score_symbol(internal, info):
    name=str(getattr(info,'name','')).lower(); desc=str(getattr(info,'description','')).lower(); path=str(getattr(info,'path','')).lower()
    hay=' '.join((name,desc,path)); score=0
    for token in EXPECTED.get(internal,()):
        if token==name: score+=100
        elif token in name: score+=60
        elif token in hay: score+=20
    if internal=='USTECH100' and ('indices' in path or 'index' in desc): score+=10
    return score


def discover(internal, infos):
    ranked=sorted(((score_symbol(internal,x),str(getattr(x,'name',''))) for x in infos),reverse=True)
    ranked=[x for x in ranked if x[0]>0]
    if not ranked: return {'status':'UNRESOLVED','internal_symbol':internal,'candidates':[]}
    # Never silently choose between Exness USTEC contracts.
    if internal=='USTECH100':
        variants=[x for x in ranked if x[1].lower() in USTEC_VARIANTS]
        if len(variants)>1:
            return {'status':'AMBIGUOUS','internal_symbol':internal,'reason':'Both USTEC and USTEC_x100 are present; contract selection is required',
                    'candidates':variants,'allowed_variants':USTEC_VARIANTS}
        if len(variants)==1:
            score,name=variants[0]
            return {'status':'RESOLVED_CANDIDATE','internal_symbol':internal,'provider_symbol':name,'provider_variant':name.lower(),
                    'contract_size_expected':USTEC_VARIANTS[name.lower()],'score':score,'candidates':ranked}
    best=ranked[0]; ties=[x for x in ranked if x[0]==best[0]]
    if len(ties)>1 or best[0]<60:
        return {'status':'AMBIGUOUS','internal_symbol':internal,'candidates':ranked}
    return {'status':'RESOLVED_CANDIDATE','internal_symbol':internal,'provider_symbol':best[1],'score':best[0],'candidates':ranked}
