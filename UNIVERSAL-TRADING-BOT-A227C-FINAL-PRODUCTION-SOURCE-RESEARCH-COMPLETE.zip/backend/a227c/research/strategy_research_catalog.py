"""Research catalogue and evidence requirements for all five A227C markets.

This is deliberately explicit: no market is silently left without a research path,
and no research candidate is silently promoted into live signal generation.
"""
from __future__ import annotations
from ..core.strategy_registry import MARKETS, market_strategies

EVIDENCE_REQUIREMENTS = {
    "provider_symbol": "Exact MT5/Exness symbol discovered and verified from the live terminal",
    "historical_quotes": "Real provider historical Bid/Ask or an explicitly documented broker-data source",
    "timeframes": "H4/H1/M30/M15 with UTC-normalized timestamps",
    "costs": "Observed/calibrated spread plus commission/slippage assumptions with provenance",
    "news": "Point-in-time event data where the strategy is news-sensitive",
    "financing": "Historical broker swap ledger for strategies exposed to overnight financing",
    "tick_replay": "Quote-level replay for finalists; OHLC-only evidence is not sufficient for promotion",
    "walk_forward": "Chronological development folds plus separate final holdout",
    "selection_bias": "PBO/CSCV and Deflated Sharpe analysis across the tested candidate family",
    "shadow": "Live read-only shadow observations after historical promotion and before production eligibility",
}


def research_plan() -> dict:
    return {
        "markets": {
            symbol: {
                "research_strategies": list(market_strategies(symbol)),
                "production_primary": list(market_strategies(symbol, "primary")),
                "status": "RESEARCH_REQUIRED" if not market_strategies(symbol, "primary") else "PRIMARY_EXISTS_BUT_REQUIRES_REVALIDATION",
            }
            for symbol in MARKETS
        },
        "evidence_requirements": dict(EVIDENCE_REQUIREMENTS),
        "promotion": "No candidate is production eligible until every required evidence layer passes.",
    }
