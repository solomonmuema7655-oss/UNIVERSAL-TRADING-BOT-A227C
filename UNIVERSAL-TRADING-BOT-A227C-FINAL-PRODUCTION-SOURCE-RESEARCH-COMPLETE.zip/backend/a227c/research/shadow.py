"""Live shadow-validation ledger. It records observations but never trades."""
from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone

class ShadowLedger:
    def __init__(self,path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def append(self,event):
        row=dict(event); row['recorded_at_utc']=datetime.now(timezone.utc).isoformat()
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,default=str)+'\n')
    def count(self):
        if not self.path.exists(): return 0
        return sum(1 for _ in self.path.open(encoding='utf-8'))
