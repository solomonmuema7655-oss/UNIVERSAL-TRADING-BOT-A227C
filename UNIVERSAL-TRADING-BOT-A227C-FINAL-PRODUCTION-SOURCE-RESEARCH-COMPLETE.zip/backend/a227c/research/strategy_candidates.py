"""Promotion rules and complete candidate matrix for all five markets."""
from __future__ import annotations
from ..core.strategy_registry import MARKETS, market_strategies

PROMOTION_RULES = {
    'min_development_trades': 100,
    'min_oos_folds': 4,
    'min_positive_oos_folds_fraction': 0.75,
    'max_pbo': 0.25,
    'min_dsr_probability': 0.95,
    'require_final_holdout': True,
    'require_tick_replay': True,
    'require_live_shadow': True,
    'exact_provider_symbol_required': True,
    'point_in_time_macro_required_when_used': True,
    'historical_financing_required_when_overnight_exposure_exists': True,
}


def candidate_matrix(symbol):
    return list(market_strategies(symbol))


def complete_matrix():
    return {s: candidate_matrix(s) for s in MARKETS}
