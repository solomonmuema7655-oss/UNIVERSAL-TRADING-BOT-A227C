"""Generic chronological screening engine for every registered research candidate.

It is intentionally a screening engine, not the final promotion engine. Signals are
formed from completed M15 candles and derived completed H1 candles. It uses deterministic
session/previous-day levels, explicit costs, conservative stop-first OHLC resolution and
never generates broker orders.
"""
from __future__ import annotations
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from ..core.indicators import enrich
from ..core.research_candidates import evaluate_candidate

UTC = ZoneInfo('UTC')
TOKYO = ZoneInfo('Asia/Tokyo')
LONDON = ZoneInfo('Europe/London')
NEW_YORK = ZoneInfo('America/New_York')


def _levels(hist: pd.DataFrame, symbol: str) -> dict:
    idx = hist.index
    ts = idx[-1].to_pydatetime().astimezone(UTC)
    tokyo = pd.Series(idx.tz_convert(TOKYO).date, index=idx)
    ny = pd.Series(idx.tz_convert(NEW_YORK).date, index=idx)
    ny_hour = pd.Series(idx.tz_convert(NEW_YORK).hour, index=idx)
    ny_minute = pd.Series(idx.tz_convert(NEW_YORK).minute, index=idx)
    day_tokyo = ts.astimezone(TOKYO).date()
    day_ny = ts.astimezone(NEW_YORK).date()
    asian = hist[(tokyo == day_tokyo) & (pd.Series(idx.tz_convert(TOKYO).hour,index=idx) >= 0) & (pd.Series(idx.tz_convert(TOKYO).hour,index=idx) < 8)]
    opening = hist[(ny == day_ny) & (ny_hour == 9) & (ny_minute >= 30)]
    out = {}
    if len(asian):
        out['asian_high'], out['asian_low'] = float(asian.high.max()), float(asian.low.min())
        out['overnight_high'], out['overnight_low'] = out['asian_high'], out['asian_low']
    if len(opening):
        out['us_open_high'], out['us_open_low'] = float(opening.high.max()), float(opening.low.min())
    prior = hist[ny < day_ny]
    if len(prior):
        prior_date = max(ny.loc[prior.index])
        pdrows = prior[ny.loc[prior.index] == prior_date]
        out['prior_day_high'], out['prior_day_low'] = float(pdrows.high.max()), float(pdrows.low.min())
    return out


def _frames(hist: pd.DataFrame) -> dict:
    m15 = hist
    h1 = hist.resample('1h', label='right', closed='right').agg({'open':'first','high':'max','low':'min','close':'last'}).dropna()
    return {'M15': enrich(m15), 'H1': enrich(h1)}


def _metrics(trades):
    rs=[t['r_multiple'] for t in trades]
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<0]
    equity=peak=dd=0.0; streak=longest=0
    for r in rs:
        equity += r; peak=max(peak,equity); dd=max(dd,peak-equity)
        if r<0: streak+=1; longest=max(longest,streak)
        elif r>0: streak=0
    return {
        'trades':len(rs), 'wins':len(wins), 'losses':len(losses),
        'win_rate_pct':round(100*len(wins)/len(rs),2) if rs else None,
        'expectancy_r':round(float(np.mean(rs)),4) if rs else None,
        'profit_factor':round(sum(wins)/abs(sum(losses)),4) if losses else (None if not wins else 'infinite'),
        'max_drawdown_r':round(dd,4), 'longest_consecutive_losses':longest,
    }



def _precompute_levels(frame: pd.DataFrame):
    idx=frame.index
    tok=idx.tz_convert(TOKYO); ny=idx.tz_convert(NEW_YORK)
    tok_date=pd.Series(tok.date,index=idx); tok_hour=pd.Series(tok.hour,index=idx)
    ny_date=pd.Series(ny.date,index=idx); ny_hour=pd.Series(ny.hour,index=idx); ny_min=pd.Series(ny.minute,index=idx)
    # Completed fixed session ranges. A row is allowed to use a range only after its end.
    asian_mask=(tok_hour>=0)&(tok_hour<8)
    asian=frame.loc[asian_mask].groupby(tok_date.loc[asian_mask]).agg(high=('high','max'),low=('low','min'))
    us_mask=(ny_hour==9)&(ny_min>=30)
    us=frame.loc[us_mask].groupby(ny_date.loc[us_mask]).agg(high=('high','max'),low=('low','min'))
    daily=frame.groupby(ny_date).agg(high=('high','max'),low=('low','min'))
    return tok,ny,tok_date,ny_date,ny_hour,ny_min,asian,us,daily


def _levels_fast(ts, pre):
    tok,ny,tok_date,ny_date,ny_hour,ny_min,asian,us,daily=pre
    t=ts.to_pydatetime().astimezone(UTC)
    td=t.astimezone(TOKYO).date(); nd=t.astimezone(NEW_YORK).date()
    out={}
    # Tokyo range is usable only after 08:00 Tokyo.
    if t.astimezone(TOKYO).hour >= 8 and td in asian.index:
        out['asian_high']=float(asian.loc[td,'high']); out['asian_low']=float(asian.loc[td,'low'])
        out['overnight_high']=out['asian_high']; out['overnight_low']=out['asian_low']
    # 09:30-10:00 New York opening range is usable only after 10:00.
    local=t.astimezone(NEW_YORK)
    if local.hour >= 10 and nd in us.index:
        out['us_open_high']=float(us.loc[nd,'high']); out['us_open_low']=float(us.loc[nd,'low'])
    prev_days=[d for d in daily.index if d < nd]
    if prev_days:
        pdx=max(prev_days); out['prior_day_high']=float(daily.loc[pdx,'high']); out['prior_day_low']=float(daily.loc[pdx,'low'])
    return out

def run_candidate_screen(frame: pd.DataFrame, symbol: str, candidate: str, spread_cost: float,
                         commission_price_units: float=0.0, slippage_price_units: float=0.0,
                         max_holding_bars: int=48, start: int=250, end: int|None=None):
    if spread_cost <= 0: raise ValueError('A positive full-spread assumption is required')
    if commission_price_units < 0 or slippage_price_units < 0: raise ValueError('Costs cannot be negative')
    data=enrich(frame.sort_index())
    if len(data) < start+20: raise ValueError('Insufficient M15 history for candidate screening')
    end=len(data)-1 if end is None else min(end,len(data)-1)
    h1_full=enrich(data.resample('1h',label='right',closed='right').agg({'open':'first','high':'max','low':'min','close':'last'}).dropna())
    pre_levels=_precompute_levels(data)
    trades=[]; i=start
    while i < end-1:
        hist=data.iloc[:i+1]
        h1_hist=h1_full.loc[:data.index[i]]
        fr={'M15':hist,'H1':h1_hist}
        levels=_levels_fast(data.index[i],pre_levels)
        sig=evaluate_candidate(symbol,candidate,fr,levels=levels)
        direction=sig['direction']
        if direction not in ('BUY','SELL'):
            i+=1; continue
        entry_bar=data.iloc[i+1]; atr=float(entry_bar.atr14)
        if not np.isfinite(atr) or atr<=0:
            i+=1; continue
        half=spread_cost/2
        entry=float(entry_bar.open + half if direction=='BUY' else entry_bar.open-half) + (slippage_price_units/2 if direction=='BUY' else -slippage_price_units/2)
        risk=1.5*atr; stop=entry-risk if direction=='BUY' else entry+risk; target=entry+2*atr if direction=='BUY' else entry-2*atr
        exit_price=None; exit_i=None; reason='TIME_EXIT'; mae=mfe=0.0
        last=min(end,i+1+max_holding_bars)
        for j in range(i+1,last+1):
            b=data.iloc[j]
            if direction=='BUY':
                mae=max(mae,max(0,entry-float(b.low))/risk); mfe=max(mfe,max(0,float(b.high)-entry)/risk)
                stop_hit=float(b.low)<=stop; target_hit=float(b.high)>=target
                if stop_hit:
                    exit_price=stop-slippage_price_units/2; exit_i=j; reason='STOP' if not target_hit else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if target_hit:
                    exit_price=target-slippage_price_units/2; exit_i=j; reason='TARGET'; break
                if j==last: exit_price=float(b.close)-slippage_price_units/2; exit_i=j
            else:
                mae=max(mae,max(0,float(b.high)-entry)/risk); mfe=max(mfe,max(0,entry-float(b.low))/risk)
                stop_hit=float(b.high)>=stop; target_hit=float(b.low)<=target
                if stop_hit:
                    exit_price=stop+slippage_price_units/2; exit_i=j; reason='STOP' if not target_hit else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if target_hit:
                    exit_price=target+slippage_price_units/2; exit_i=j; reason='TARGET'; break
                if j==last: exit_price=float(b.close)+slippage_price_units/2; exit_i=j
        pnl=((exit_price-entry) if direction=='BUY' else (entry-exit_price))-commission_price_units
        trades.append({'signal_time':str(data.index[i]),'entry_time':str(data.index[i+1]),'exit_time':str(data.index[exit_i]),
                       'direction':direction,'r_multiple':round(pnl/risk,5),'mae_r':round(mae,5),'mfe_r':round(mfe,5),
                       'holding_bars':int(exit_i-i),'exit_reason':reason,'strategy_reason':sig['reason']})
        i=exit_i+1
    return {'symbol':symbol,'candidate':candidate,'timeframe':'M15','execution_model':'OHLC screening; BUY uses ask-side entry / bid-side exit approximation; SELL inverse',
            'costs':{'spread_price_units':spread_cost,'commission_round_turn_price_units':commission_price_units,'slippage_round_turn_price_units':slippage_price_units},
            'metrics':_metrics(trades),'trades':trades,'promotion_status':'NOT_PROMOTED'}
