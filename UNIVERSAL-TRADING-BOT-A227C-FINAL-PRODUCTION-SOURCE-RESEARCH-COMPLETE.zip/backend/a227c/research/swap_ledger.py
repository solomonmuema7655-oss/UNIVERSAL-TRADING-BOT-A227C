"""Historical broker-swap ledger. No current snapshot is backfilled into history."""
from __future__ import annotations
import pandas as pd

REQUIRED={'date','symbol','long','short','unit','triple_day','source','observed_at_utc'}

def load_swap_ledger(path):
    df=pd.read_csv(path)
    missing=REQUIRED-set(df.columns)
    if missing: raise ValueError(f'Missing swap ledger columns: {sorted(missing)}')
    df['date']=pd.to_datetime(df.date,utc=True,errors='raise').dt.date
    df['observed_at_utc']=pd.to_datetime(df.observed_at_utc,utc=True,errors='raise')
    if (df[['long','short']].apply(pd.to_numeric,errors='coerce').isna()).any().any(): raise ValueError('Swap values must be numeric')
    if (df['unit'].str.upper()=='CURRENT_SNAPSHOT_ONLY_NOT_HISTORICAL').any():
        raise ValueError('Current contract snapshots cannot be used as historical swap observations')
    return df.sort_values(['symbol','date','observed_at_utc'])

def accrue(rate, nights, triple=False):
    return float(rate)*float(nights)*(3.0 if triple else 1.0)
