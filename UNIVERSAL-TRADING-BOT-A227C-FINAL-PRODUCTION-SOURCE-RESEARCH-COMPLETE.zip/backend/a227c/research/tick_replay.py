"""Quote-level execution replay for A227C research.

Signals are generated only at completed-bar timestamps. Tick replay then resolves
entry, stop, target and expiry against subsequent bid/ask ticks, eliminating the
bar-level same-candle ambiguity that existed in the earlier research engine.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable
import pandas as pd

@dataclass
class ReplaySignal:
    timestamp: pd.Timestamp
    direction: str
    entry: float
    stop: float
    target: float
    max_hold_seconds: int
    signal_id: str=''

@dataclass
class ReplayTrade:
    signal_id: str
    direction: str
    signal_time: str
    entry_time: str|None
    exit_time: str|None
    entry: float|None
    exit: float|None
    stop: float
    target: float
    exit_reason: str
    r_multiple: float|None
    duration_seconds: float|None


def replay_ticks(ticks: pd.DataFrame, signals: Iterable[ReplaySignal]):
    required={'timestamp','bid','ask'}
    if not required.issubset(ticks.columns): raise ValueError(f'ticks must contain {required}')
    t=ticks.copy(); t['timestamp']=pd.to_datetime(t['timestamp'],utc=True); t=t.sort_values('timestamp')
    if (t[['bid','ask']]<=0).any().any() or (t.ask<t.bid).any(): raise ValueError('Invalid tick quotes')
    rows=[]
    for sig in sorted(signals,key=lambda s:pd.Timestamp(s.timestamp)):
        ts=pd.Timestamp(sig.timestamp); direction=sig.direction.upper()
        if direction not in ('BUY','SELL') or sig.stop is None or sig.target is None: continue
        future=t[t.timestamp>=ts]
        if future.empty: continue
        entry=None; entry_ts=None; exit=None; exit_ts=None; reason='EXPIRED'
        for row in future.itertuples(index=False):
            price=float(row.ask if direction=='BUY' else row.bid)
            if entry is None:
                entry=price; entry_ts=pd.Timestamp(row.timestamp)
                # A signal entry is accepted at the first quote after publication.
                continue
            elapsed=(pd.Timestamp(row.timestamp)-entry_ts).total_seconds()
            if direction=='BUY':
                if float(row.bid)<=sig.stop: exit=float(row.bid); exit_ts=pd.Timestamp(row.timestamp); reason='STOP'; break
                if float(row.bid)>=sig.target: exit=float(row.bid); exit_ts=pd.Timestamp(row.timestamp); reason='TARGET'; break
            else:
                if float(row.ask)>=sig.stop: exit=float(row.ask); exit_ts=pd.Timestamp(row.timestamp); reason='STOP'; break
                if float(row.ask)<=sig.target: exit=float(row.ask); exit_ts=pd.Timestamp(row.timestamp); reason='TARGET'; break
            if elapsed>=sig.max_hold_seconds:
                exit=price; exit_ts=pd.Timestamp(row.timestamp); reason='MAX_HOLD'; break
        if entry is not None and exit is not None:
            risk=abs(sig.entry-sig.stop)
            pnl=(exit-entry) if direction=='BUY' else (entry-exit)
            r=pnl/risk if risk>0 else None
        else: r=None
        rows.append(asdict(ReplayTrade(sig.signal_id,direction,ts.isoformat(),entry_ts.isoformat() if entry_ts else None,
            exit_ts.isoformat() if exit_ts else None,entry,exit,float(sig.stop),float(sig.target),reason,r,
            (exit_ts-entry_ts).total_seconds() if entry_ts and exit_ts else None)))
    return pd.DataFrame(rows)
