"""Empirical holding-window calibration from completed research trades."""
from __future__ import annotations
import numpy as np

def calibrate_durations(trades, min_success=30):
    """Return conservative observed-duration quantiles; never invents data."""
    durations=[float(t) for t in trades if t is not None and float(t)>=0]
    if len(durations)<min_success:
        return {'status':'BLOCKED_INSUFFICIENT_REAL_OUTCOMES','n':len(durations),'required':min_success}
    a=np.asarray(durations,float)
    return {'status':'CALIBRATED','n':int(len(a)),'p25':float(np.quantile(a,.25)),
            'median':float(np.quantile(a,.50)),'p75':float(np.quantile(a,.75)),
            'p90':float(np.quantile(a,.90)),'max':float(a.max()),
            'policy':'Observation window derived from real out-of-sample outcomes; invalidation always supersedes.'}
