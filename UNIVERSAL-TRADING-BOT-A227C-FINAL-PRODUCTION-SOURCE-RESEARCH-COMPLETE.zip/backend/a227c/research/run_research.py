"""Run the A227C fixed-rule research matrix across all five markets.

The runner never invents market data. Missing exact-provider datasets, costs, point-in-time
news/macro inputs, or quote-level history produce BLOCKED records. Unit-test fixtures are
not accepted as research datasets.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import pandas as pd
from .mt5_history_export import validate_ohlc
from .backtest import walk_forward
from .candidate_backtest import run_candidate_screen
from .strategy_candidates import complete_matrix


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()


def load_dataset(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if 'time_utc' not in frame.columns: raise ValueError('CSV must contain time_utc column')
    frame['time_utc'] = pd.to_datetime(frame['time_utc'], utc=True, errors='raise')
    frame = frame.set_index('time_utc').sort_index()
    if frame.index.has_duplicates: raise ValueError('Duplicate timestamps are not allowed')
    validate_ohlc(frame)
    return frame


def run(data_dir: Path, output: Path, costs: dict, train_fraction=.6, folds=4):
    results, datasets = [], {}
    matrix = complete_matrix()
    for symbol, candidates in matrix.items():
        for strategy in candidates:
            timeframes = ('H1', 'H4') if strategy == 'TREND_PULLBACK' and symbol == 'USDJPY' else ('M15',)
            for timeframe in timeframes:
                key = f'{symbol}_{timeframe}'
                path = data_dir / f'{key}.csv'
                bid_path = data_dir / f'{key}_BID.csv'
                ask_path = data_dir / f'{key}_ASK.csv'
                if not path.exists() and not (bid_path.exists() and ask_path.exists()):
                    results.append({'symbol':symbol,'timeframe':timeframe,'strategy':strategy,'status':'BLOCKED_MISSING_REAL_DATASET'})
                    continue
                try:
                    cost = costs.get(key, {})
                    required = ('commission_round_turn_price_units','slippage_round_turn_price_units','commission_basis','slippage_basis')
                    missing = [f for f in required if f not in cost or cost[f] in ('', None)]
                    if missing:
                        raise ValueError(f'Missing explicit commission/slippage cost evidence: {missing}')
                    ask_frame = None
                    spread = None
                    quote_source = 'FIXED_SPREAD_ASSUMPTION'
                    if bid_path.exists() and ask_path.exists():
                        frame = load_dataset(bid_path)
                        ask_frame = load_dataset(ask_path)
                        if not frame.index.equals(ask_frame.index):
                            raise ValueError('Bid/ask timestamps do not match')
                        quote_source = 'EXNESS_HISTORICAL_BID_ASK_ARCHIVE'
                        spread = float((ask_frame.close - frame.close).median())
                        if spread <= 0: raise ValueError('Observed bid/ask history has no positive spread')
                        datasets[key] = {'bid_sha256':sha256(bid_path),'ask_sha256':sha256(ask_path),'bars':len(frame),
                                         'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}
                    else:
                        frame = load_dataset(path)
                        spread = float(cost.get('spread_price_units',0))
                        if spread <= 0:
                            raise ValueError('Positive spread or observed bid/ask history is required')
                        datasets[key] = {'sha256':sha256(path),'bars':len(frame),
                                         'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}

                    if strategy == 'TREND_PULLBACK' and symbol == 'USDJPY' and timeframe in ('H1','H4'):
                        report = walk_forward(frame,strategy,symbol,timeframe,spread,train_fraction=train_fraction,folds=folds,
                                              commission_price_units=float(cost.get('commission_round_turn_price_units',0)),
                                              slippage_price_units=float(cost.get('slippage_round_turn_price_units',0)),ask_frame=ask_frame)
                    elif timeframe == 'M15' and strategy != 'CARRY_CONTEXT':
                        report = run_candidate_screen(frame,symbol,strategy,spread_cost=float(spread),
                                                      commission_price_units=float(cost.get('commission_round_turn_price_units',0)),
                                                      slippage_price_units=float(cost.get('slippage_round_turn_price_units',0)))
                    else:
                        raise ValueError('Macro/carry candidate requires point-in-time macro dataset and dedicated financing replay adapter')
                    results.append({'symbol':symbol,'timeframe':timeframe,'strategy':strategy,'status':'SIMULATED_REAL_HISTORY',
                                    'quote_source':quote_source,'dataset':datasets[key],'cost_assumptions':cost,'report':report})
                except Exception as exc:
                    results.append({'symbol':symbol,'timeframe':timeframe,'strategy':strategy,
                                    'status':'BLOCKED_INVALID_OR_INSUFFICIENT_DATA','error':str(exc)})
    payload = {'schema_version':3,'research_type':'A227C_COMPLETE_FIVE_MARKET_FIXED_RULE_MATRIX',
               'created_at_utc':pd.Timestamp.now(tz='UTC').isoformat(),'matrix':matrix,
               'datasets':datasets,'results':results,
               'policy':'No synthetic fallback. Every missing evidence layer blocks promotion. Research-only candidates are not live signals.',
               'not_a_profitability_claim':True}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload,indent=2,default=str),encoding='utf-8')
    return payload


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--data',required=True); p.add_argument('--costs',required=True); p.add_argument('--output',default='research_data/a227c_research_report.json'); p.add_argument('--folds',type=int,default=4)
    a=p.parse_args(); costs=json.loads(Path(a.costs).read_text(encoding='utf-8')); report=run(Path(a.data),Path(a.output),costs,folds=a.folds)
    print(json.dumps({'output':a.output,'markets':list(report['matrix']),'result_count':len(report['results'])},indent=2))
if __name__=='__main__': main()
