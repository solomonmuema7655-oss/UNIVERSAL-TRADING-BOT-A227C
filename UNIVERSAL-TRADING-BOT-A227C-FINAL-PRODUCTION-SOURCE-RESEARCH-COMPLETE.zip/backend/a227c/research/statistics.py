"""Research statistics used for selection-bias-aware A227C validation.

No profitability claim is made by these functions. They are diagnostics for research
selection and uncertainty only.
"""
from __future__ import annotations
import itertools, math
import numpy as np


def _clean(x):
    a=np.asarray(x,dtype=float)
    return a[np.isfinite(a)]


def sharpe(returns, annualization=1.0):
    r=_clean(returns)
    if r.size<2: return float('nan')
    sd=float(np.std(r,ddof=1))
    return float(np.mean(r)/sd*math.sqrt(annualization)) if sd>0 else float('nan')


def probabilistic_sharpe_ratio(observed_sr, benchmark_sr, n, skew=0.0, kurtosis=3.0):
    """Bailey/Lopez de Prado PSR approximation; returns probability observed SR > benchmark."""
    if not np.isfinite(observed_sr) or n<2: return float('nan')
    denom=math.sqrt(max(1e-15,(1-skew*observed_sr+(kurtosis-1)*observed_sr**2)/max(n-1,1)))
    z=(observed_sr-benchmark_sr)/denom
    return float(0.5*(1+math.erf(z/math.sqrt(2))))


def deflated_sharpe_ratio(returns, trials, benchmark_sr=0.0, annualization=1.0):
    """Compute a DSR-style statistic using the expected maximum Sharpe threshold.

    The implementation follows the selection-bias logic of Bailey & Lopez de Prado:
    estimate the expected maximum SR across trials, then report the PSR against that
    threshold. The exact threshold depends on the trial-return distribution, so the
    result is a diagnostic rather than a proof of robustness.
    """
    r=_clean(returns)
    n=r.size
    if n<3 or trials<1: return {'status':'INSUFFICIENT_DATA'}
    sr=sharpe(r,annualization)
    s=float(np.mean(((r-r.mean())/max(r.std(ddof=1),1e-15))**3))
    k=float(np.mean(((r-r.mean())/max(r.std(ddof=1),1e-15))**4))
    # Euler approximation for expected maximum of iid normal-like SR estimates.
    t=max(int(trials),1)
    if t==1:
        emax=0.0
    else:
        q=1.0-1.0/t
        # inverse normal via Acklam-style approximation using scipy-free bisection.
        lo,hi=-8.0,8.0
        for _ in range(80):
            m=(lo+hi)/2
            cdf=0.5*(1+math.erf(m/math.sqrt(2)))
            if cdf<q: lo=m
            else: hi=m
        z=(lo+hi)/2
        emax=z/math.sqrt(max(n-1,1))
    psr=probabilistic_sharpe_ratio(sr,max(benchmark_sr,emax),n,s,k)
    return {'status':'OK','observed_sharpe':sr,'expected_max_sharpe':emax,
            'benchmark_sharpe':benchmark_sr,'probability_exceeds_deflated_benchmark':psr,
            'trials':t,'n_observations':n,'skew':s,'kurtosis':k}


def cscv_pbo(strategy_returns, partitions=8):
    """Combinatorially Symmetric Cross-Validation estimate of PBO.

    Input shape: observations x candidate-strategies. Each partition is chronological.
    For each half-sample combination, choose the best in-sample candidate and measure
    its OOS rank. PBO is the fraction with negative logit rank.
    """
    x=np.asarray(strategy_returns,dtype=float)
    if x.ndim!=2: raise ValueError('strategy_returns must be 2-D')
    n,m=x.shape
    if partitions<4 or partitions%2: raise ValueError('partitions must be an even integer >= 4')
    if n<partitions*2 or m<2: return {'status':'INSUFFICIENT_DATA'}
    chunks=np.array_split(x,partitions,axis=0)
    half=partitions//2
    combos=list(itertools.combinations(range(partitions),half))
    logits=[]; selected=[]
    for ins_idx in combos:
        oos_idx=tuple(i for i in range(partitions) if i not in ins_idx)
        ins=np.concatenate([chunks[i] for i in ins_idx],axis=0)
        oos=np.concatenate([chunks[i] for i in oos_idx],axis=0)
        ins_mean=np.nanmean(ins,axis=0); oos_mean=np.nanmean(oos,axis=0)
        if not np.isfinite(ins_mean).any(): continue
        best=int(np.nanargmax(ins_mean))
        rank=1+int(np.sum(np.where(np.isfinite(oos_mean),oos_mean, -np.inf)>oos_mean[best]))
        percentile=(rank-0.5)/m
        percentile=min(max(percentile,1/(2*m)),1-1/(2*m))
        logit=math.log(percentile/(1-percentile))
        logits.append(logit); selected.append({'best_candidate':best,'oos_rank':rank,'oos_percentile':percentile,'logit':logit})
    if not logits: return {'status':'INSUFFICIENT_DATA'}
    return {'status':'OK','pbo':float(np.mean(np.array(logits)<0)),'logit_mean':float(np.mean(logits)),
            'trials':len(logits),'partitions':partitions,'candidates':m,'details':selected}
