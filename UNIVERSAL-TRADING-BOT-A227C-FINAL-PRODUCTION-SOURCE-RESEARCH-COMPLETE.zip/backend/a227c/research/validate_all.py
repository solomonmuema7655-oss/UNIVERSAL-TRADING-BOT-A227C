"""Single command that audits all five-market research prerequisites without fabricating evidence."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from .strategy_candidates import complete_matrix, PROMOTION_RULES
from .strategy_research_catalog import EVIDENCE_REQUIREMENTS
from .acceptance import evaluate


def audit(data_dir):
    d=Path(data_dir); matrix=complete_matrix()
    report={'markets':{},'promotion_rules':PROMOTION_RULES,'evidence_requirements':EVIDENCE_REQUIREMENTS}
    for s,candidates in matrix.items():
        files=list(d.glob(f'{s}_*.csv')) if d.exists() else []
        report['markets'][s]={'candidate_strategies':candidates,'dataset_files':[x.name for x in files], 'real_data_present':bool(files)}
    return report


def main():
    p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--output',default='research_data/prereq_audit.json'); a=p.parse_args()
    r=audit(a.data); Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps(r,indent=2),encoding='utf-8'); print(json.dumps(r,indent=2))
if __name__=='__main__': main()
