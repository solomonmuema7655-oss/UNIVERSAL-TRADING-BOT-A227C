"""Production acceptance gate. Every external dependency must prove itself."""
from __future__ import annotations
import json, socket, ssl
from urllib.parse import urlparse

REQUIRED_KEYS=('bootstrap_https','wss','mt5_connected','five_symbols_verified','news_entitlement','tls_valid','shadow_stream')

def evaluate(gates):
    missing=[k for k in REQUIRED_KEYS if not gates.get(k)]
    return {'status':'ACCEPTED' if not missing else 'BLOCKED','missing':missing,'gates':gates,
            'policy':'No production acceptance is inferred from source code alone.'}

def validate_https(url):
    p=urlparse(url)
    return p.scheme=='https' and bool(p.hostname)
