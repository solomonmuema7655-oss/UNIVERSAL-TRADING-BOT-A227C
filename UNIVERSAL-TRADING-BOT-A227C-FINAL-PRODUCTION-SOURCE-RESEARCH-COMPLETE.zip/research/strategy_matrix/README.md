# A227C strategy-research matrix

GBPJPY and USTECH100 are now fully researchable rather than permanently hard-coded as `RESEARCH_REQUIRED`.

A candidate may only be promoted to a production strategy after:

1. Exact broker symbol mapping is verified on the target MT5 account.
2. Real Exness bid/ask tick history is acquired and hashed.
3. Candidate rules are frozen before the final holdout.
4. Tick-level replay is run for execution, stops, targets and holding windows.
5. Costs, spread, commission, slippage and historical financing are evidenced.
6. Chronological walk-forward OOS performance is positive and stable.
7. PBO/CSCV and DSR diagnostics pass the promotion thresholds.
8. The untouched final holdout passes.
9. Live shadow validation passes without order execution.
10. Only then is the strategy registry allowed to mark the candidate `VALIDATED_PRIMARY`.

No synthetic or third-party price series may be silently substituted for the required Exness evidence.
