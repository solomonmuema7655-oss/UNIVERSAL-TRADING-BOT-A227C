plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.siyoma.a227c"
    compileSdk = 35


    buildFeatures { buildConfig = true }

    defaultConfig {
        applicationId = "com.siyoma.a227c"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
        val bootstrap = providers.gradleProperty("A227C_BOOTSTRAP_URL").orElse(System.getenv("A227C_BOOTSTRAP_URL") ?: "").get()
        buildConfigField("String", "A227C_BOOTSTRAP_URL", "\"${bootstrap.replace("\"", "") }\"")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
