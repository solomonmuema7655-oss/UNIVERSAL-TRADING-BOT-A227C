package com.siyoma.a227c

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var detail: TextView
    private lateinit var markets: LinearLayout
    private lateinit var chart: CandleChartView
    private var selectedTimeframe = "M15"
    private var lastChartBar = ""
    private val cards = mutableMapOf<String, TextView>()
    private val latest = mutableMapOf<String, JSONObject>()
    private val lastConfirmedSignals = mutableMapOf<String, JSONObject>()
    private var selectedSymbol: String? = null
    private val previousDirections = mutableMapOf<String, String>()
    private val notificationChannel = "a227c_confirmed_signals"
    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private var socket: WebSocket? = null
    private var reconnectDelay = 3000L
    private var manuallyClosed = false
    private var bootstrapUrl = BuildConfig.A227C_BOOTSTRAP_URL
    private var engineWs = ""
    private var engineHttp = ""
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 227)
        }
        status = findViewById(R.id.status)
        detail = findViewById(R.id.detail)
        markets = findViewById(R.id.markets)
        chart = findViewById(R.id.chart)
        listOf("XAUUSD", "USTECH100", "GBPJPY", "GBPUSD", "USDJPY").forEach { symbol ->
            val card = TextView(this).apply {
                text = "$symbol     WAIT\nCONNECTING TO LIVE A227C ENGINE…"
                textSize = 14f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.rgb(16,39,71))
                setPadding(16,18,16,18)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 9 }
                setOnClickListener { selectedSymbol = symbol; latest[symbol]?.let { detail.text = formatDetail(it) }; lastChartBar=""; refreshChart() }
            }
            cards[symbol] = card
            markets.addView(card)
        }
        findViewById<Button>(R.id.tfM15).setOnClickListener { selectedTimeframe="M15"; refreshChart() }
        findViewById<Button>(R.id.tfM30).setOnClickListener { selectedTimeframe="M30"; refreshChart() }
        findViewById<Button>(R.id.tfH1).setOnClickListener { selectedTimeframe="H1"; refreshChart() }
        findViewById<Button>(R.id.tfH4).setOnClickListener { selectedTimeframe="H4"; refreshChart() }
        findViewById<Button>(R.id.history).setOnClickListener { fetchPublic("/public/signals/history?limit=50", "SIGNAL HISTORY") }
        findViewById<Button>(R.id.research).setOnClickListener { fetchPublic("/public/research/performance", "RESEARCH LAB") }
        findViewById<Button>(R.id.runBacktest).setOnClickListener { runWalkForward() }
        findViewById<Button>(R.id.recordWin).setOnClickListener { recordLocalOutcome("WIN") }
        findViewById<Button>(R.id.recordLoss).setOnClickListener { recordLocalOutcome("LOSS") }
        findViewById<Button>(R.id.recordBe).setOnClickListener { recordLocalOutcome("BREAKEVEN") }
        registerNetworkRecovery()
        autoStart()
    }

    private fun autoStart() {
        manuallyClosed = false
        if (bootstrapUrl.isBlank()) {
            status.text = "A227C BUILD ERROR — production bootstrap endpoint was not supplied"
            return
        }
        status.text = "STARTING A227C — DISCOVERING SECURE ENGINE…"
        val url = bootstrapUrl.toHttpUrlOrNull()
        if (url == null || url.scheme != "https") {
            status.text = "A227C BUILD ERROR — bootstrap must use HTTPS"
            return
        }
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: java.io.IOException) {
                runOnUiThread { status.text = "A227C ENGINE DISCOVERY FAILED — RETRYING…" }
                scheduleBootstrapRetry()
            }
            override fun onResponse(call: Call, response: Response) {
                val body=response.body?.string()?: "{}"
                response.close()
                if (!response.isSuccessful) { runOnUiThread { status.text="A227C ENGINE DISCOVERY HTTP ${response.code} — RETRYING…" }; scheduleBootstrapRetry(); return }
                try {
                    val obj=JSONObject(body)
                    val explicitWs=obj.optString("ws_url","")
                    engineWs=if(explicitWs.isNotBlank()) explicitWs else "wss://${url.host}${if(url.port!=443) ":${url.port}" else ""}/ws"
                    engineHttp="https://${url.host}${if(url.port!=443) ":${url.port}" else ""}"
                    if (!engineWs.startsWith("wss://")) throw IllegalStateException("Production engine is not TLS")
                    runOnUiThread { status.text="ENGINE DISCOVERED — CONNECTING LIVE DATA…"; connectNow() }
                } catch (_:Exception) {
                    runOnUiThread { status.text="A227C ENGINE DISCOVERY INVALID — RETRYING…" }; scheduleBootstrapRetry()
                }
            }
        })
    }

    private fun scheduleBootstrapRetry() {
        if (manuallyClosed) return
        handler.postDelayed({ if (!manuallyClosed && !isFinishing) autoStart() }, reconnectDelay)
        reconnectDelay=(reconnectDelay*2).coerceAtMost(60000L)
    }

    private fun connectNow() {
        if (engineWs.isBlank()) { autoStart(); return }
        socket?.close(1000,"reconnect")
        status.text="CONNECTING A227C LIVE ENGINE…"
        val request=Request.Builder().url(engineWs).build()
        socket=client.newWebSocket(request,object:WebSocketListener(){
            override fun onOpen(webSocket: WebSocket,response: Response){
                reconnectDelay=3000L
                runOnUiThread { status.text="CONNECTED — LIVE FIVE-MARKET STREAM ACTIVE" }
                webSocket.send("subscribe")
            }
            override fun onMessage(webSocket: WebSocket,text:String){ try{consume(JSONObject(text))}catch(_:Exception){runOnUiThread{status.text="ENGINE MESSAGE ERROR — RECONNECTING"}} }
            override fun onFailure(webSocket: WebSocket,t:Throwable,response:Response?){runOnUiThread{status.text="LIVE ENGINE CONNECTION LOST — RETRYING…"}; scheduleReconnect()}
            override fun onClosed(webSocket:WebSocket,code:Int,reason:String){runOnUiThread{status.text="LIVE ENGINE DISCONNECTED — RETRYING…"}; scheduleReconnect()}
        })
    }

    private fun scheduleReconnect(){
        if(manuallyClosed)return
        handler.postDelayed({if(!manuallyClosed&&!isFinishing) { if(engineWs.isBlank()) autoStart() else connectNow()}},reconnectDelay)
        reconnectDelay=(reconnectDelay*2).coerceAtMost(60000L)
    }

    private fun registerNetworkRecovery(){
        val cm=getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback=object:ConnectivityManager.NetworkCallback(){override fun onAvailable(network:Network){handler.post{reconnectDelay=3000L; if(!manuallyClosed) autoStart()}}}
        cm.registerDefaultNetworkCallback(networkCallback!!)
    }

    private fun refreshChart(){
        val symbol=selectedSymbol?:return
        if(engineHttp.isBlank())return
        val url=("$engineHttp/public/market/$symbol/candles").toHttpUrlOrNull()?.newBuilder()?.addQueryParameter("timeframe",selectedTimeframe)?.addQueryParameter("limit","100")?.build()?:return
        client.newCall(Request.Builder().url(url).get().build()).enqueue(object:Callback{
            override fun onFailure(call:Call,e:java.io.IOException){runOnUiThread{detail.text="Chart temporarily unavailable; live stream remains active."}}
            override fun onResponse(call:Call,response:Response){val text=response.body?.string()?: "{}";response.close();try{val obj=JSONObject(text);val rows=obj.optJSONArray("candles")?:org.json.JSONArray();runOnUiThread{chart.setCandles(rows);if(rows.length()>0)lastChartBar=rows.optJSONObject(rows.length()-1)?.optString("time","")?:""}}catch(_:Exception){runOnUiThread{detail.text="Chart data unavailable."}}}
        })
    }

    private fun runWalkForward(){
        val symbol=selectedSymbol?:run{detail.text="Select a market first.";return}
        val strategy=when{symbol=="USDJPY"&&selectedTimeframe in listOf("H1","H4")->"TREND_PULLBACK";symbol=="XAUUSD"&&selectedTimeframe=="M15"->"LIQUIDITY_SMC";symbol in listOf("GBPUSD","XAUUSD")&&selectedTimeframe in listOf("M15","M30")->"SESSION_BREAKOUT";else->{detail.text="No validated strategy assignment exists for this market/timeframe. A227C will not invent one.";return}}
        val spread=findViewById<EditText>(R.id.backtestSpread).text.toString().toDoubleOrNull()
        if(spread==null||spread<=0.0){detail.text="Enter the observed full spread cost for the selected market.";return}
        val url=("$engineHttp/public/research/backtest").toHttpUrlOrNull()?:return
        val payload=JSONObject().put("symbol",symbol).put("timeframe",selectedTimeframe).put("strategy",strategy).put("spread_cost",spread).put("train_fraction",0.6).put("max_holding_bars",48)
        val req=Request.Builder().url(url).post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        detail.text="RUNNING CHRONOLOGICAL WALK-FORWARD RESEARCH…"
        client.newCall(req).enqueue(object:Callback{override fun onFailure(call:Call,e:java.io.IOException){runOnUiThread{detail.text="Research temporarily unavailable."}};override fun onResponse(call:Call,response:Response){val body=response.body?.string()?: "";response.close();runOnUiThread{detail.text=if(response.isSuccessful)"WALK-FORWARD RESEARCH\n$body" else "RESEARCH ERROR ${response.code}\n$body"}}})
    }

    private fun recordLocalOutcome(outcome:String){
        val selected=selectedSymbol?.let{lastConfirmedSignals[it]}
        if(selected==null){detail.text="Select a market with a confirmed signal first.";return}
        val rr=findViewById<EditText>(R.id.realizedR).text.toString().toDoubleOrNull()
        val id=selected.optString("signal_id","unknown")
        val prefs=getSharedPreferences("a227c_journal",MODE_PRIVATE)
        val line="${System.currentTimeMillis()}|$id|${selected.optString("symbol")}|${selected.optString("direction")}|$outcome|${rr?:""}"
        val old=prefs.getString("entries","")?:""
        prefs.edit().putString("entries", if(old.isBlank()) line else "$old\n$line").apply()
        detail.text="LOCAL JOURNAL SAVED — ${selected.optString("symbol")} ${selected.optString("direction")} $outcome"
    }

    private fun fetchPublic(path:String,title:String){
        if(engineHttp.isBlank()){detail.text="A227C engine is still connecting.";return}
        val url=(engineHttp+path).toHttpUrlOrNull()?:return
        client.newCall(Request.Builder().url(url).get().build()).enqueue(object:Callback{override fun onFailure(call:Call,e:java.io.IOException){runOnUiThread{detail.text="$title unavailable while offline."}};override fun onResponse(call:Call,response:Response){val body=response.body?.string()?: "";response.close();runOnUiThread{detail.text="$title\n$body"}}})
    }

    private fun consume(message:JSONObject){
        val type=message.optString("type");val data=message.optJSONObject("data")
        if(type=="snapshot"&&data!=null){data.optJSONArray("signals")?.let{for(i in 0 until it.length())it.optJSONObject(i)?.let(::updateSignal)};runOnUiThread{status.text="CONNECTED — LIVE FIVE-MARKET STREAM ACTIVE"}}
        else if(type=="market_update"&&data!=null)updateSignal(data)
        else if(type=="signal_invalidated"){val symbol=message.optString("symbol");val previous=message.optString("previous_direction");runOnUiThread{status.text="SIGNAL INVALIDATED — $symbol $previous"};notifyInvalidation(symbol,previous)}
        else if(type=="emergency_stop")runOnUiThread{status.text="A227C EMERGENCY SIGNAL STOP ACTIVE — ALL MARKETS WAIT"}
    }

    private fun updateSignal(signal:JSONObject){
        val symbol=signal.optString("symbol");if(symbol !in cards)return
        latest[symbol]=signal;if(selectedSymbol==null)selectedSymbol=symbol
        val direction=signal.optString("direction","WAIT");val previous=previousDirections[symbol]
        if(direction in listOf("BUY","SELL"))lastConfirmedSignals[symbol]=signal
        if(direction in listOf("BUY","SELL")&&previous!=direction)notifySignal(symbol,direction,signal.optString("score","—"))
        previousDirections[symbol]=direction
        val color=when(direction){"BUY"->Color.rgb(49,209,138);"SELL"->Color.rgb(255,107,112);else->Color.rgb(245,196,81)}
        runOnUiThread{cards[symbol]?.apply{text="$symbol     $direction     SCORE ${signal.optString("score","—")}/100\n${signal.optString("data_health")} • ${signal.optString("source")}\n${signal.optString("quality","WAIT")}";setTextColor(color)};detail.text=formatDetail(signal)
        if(symbol==selectedSymbol&&selectedTimeframe=="M15"&&signal.optString("bar_timestamp")!=lastChartBar&&signal.optString("bar_timestamp").isNotBlank())refreshChart()
    }

    private fun notifyInvalidation(symbol:String,previous:String){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;val intent=android.content.Intent(this,MainActivity::class.java).apply{flags=android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP};val pending=PendingIntent.getActivity(this,symbol.hashCode()+1,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val n=NotificationCompat.Builder(this,notificationChannel).setSmallIcon(R.mipmap.ic_launcher).setContentTitle("A227C signal invalidated — $symbol").setContentText("Previous $previous thesis no longer passes current analysis.").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pending).build();NotificationManagerCompat.from(this).notify(symbol.hashCode()+1,n)}

    private fun createNotificationChannel(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){val c=NotificationChannel(notificationChannel,"A227C Confirmed Signals",NotificationManager.IMPORTANCE_HIGH);c.description="Live A227C signal and invalidation alerts";getSystemService(NotificationManager::class.java).createNotificationChannel(c)}}
    private fun notifySignal(symbol:String,direction:String,score:String){if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;val intent=android.content.Intent(this,MainActivity::class.java);val pending=PendingIntent.getActivity(this,symbol.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);val n=NotificationCompat.Builder(this,notificationChannel).setSmallIcon(R.mipmap.ic_launcher).setContentTitle("A227C $direction — $symbol").setContentText("Evidence score $score/100. Signal-only analysis.").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pending).build();NotificationManagerCompat.from(this).notify(symbol.hashCode(),n)}

    private fun formatDetail(s:JSONObject):String{val l=mutableListOf<String>();l+="${s.optString("symbol")} — ${s.optString("direction","WAIT")}";l+="Evidence score: ${s.optString("score","0")}/100 (not a win probability)";l+="Data: ${s.optString("data_health")} | ${s.optString("source")}";l+="News: ${s.optString("news_risk","UNKNOWN")} | Session: ${s.optString("session","—")}";l+="Feed age: ${s.optString("tick_age_seconds","—")}s | Spread: ${s.optString("spread","—")}";s.optJSONObject("live_quote")?.let{l+="LIVE BID ${it.optString("bid")} | ASK ${it.optString("ask")}"};s.optJSONObject("market_regime")?.let{l+="Regime: ${it.optString("name")} | ADX ${it.optString("adx14","—")}"};s.optJSONObject("timeframe_state")?.let{l+="H4 ${it.optString("H4")} • H1 ${it.optString("H1")} • M30 ${it.optString("M30")} • M15 ${it.optString("M15")}"};l+="Entry reference: ${s.optString("entry_reference","—")}";l+="Reference SL: ${s.optString("reference_sl","—")} | TP: ${s.optString("reference_tp","—")}";l+="R/R: ${s.optString("risk_reward_reference","—")}";val h=s.optJSONObject("holding_window");if(h!=null)l+="Holding policy: ${h.optInt("min_bars")}–${h.optInt("max_bars")} ${h.optString("unit")}; invalidation supersedes";s.optJSONArray("strategies")?.let{l+="Strategy evidence:";for(i in 0 until it.length()){val x=it.optJSONObject(i)?:continue;l+="• ${x.optString("name")}: ${x.optString("direction")} — ${x.optString("reason")}"}};s.optJSONArray("reasons")?.let{l+="Reasons:";for(i in 0 until it.length())l+="• ${it.optString(i)}"};l+="\nA227C is signal-only. It never places, modifies or closes broker trades.";return l.joinToString("\n")}

    override fun onResume(){super.onResume();if(!manuallyClosed)autoStart()}
    override fun onDestroy(){manuallyClosed=true;handler.removeCallbacksAndMessages(null);socket?.close(1000,"App closed");networkCallback?.let{(getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it)};super.onDestroy()}
}
