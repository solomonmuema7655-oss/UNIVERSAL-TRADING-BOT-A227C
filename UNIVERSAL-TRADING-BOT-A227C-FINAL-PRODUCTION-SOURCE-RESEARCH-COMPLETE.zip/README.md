# SIYOMA UNIVERSAL-TRADING-BOT-A227C — FINAL BUILD BASELINE

This is the final production-oriented A227C source baseline. It is **not** a prototype, mock-up, V1 or MVP.

## Operating rule

A227C is a **signal-only** market-analysis system. It never places, modifies, closes or manages broker trades. The user's broker account remains outside the application. No live AI/ML/LLM is used for decisions.

## Live path

```text
MetaTrader 5 / Exness feed
        ↓
A227C Windows analysis engine
        ↓
validated H4 → H1 → M30 → M15 pipeline
        ↓
strategy + regime + structure + momentum + volatility
+ liquidity + sessions + news/macro + correlation + spread
+ independent risk/SL gate + conflict/confluence gates
        ↓
BUY / SELL / WAIT + complete explanation + snapshot
        ↓
secure WSS
        ↓
SIYOMA Android application
```

Deriv is a separate provider namespace. It is never substituted for an Exness/MT5 CFD feed.

## Android first-run behavior

The final Android architecture no longer asks the user to type a WSS address or API token.

At build time, the production APK receives **only a public HTTPS bootstrap URL**. On launch it:

1. calls the HTTPS bootstrap endpoint;
2. discovers the deployed WSS endpoint;
3. requires WSS/TLS;
4. opens the read-only signal stream automatically;
5. reconnects after connection failure;
6. reacts to Android network changes;
7. displays live five-market analysis.

No broker password, Trading Economics key or A227C admin token is embedded in the APK.

The public WSS stream is intentionally read-only. Administrative and mutation endpoints remain token protected.

## Production hosting

The Windows deployment package provisions:

- Python virtual environment;
- MetaTrader5 Python integration;
- encrypted local secrets using Windows DPAPI;
- A227C startup task;
- MT5 startup task;
- Caddy TLS reverse proxy;
- firewall rules for 80/443;
- no public exposure of backend port 8765;
- restart-on-failure scheduled tasks.

The production host still necessarily requires real account-holder infrastructure: a Windows machine/VPS, an MT5 login, the exact broker symbol names, a domain/DNS name, and Trading Economics API entitlement.

## Five-market production gate

The production engine refuses to start if the configured analysis set is not exactly:

- XAUUSD
- USTECH100
- GBPJPY
- GBPUSD
- USDJPY

The internal names are separate from the broker/provider names. USTECH100 must be mapped to the exact symbol shown by the selected MT5 account.

## News/macro gate

The production installer requires a Trading Economics API key. A missing/stale/invalid news or macro context cannot silently become a confirmed signal. This preserves the rule that A227C must use real data or remain WAIT.

## Research

The source includes chronological walk-forward research, observed bid/ask quote-side handling, explicit spread/commission/slippage inputs, conservative same-bar stop-first handling, final holdout support, manual outcome storage, score calibration buckets, carry research and historical data tooling.

No strategy performance is fabricated. Empirical calibration becomes valid only after the required real historical datasets are supplied and the research pipeline has produced results.

## Build acceptance

A production Android release **must** be built with a real HTTPS `A227C_BOOTSTRAP_URL`. The GitHub Actions workflow intentionally fails when this value is missing or not HTTPS. This prevents another incomplete APK from being labelled as a final build.

For local build tooling, use `deploy/build-final.sh` after the production bootstrap endpoint exists.

## Validation performed on this source baseline

- Python compilation: passed.
- Backend tests: **36 passed**.
- New tests cover independent risk/SL enforcement, spread rejection, duration policy and cross-market opportunity ranking.
- Android source was redesigned for automatic bootstrap/WSS discovery and no embedded secret.
- Production Gradle build is configured for Ubuntu 22.04, Java 17 and Gradle 8.7 in GitHub Actions.

A physical Android + live Windows/MT5 host acceptance test remains a deployment test; source code cannot honestly claim that a broker account, DNS name, TLS certificate or Trading Economics entitlement exists before those resources are provisioned.
