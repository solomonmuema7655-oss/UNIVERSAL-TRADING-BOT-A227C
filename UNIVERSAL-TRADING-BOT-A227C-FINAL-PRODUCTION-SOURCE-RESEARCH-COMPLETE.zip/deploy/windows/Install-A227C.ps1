param(
  [string]$Python = "python",
  [string]$BackendPath = (Join-Path $PSScriptRoot "../../backend")
)
$ErrorActionPreference = 'Stop'
$BackendPath = (Resolve-Path $BackendPath).Path
Write-Host "A227C backend installation: $BackendPath" -ForegroundColor Cyan
& $Python --version
if ($LASTEXITCODE -ne 0) { throw "Python 3.11+ is required. Install 64-bit Python and retry." }
$venv = Join-Path $BackendPath '.venv'
if (!(Test-Path $venv)) { & $Python -m venv $venv }
$pip = Join-Path $venv 'Scripts/pip.exe'
$py = Join-Path $venv 'Scripts/python.exe'
& $py -m pip install --upgrade pip
& $pip install -r (Join-Path $BackendPath 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Python dependency installation failed.' }
$config = Join-Path $BackendPath 'config.json'
if (!(Test-Path $config)) { Copy-Item (Join-Path $BackendPath 'config.example.json') $config }
$secureDir = Join-Path $env:LOCALAPPDATA 'Siyoma/A227C'
New-Item -ItemType Directory -Force -Path $secureDir | Out-Null
$token = Read-Host 'Enter a unique long A227C API token (do not reuse a broker password)' -AsSecureString
if ($token.Length -lt 32) { throw 'Use an API token of at least 32 characters.' }
$token | ConvertFrom-SecureString | Set-Content (Join-Path $secureDir 'api-token.dpapi')
$te = Read-Host 'Enter Trading Economics API key (required for the live news/macro gate)' -AsSecureString
if ($te.Length -eq 0) { throw 'Trading Economics API key is required for the final live A227C build; no news/macro data may be fabricated or silently skipped.' }
$te | ConvertFrom-SecureString | Set-Content (Join-Path $secureDir 'te-key.dpapi')
if ($te.Length -gt 0) {
  $cfgObj = Get-Content $config -Raw | ConvertFrom-Json
  $cfgObj.news.enabled = $true
  $cfgObj | ConvertTo-Json -Depth 20 | Set-Content $config -Encoding UTF8
}
@"
`$ErrorActionPreference = 'Stop'
function Read-LocalSecret([string]`$Name) {
  `$p = Join-Path '$secureDir' (`$Name + '.dpapi')
  if (!(Test-Path `$p)) { return '' }
  `$s = Get-Content `$p | ConvertTo-SecureString
  `$b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR(`$s)
  try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR(`$b) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR(`$b) }
}
`$env:A227C_API_TOKEN = Read-LocalSecret 'api-token'
`$env:TRADING_ECONOMICS_API_KEY = Read-LocalSecret 'te-key'
`$env:A227C_CONFIG = '$config'
`$env:A227C_ENV = 'production'
Set-Location '$BackendPath'
& '$py' -m uvicorn a227c.server:app --host 127.0.0.1 --port 8765 --proxy-headers
"@ | Set-Content (Join-Path $PSScriptRoot 'Start-A227C.ps1') -Encoding UTF8
Write-Host 'Installed dependencies and protected local credentials using Windows DPAPI.' -ForegroundColor Green
Write-Host 'Next: verify MT5 terminal is installed, logged in, and all five symbols are visible.'
Write-Host 'Then run deploy\windows\Start-A227C.ps1 in the same Windows user account.'
