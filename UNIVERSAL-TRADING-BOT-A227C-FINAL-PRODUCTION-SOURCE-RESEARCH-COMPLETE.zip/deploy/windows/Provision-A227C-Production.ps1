param(
  [Parameter(Mandatory=$true)][string]$A227CRoot,
  [Parameter(Mandatory=$true)][string]$BootstrapHost,
  [Parameter(Mandatory=$true)][string]$CloudflareTunnelToken,
  [Parameter(Mandatory=$true)][string]$A227CApiToken
)
$ErrorActionPreference='Stop'
if($BootstrapHost -notmatch '^https://'){ throw 'BootstrapHost must be HTTPS.' }
if($A227CApiToken.Length -lt 32){ throw 'A227C API token must be at least 32 characters.' }
if(-not (Test-Path $A227CRoot)){ New-Item -ItemType Directory -Path $A227CRoot -Force | Out-Null }
$envFile=Join-Path $A227CRoot 'production.env.ps1'
@"
`$env:A227C_ENV='production'
`$env:A227C_BOOTSTRAP_URL='$BootstrapHost'
`$env:A227C_API_TOKEN='$A227CApiToken'
`$env:TRADING_ECONOMICS_API_KEY='SET_IN_WINDOWS_SECRET_STORE'
"@ | Set-Content $envFile -Encoding UTF8
# cloudflared must be installed separately from Cloudflare's official distribution.
$cf=Get-Command cloudflared -ErrorAction SilentlyContinue
if(-not $cf){ throw 'cloudflared is not installed. Install the official Cloudflare cloudflared binary, then rerun this provisioner.' }
& cloudflared service install $CloudflareTunnelToken
Write-Host 'A227C production host prerequisites recorded. Next run Register-A227C-StartupTask.ps1 and execute the external acceptance checklist.'
