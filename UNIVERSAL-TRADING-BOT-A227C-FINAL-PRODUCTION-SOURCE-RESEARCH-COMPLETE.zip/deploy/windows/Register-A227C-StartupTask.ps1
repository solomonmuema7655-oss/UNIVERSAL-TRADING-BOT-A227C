param(
  [Parameter(Mandatory=$true)][string]$Mt5Path,
  [string]$InstallPath = (Resolve-Path (Join-Path $PSScriptRoot "../../backend")).Path
)
$ErrorActionPreference='Stop'
if(!(Test-Path $Mt5Path)){throw "MetaTrader 5 executable not found: $Mt5Path"}
$start = Join-Path $PSScriptRoot 'Start-A227C.ps1'
if(!(Test-Path $start)){throw 'Run Install-A227C.ps1 first.'}
$user="$env:USERDOMAIN\$env:USERNAME"
$settings=New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
$mt5Action=New-ScheduledTaskAction -Execute $Mt5Path
$engineAction=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$start`""
$trigger=New-ScheduledTaskTrigger -AtLogOn -User $user
Register-ScheduledTask -TaskName 'SIYOMA A227C - MetaTrader 5' -Action $mt5Action -Trigger $trigger -Settings $settings -Description 'Starts the MT5 terminal used as A227C market-data source.' -Force | Out-Null
Register-ScheduledTask -TaskName 'SIYOMA A227C - Analysis Engine' -Action $engineAction -Trigger $trigger -Settings $settings -Description 'Starts the signal-only A227C analysis engine.' -Force | Out-Null
Write-Host 'A227C MT5 + analysis engine startup tasks registered.' -ForegroundColor Green
