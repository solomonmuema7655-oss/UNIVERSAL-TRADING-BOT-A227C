param(
  [Parameter(Mandatory=$true)][string]$Domain,
  [Parameter(Mandatory=$true)][string]$Mt5Path,
  [string]$CaddyPath='caddy'
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$backend=Join-Path $root 'backend'
$caddyDir=Join-Path $root 'deploy/caddy'
$config=Join-Path $backend 'config.json'
if(!(Test-Path $config)){Copy-Item (Join-Path $backend 'config.example.json') $config}
if(!(Get-Command $CaddyPath -ErrorAction SilentlyContinue)){
  if(Get-Command winget -ErrorAction SilentlyContinue){
    winget install --id CaddyServer.Caddy -e --accept-package-agreements --accept-source-agreements
  } else { throw 'Caddy is not installed and winget is unavailable. Install Caddy, then rerun this script.' }
}
New-Item -ItemType Directory -Force -Path $caddyDir | Out-Null
@"
$Domain {
    encode gzip
    reverse_proxy 127.0.0.1:8765
}
"@ | Set-Content (Join-Path $caddyDir 'Caddyfile') -Encoding UTF8
New-NetFirewallRule -DisplayName 'SIYOMA A227C HTTPS' -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName 'SIYOMA A227C ACME HTTP' -Direction Inbound -Protocol TCP -LocalPort 80 -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null
# Never expose the FastAPI port publicly.
Remove-NetFirewallRule -DisplayName 'SIYOMA A227C Backend 8765' -ErrorAction SilentlyContinue
& (Get-Command $CaddyPath).Source validate --config (Join-Path $caddyDir 'Caddyfile')
if($LASTEXITCODE -ne 0){throw 'Caddy configuration validation failed.'}
$action=New-ScheduledTaskAction -Execute (Get-Command $CaddyPath).Source -Argument "run --config `"$(Join-Path $caddyDir 'Caddyfile')`""
$trigger=New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$settings=New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName 'SIYOMA A227C - TLS Proxy' -Action $action -Trigger $trigger -Settings $settings -Description 'Caddy TLS reverse proxy for A227C WSS/HTTPS.' -Force | Out-Null
Write-Host "Caddy host provisioned for $Domain. DNS must point to this machine before certificate issuance." -ForegroundColor Green
Write-Host 'Next: run Install-A227C.ps1, then Register-A227C-StartupTask.ps1, then start/verify the three scheduled tasks.' -ForegroundColor Yellow
