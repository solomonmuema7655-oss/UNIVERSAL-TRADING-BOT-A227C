#!/usr/bin/env bash
set -euo pipefail
: "${A227C_BOOTSTRAP_URL:?A227C_BOOTSTRAP_URL must be a real HTTPS /bootstrap endpoint of the deployed final engine}"
case "$A227C_BOOTSTRAP_URL" in https://*) ;; *) echo 'A227C_BOOTSTRAP_URL must use HTTPS' >&2; exit 2;; esac
./gradlew :android:app:assembleRelease --no-daemon -PA227C_BOOTSTRAP_URL="$A227C_BOOTSTRAP_URL"
