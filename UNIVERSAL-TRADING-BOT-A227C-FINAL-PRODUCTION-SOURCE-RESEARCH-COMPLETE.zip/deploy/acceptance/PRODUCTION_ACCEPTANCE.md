# A227C production acceptance

The deployment system must not claim production readiness until every gate is green.

- Windows VPS reachable and persistent
- MT5 installed, logged into intended Exness account, terminal auto-starting
- Exact five broker symbols discovered and contract metadata verified
- Exness tick-history research archives acquired and hashed
- Trading Economics API entitlement verified
- BOJ point-in-time macro source available for Japan data
- Treasury point-in-time US yield source available
- Broker historical swap ledger available; current snapshots are never backfilled
- A227C backend running read-only market analysis
- Cloudflare Tunnel or Caddy public HTTPS/WSS endpoint valid
- Android bootstrap endpoint resolves over HTTPS
- WSS stream passes five-market heartbeat and freshness tests
- stale-feed, reconnect, invalidation and notification tests pass
- live shadow period passes with zero broker order calls

The acceptance result is BLOCKED if any required gate is missing. This is intentional.
