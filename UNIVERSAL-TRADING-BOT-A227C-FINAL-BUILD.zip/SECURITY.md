# Security boundary

- Never put MT5 passwords, broker credentials, Deriv account tokens, Trading Economics secrets, or private WebSocket credentials in the Android app.
- The Android client is a display/control client only.
- No order-placement endpoint exists in the A227C engine.
- For production deployment, expose the engine through TLS (wss/https), authenticate the Android client, rotate secrets, and restrict inbound access.
- Data feeds must be marked stale if heartbeat/timestamp freshness fails.
