# UNIVERSAL-TRADING-BOT-A227C

Production-oriented real-time market analysis and signal system by SiyomaCodingPrograms.

**A227C does not execute trades.** It captures live market data, validates it, builds H4/H1/M30/M15 state, runs deterministic/statistical analysis, incorporates economic-news risk, and publishes explainable BUY/SELL/WAIT signals. The user manually executes any trade through their own broker/platform.

## Live-data architecture

- **MT5 adapter:** connects to a running MetaTrader 5 terminal and reads live ticks and bars. The terminal must be logged into a broker account that provides the requested instruments.
- **Deriv adapter:** connects to Deriv's public WebSocket market-data endpoint and subscribes to ticks. No trading/account permissions are used.
- **News adapter:** supports a Trading Economics calendar feed/API through a server-side key. The key is never stored in the Android APK.
- **Core engine:** normalizes symbols, validates freshness, builds bars, computes indicators/structure/liquidity/session conditions, evaluates strategies, scores confluence, applies news/risk gates, and publishes signals.
- **Android app:** monitoring/control UI only; it never contains broker credentials or execution code.

## Initial instruments

XAUUSD, USTECH100, GBPJPY, GBPUSD, USDJPY.

Provider-specific symbols are configured in `backend/config.example.json`; never assume one broker's symbol spelling is universal.

## Timeframe protocol

H4 → H1 → M30 → M15. M15 is a hard confirmation gate. Any unresolved mandatory conflict produces WAIT.

## Important validation rule

The supplied strategy concepts are encoded as a framework, but **no strategy is allowed to claim statistical profitability merely because a rule exists**. Backtesting, walk-forward validation, paper/demo validation, score calibration, and live shadow validation are required before a strategy is promoted to a confirmed production signal rule.

## Running the engine

1. Copy `backend/config.example.json` to `backend/config.json`.
2. Install Python 3.11+ dependencies from `backend/requirements.txt`.
3. For MT5 data, run the engine on a Windows host with MetaTrader 5 installed and logged in. Set `MT5_ENABLED=true`.
4. For Deriv, set `DERIV_ENABLED=true` and provider symbols in config.
5. For economic news, configure the Trading Economics key if available. Without a news feed, A227C must remain in DATA_LIMITED/WAIT rather than pretend news risk is known.
6. Start `python -m a227c.server`.
7. Point the Android client at the engine WebSocket URL.

## Safety boundary

There is intentionally no order-placement module, broker login API, trade/close-all endpoint, or automated execution path in this project.
