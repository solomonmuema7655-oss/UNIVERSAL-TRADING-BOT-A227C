package com.siyoma.a227c

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.util.AttributeSet
import android.view.View
import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

class CandleChartView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private data class Candle(val open: Double, val high: Double, val low: Double, val close: Double)
    private val candles = mutableListOf<Candle>()
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(42,65,91); strokeWidth = 1f }
    private val up = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(49,209,138); strokeWidth = 2f; style = Paint.Style.FILL }
    private val down = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255,107,112); strokeWidth = 2f; style = Paint.Style.FILL }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(169,187,210); textSize = 25f }
    private val empty = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(169,187,210); textSize = 30f; textAlign = Paint.Align.CENTER }

    fun setCandles(rows: JSONArray) {
        candles.clear()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            candles += Candle(row.optDouble("open"), row.optDouble("high"), row.optDouble("low"), row.optDouble("close"))
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(10,29,53))
        if (candles.isEmpty()) { canvas.drawText("Waiting for verified candle history", width/2f, height/2f, empty); return }
        val left=54f; val right=width-18f; val top=18f; val bottom=height-28f
        val minP=candles.minOf { it.low }; val maxP=candles.maxOf { it.high }; val span=max(maxP-minP,1e-9)
        fun y(v:Double)=bottom-((v-minP)/span).toFloat()*(bottom-top)
        val decimals=when { maxP>=1000 -> 1; maxP>=100 -> 2; maxP>=1 -> 4; else -> 5 }
        for (i in 0..4) {
            val gy=top+(bottom-top)*i/4f; canvas.drawLine(left,gy,right,gy,grid)
            val value=maxP-span*i/4.0; canvas.drawText(String.format("%.${decimals}f",value),4f,gy+8f,label)
        }
        val step=(right-left)/candles.size; val bodyW=max(3f,step*.58f)
        candles.forEachIndexed { i,c ->
            val cx=left+step*(i+.5f); val paint=if(c.close>=c.open) up else down
            canvas.drawLine(cx,y(c.high),cx,y(c.low),paint)
            val topBody=min(y(c.open),y(c.close)); val bottomBody=max(y(c.open),y(c.close))
            canvas.drawRect(cx-bodyW/2,topBody,cx+bodyW/2,max(topBody+2f,bottomBody),paint)
        }
    }
}
