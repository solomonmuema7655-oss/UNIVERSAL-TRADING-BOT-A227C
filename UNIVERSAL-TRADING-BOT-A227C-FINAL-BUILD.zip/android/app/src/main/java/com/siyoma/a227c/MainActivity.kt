package com.siyoma.a227c

import android.graphics.Color
import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var host: EditText
    private lateinit var token: EditText
    private lateinit var detail: TextView
    private lateinit var markets: LinearLayout
    private lateinit var chart: CandleChartView
    private var selectedTimeframe = "M15"
    private var lastChartBar = ""
    private val cards = mutableMapOf<String, TextView>()
    private val latest = mutableMapOf<String, JSONObject>()
    private val lastConfirmedSignals = mutableMapOf<String, JSONObject>()
    private var selectedSymbol: String? = null
    private val previousDirections = mutableMapOf<String, String>()
    private val notificationChannel = "a227c_confirmed_signals"
    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private var socket: WebSocket? = null
    private var reconnectDelay = 3000L
    private var manuallyClosed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 227)
        }
        status = findViewById(R.id.status); host = findViewById(R.id.host); token = findViewById(R.id.token)
        detail = findViewById(R.id.detail); markets = findViewById(R.id.markets); chart = findViewById(R.id.chart)
        findViewById<Button>(R.id.tfM15).setOnClickListener { selectedTimeframe="M15"; refreshChart() }
        findViewById<Button>(R.id.tfM30).setOnClickListener { selectedTimeframe="M30"; refreshChart() }
        findViewById<Button>(R.id.tfH1).setOnClickListener { selectedTimeframe="H1"; refreshChart() }
        findViewById<Button>(R.id.tfH4).setOnClickListener { selectedTimeframe="H4"; refreshChart() }
        host.setText(getPreferences(MODE_PRIVATE).getString("engine_host", ""))
        listOf("XAUUSD", "USTECH100", "GBPJPY", "GBPUSD", "USDJPY").forEach { symbol ->
            val card = TextView(this).apply {
                text = "$symbol     WAITING FOR LIVE DATA\nNo provider tick or validated analysis received yet"
                textSize = 14f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(16,39,71)); setPadding(16,18,16,18)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 9 }
                setOnClickListener { selectedSymbol = symbol; latest[symbol]?.let { detail.text = formatDetail(it) }; lastChartBar=""; refreshChart() }
            }
            cards[symbol] = card; markets.addView(card)
        }
        findViewById<Button>(R.id.connect).setOnClickListener { manuallyClosed = false; connectNow() }
        findViewById<Button>(R.id.history).setOnClickListener { fetchProtected("/signals/history?limit=50", "SIGNAL HISTORY") }
        findViewById<Button>(R.id.research).setOnClickListener { fetchProtected("/research/performance", "RESEARCH LAB") }
        findViewById<Button>(R.id.runBacktest).setOnClickListener { runWalkForward() }
        findViewById<Button>(R.id.recordWin).setOnClickListener { postOutcome("WIN") }
        findViewById<Button>(R.id.recordLoss).setOnClickListener { postOutcome("LOSS") }
        findViewById<Button>(R.id.recordBe).setOnClickListener { postOutcome("BREAKEVEN") }
    }

    private fun connectNow() {
        val raw = host.text.toString().trim()
        val parsed = raw.toHttpUrlOrNull()
        if (parsed == null || parsed.scheme != "wss") {
            status.text = "Enter a secure wss:// A227C WebSocket address (TLS required)"; return
        }
        getPreferences(MODE_PRIVATE).edit().putString("engine_host", raw).apply()
        socket?.close(1000, "Reconnect requested")
        val secret = token.text.toString().trim()
        status.text = "CONNECTING TO A227C ENGINE…"
        val requestBuilder = Request.Builder().url(parsed)
        if (secret.isNotEmpty()) requestBuilder.header("X-A227C-Token", secret)
        socket = client.newWebSocket(requestBuilder.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectDelay = 3000L
                runOnUiThread { status.text = "CONNECTED — RECEIVING ENGINE UPDATES" }
                webSocket.send("subscribe")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try { consume(JSONObject(text)) } catch (_: Exception) { runOnUiThread { status.text = "CONNECTED — UNREADABLE ENGINE MESSAGE" } }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { status.text = "ENGINE CONNECTION FAILED — ${t.message ?: "network error"}" }
                scheduleReconnect()
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { status.text = "ENGINE DISCONNECTED" }; scheduleReconnect()
            }
        })
    }

    private fun scheduleReconnect() {
        if (manuallyClosed) return
        handler.postDelayed({ if (!manuallyClosed && !isFinishing) connectNow() }, reconnectDelay)
        reconnectDelay = (reconnectDelay * 2).coerceAtMost(60000L)
    }




    private fun refreshChart() {
        val symbol = selectedSymbol ?: return
        val ws = host.text.toString().trim().toHttpUrlOrNull() ?: return
        val scheme = "https"
        val url = ws.newBuilder().scheme(scheme).encodedPath("/market/$symbol/candles").query(null)
            .addQueryParameter("timeframe", selectedTimeframe).addQueryParameter("limit", "100").build()
        val request = Request.Builder().url(url).header("X-A227C-Token", token.text.toString().trim()).get().build()
        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: java.io.IOException) { runOnUiThread { detail.text = "Chart unavailable: ${e.message}" } }
            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string() ?: "{}"
                try {
                    val obj=JSONObject(text); val rows=obj.optJSONArray("candles") ?: org.json.JSONArray()
                    runOnUiThread { chart.setCandles(rows); if (rows.length()>0) lastChartBar=rows.optJSONObject(rows.length()-1)?.optString("time","") ?: "" }
                } catch (_: Exception) { runOnUiThread { detail.text = "Chart data could not be parsed." } }
                response.close()
            }
        })
    }


    private fun runWalkForward() {
        val symbol=selectedSymbol ?: run { detail.text="Select a market first."; return }
        val strategy=when {
            symbol=="USDJPY" && selectedTimeframe in listOf("H1","H4") -> "TREND_PULLBACK"
            symbol=="XAUUSD" && selectedTimeframe=="M15" -> "LIQUIDITY_SMC"
            symbol in listOf("GBPUSD","XAUUSD") && selectedTimeframe in listOf("M15","M30") -> "SESSION_BREAKOUT"
            else -> { detail.text="No backtest rule is enabled for $symbol at $selectedTimeframe. This market/timeframe strategy assignment is not validated."; return }
        }
        val spread=findViewById<EditText>(R.id.backtestSpread).text.toString().toDoubleOrNull()
        if(spread==null || spread<=0.0) { detail.text="Enter a positive historical full-spread cost in the instrument's quote-price units."; return }
        val ws=host.text.toString().trim().toHttpUrlOrNull() ?: return
        val scheme="https"
        val url=ws.newBuilder().scheme(scheme).encodedPath("/research/backtest").query(null).build()
        val payload=JSONObject().put("symbol",symbol).put("timeframe",selectedTimeframe).put("strategy",strategy).put("spread_cost",spread)
            .put("train_fraction",0.6).put("max_holding_bars",48)
        val request=Request.Builder().url(url).header("X-A227C-Token",token.text.toString().trim())
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        detail.text="Running chronological walk-forward research on loaded historical candles…"
        client.newCall(request).enqueue(object:Callback {
            override fun onFailure(call:Call,e:java.io.IOException){runOnUiThread{detail.text="Backtest failed: ${e.message}"}}
            override fun onResponse(call:Call,response:Response){val body=response.body?.string()?:"No response";runOnUiThread{detail.text=if(response.isSuccessful) "WALK-FORWARD RESEARCH\n$body" else "RESEARCH ERROR ${response.code}\n$body"};response.close()}
        })
    }

    private fun postOutcome(outcome: String) {
        val selected = selectedSymbol?.let { lastConfirmedSignals[it] }
        if (selected == null || selected.optInt("signal_id", 0) <= 0) {
            detail.text = "Select a persisted A227C signal snapshot before recording an outcome."; return
        }
        val ws = host.text.toString().trim().toHttpUrlOrNull()
        if (ws == null) return
        val scheme = "https"
        val url = ws.newBuilder().scheme(scheme).encodedPath("/journal/outcome").query(null).build()
        val realizedText = findViewById<EditText>(R.id.realizedR).text.toString().trim()
        val json = JSONObject().put("signal_id", selected.optInt("signal_id"))
            .put("outcome", outcome).put("notes", "Manually recorded in A227C Android app")
        if (realizedText.isNotEmpty()) realizedText.toDoubleOrNull()?.let { json.put("realized_r", it) }
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(url).header("X-A227C-Token", token.text.toString().trim()).post(body).build()
        client.newCall(request).enqueue(object: Callback {
            override fun onFailure(call: Call, e: java.io.IOException) { runOnUiThread { detail.text = "Journal save failed: ${e.message}" } }
            override fun onResponse(call: Call, response: Response) {
                val result = response.body?.string() ?: "No response"; runOnUiThread { detail.text = if (response.isSuccessful) "OUTCOME RECORDED\n$result" else "JOURNAL ERROR ${response.code}\n$result" }; response.close()
            }
        })
    }

    private fun fetchProtected(path: String, title: String) {
        val ws = host.text.toString().trim().toHttpUrlOrNull()
        if (ws == null) { detail.text = "Configure the A227C engine address first."; return }
        val scheme = "https"
        val httpUrl = ws.newBuilder().scheme(scheme).encodedPath(path.substringBefore('?')).query(null)
            .apply { if (path.contains("?")) path.substringAfter('?').split("&").forEach { part -> val p=part.split("=",limit=2); if(p.size==2) addQueryParameter(p[0],p[1]) } }.build()
        val requestBuilder = Request.Builder().url(httpUrl)
        val secret = token.text.toString().trim(); if (secret.isNotEmpty()) requestBuilder.header("X-A227C-Token", secret)
        client.newCall(requestBuilder.get().build()).enqueue(object: Callback {
            override fun onFailure(call: Call, e: java.io.IOException) { runOnUiThread { detail.text = "$title unavailable: ${e.message}" } }
            override fun onResponse(call: Call, response: Response) {
                val body = response.body?.string() ?: "No response"
                runOnUiThread { detail.text = if (response.isSuccessful) "$title\n$body" else "$title — HTTP ${response.code}\n$body" }
                response.close()
            }
        })
    }

    private fun consume(message: JSONObject) {
        val type = message.optString("type")
        val data = message.optJSONObject("data")
        if (type == "snapshot" && data != null) {
            val signals = data.optJSONArray("signals")
            if (signals != null) for (i in 0 until signals.length()) signals.optJSONObject(i)?.let { updateSignal(it) }
            data.optJSONObject("providers")?.let { updateProviderStatus(it) }
            runOnUiThread { if (data.optJSONObject("providers") == null) status.text = "CONNECTED — INITIAL ENGINE SNAPSHOT RECEIVED" }
        } else if ((type == "market_update" || type == "signal") && data != null) {
            updateSignal(data); message.optJSONObject("providers")?.let { updateProviderStatus(it) }
        }
        else if (type == "deriv_tick" && data != null) {
            runOnUiThread { status.text = "DERIV LIVE TICK — ${data.optString("provider_symbol")}  QUOTE ${data.optString("quote")}" }
        }
        else if (type == "signal_invalidated") {
            val symbol=message.optString("symbol"); val previous=message.optString("previous_direction")
            runOnUiThread { status.text = "SIGNAL INVALIDATED — $symbol $previous. Review the latest analysis." }
            notifyInvalidation(symbol, previous)
        }
        else if (type == "provider_status") runOnUiThread { status.text = "ENGINE CONNECTED — ${message.optString("provider").uppercase()}: ${message.optString("status")}" }
        else if (type == "news_status") runOnUiThread { status.text = "ENGINE CONNECTED — NEWS: ${message.optString("status")}" }
    }


    private fun updateProviderStatus(providers: JSONObject) {
        val mt5 = providers.optString("mt5", "UNKNOWN")
        val deriv = providers.optString("deriv", "UNKNOWN")
        val news = providers.optString("news", "UNKNOWN")
        val macro = providers.optString("macro", "UNKNOWN")
        runOnUiThread { status.text = "ENGINE CONNECTED  |  MT5: $mt5  |  DERIV: $deriv  |  NEWS: $news  |  MACRO: $macro" }
    }

    private fun updateSignal(signal: JSONObject) {
        val symbol = signal.optString("symbol")
        if (symbol !in cards) return
        latest[symbol] = signal
        if (selectedSymbol == null) selectedSymbol = symbol
        val direction = signal.optString("direction", "WAIT")
        val previous = previousDirections[symbol]
        if (direction in listOf("BUY", "SELL")) lastConfirmedSignals[symbol] = signal
        if (direction in listOf("BUY", "SELL") && previous != direction) notifySignal(symbol, direction, signal.optString("score", "—"))
        previousDirections[symbol] = direction
        val health = signal.optString("data_health", "UNKNOWN")
        val source = signal.optString("source", "UNKNOWN")
        val score = signal.optString("score", "—")
        val color = when (direction) { "BUY" -> Color.rgb(49,209,138); "SELL" -> Color.rgb(255,107,112); else -> Color.rgb(245,196,81) }
        runOnUiThread {
            cards[symbol]?.apply {
                text = "$symbol     $direction     SCORE $score/100\n$health  •  $source\n${signal.optString("quality", "WAIT")}" 
                setTextColor(color)
            }
            detail.text = formatDetail(signal)
            status.text = "CONNECTED — LIVE ENGINE STREAM ACTIVE"
            if (symbol == selectedSymbol && selectedTimeframe == "M15" && signal.optString("bar_timestamp") != lastChartBar && signal.optString("bar_timestamp").isNotBlank()) refreshChart()
        }
    }



    private fun notifyInvalidation(symbol: String, previous: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val intent = android.content.Intent(this, MainActivity::class.java).apply { flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pending = PendingIntent.getActivity(this, symbol.hashCode()+1, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, notificationChannel)
            .setSmallIcon(R.mipmap.ic_launcher).setContentTitle("A227C signal invalidated — $symbol")
            .setContentText("Previous $previous thesis no longer passes current analysis. Review before taking action.")
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pending).build()
        NotificationManagerCompat.from(this).notify(symbol.hashCode()+1, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(notificationChannel, "A227C Confirmed Signals", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alerts when A227C changes a market to a confirmed BUY or SELL signal"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notifySignal(symbol: String, direction: String, score: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val intent = android.content.Intent(this, MainActivity::class.java).apply { flags = android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pending = PendingIntent.getActivity(this, symbol.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, notificationChannel)
            .setSmallIcon(R.mipmap.ic_launcher).setContentTitle("A227C $direction — $symbol")
            .setContentText("Confirmed signal state changed. Evidence score: $score/100. Review the full analysis before acting.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("A227C has issued a $direction signal for $symbol. Evidence score: $score/100. This is analysis only; A227C does not place trades."))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pending).build()
        NotificationManagerCompat.from(this).notify(symbol.hashCode(), notification)
    }

    private fun formatDetail(s: JSONObject): String {
        val lines = mutableListOf<String>()
        lines += "${s.optString("symbol")} — ${s.optString("direction", "WAIT")}"
        lines += "Evidence score: ${s.optString("score", "0")}/100 (not a win probability)"
        lines += "Data: ${s.optString("data_health")} | Source: ${s.optString("source")}"
        lines += "News risk: ${s.optString("news_risk", "UNKNOWN")} | Session: ${s.optString("session", "—")}"
        lines += "Feed age: ${s.optString("tick_age_seconds", "—")}s | Spread: ${s.optString("spread", "—")}"
        val quote=s.optJSONObject("live_quote")
        if (quote != null) lines += "LIVE BID ${quote.optString("bid")}  |  ASK ${quote.optString("ask")}  |  LAST ${quote.optString("last")}"
        val regime = s.optJSONObject("market_regime")
        if (regime != null) lines += "Market regime: ${regime.optString("name")} (ADX ${regime.optString("adx14", "—")}, ATR percentile ${regime.optString("atr_percentile", "—")})"
        val tfs = s.optJSONObject("timeframe_state")
        if (tfs != null) lines += "H4 ${tfs.optString("H4")}  •  H1 ${tfs.optString("H1")}  •  M30 ${tfs.optString("M30")}  •  M15 ${tfs.optString("M15")}"
        val structures=s.optJSONObject("timeframe_structure")
        if (structures != null) { lines += "Structure / BOS:"; for (tf in listOf("H4","H1","M30","M15")) { val st=structures.optJSONObject(tf) ?: continue; lines += "• $tf: ${st.optString("state")} | HH ${st.optBoolean("hh")} HL ${st.optBoolean("hl")} LH ${st.optBoolean("lh")} LL ${st.optBoolean("ll")} | BOS↑ ${st.optBoolean("bos_bullish")} BOS↓ ${st.optBoolean("bos_bearish")}" } }
        lines += "Expected: ${s.optString("expected_move", "No confirmed expectation")}"
        lines += "Entry reference: ${s.optString("entry_reference", "—")}"
        lines += "Reference SL: ${s.optString("reference_sl", "—")} | TP: ${s.optString("reference_tp", "—")}"
        lines += "Risk/reward reference: ${s.optString("risk_reward_reference", "—")}"
        lines += "Holding window: ${s.optString("holding_window", "Not calibrated")}"
        val strategies = s.optJSONArray("strategies")
        if (strategies != null) { lines += "Strategy evidence:"; for (i in 0 until strategies.length()) { val st = strategies.optJSONObject(i) ?: continue; lines += "• ${st.optString("name")}: ${st.optString("direction")} — ${st.optString("reason")}" } }
        val correlations = s.optJSONObject("cross_market_correlations")
        if (correlations != null && correlations.length()>0) { lines += "H1 cross-market correlations:"; val keys=correlations.keys(); while(keys.hasNext()) { val key=keys.next(); lines += "• $key: ${correlations.optJSONObject(key)?.optString("pearson_100h1")}" } }
        val events = s.optJSONArray("news_events")
        if (events != null && events.length()>0) { lines += "Relevant economic events:"; for(i in 0 until minOf(events.length(),5)) { val ev=events.optJSONObject(i) ?: continue; lines += "• ${ev.optString("currency")} ${ev.optString("event")}: ${ev.optString("surprise_state")} (actual ${ev.optString("actual")}, forecast ${ev.optString("forecast")})" } }
        val reasons = s.optJSONArray("reasons")
        if (reasons != null) { lines += "Reasons:"; for (i in 0 until reasons.length()) lines += "• ${reasons.optString(i)}" }
        lines += "\nA227C does not place trades. You remain responsible for any manual broker action."
        return lines.joinToString("\n")
    }

    override fun onDestroy() {
        manuallyClosed = true; handler.removeCallbacksAndMessages(null); socket?.close(1000, "App closed")
        super.onDestroy()
    }
}
