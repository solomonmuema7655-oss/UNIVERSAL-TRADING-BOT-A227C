package com.siyoma.a227c

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var feed: TextView
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    private val engineUrl = "ws://10.0.2.2:8765/ws" // Change to the A227C engine host on a real device.
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main); status=findViewById(R.id.status); feed=findViewById(R.id.feed); connect() }
    private fun connect() {
        val req=Request.Builder().url(engineUrl).build()
        client.newWebSocket(req, object: WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) { runOnUiThread { status.text="● LIVE ENGINE CONNECTION" } ; ws.send("subscribe") }
            override fun onMessage(ws: WebSocket, text: String) { runOnUiThread { feed.text=text } }
            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) { runOnUiThread { status.text="DATA CONNECTION ERROR: ${t.message}" } }
            override fun onClosed(ws: WebSocket, code: Int, reason: String) { runOnUiThread { status.text="ENGINE DISCONNECTED" } }
        })
    }
}
