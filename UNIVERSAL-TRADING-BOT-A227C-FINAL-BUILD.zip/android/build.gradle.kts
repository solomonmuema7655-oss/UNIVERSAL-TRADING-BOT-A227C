// Android module container.
