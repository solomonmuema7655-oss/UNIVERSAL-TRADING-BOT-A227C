# A227C implementation and deployment gates

This file prevents the project from being described as live-connected or statistically validated before those conditions are actually demonstrated.

## Implemented in this source package

- Actual saved A227C logo integrated into Android drawable and launcher icon assets.
- Android market dashboard for the five agreed instruments, live quote details, provider status, completed-candle chart (M15/M30/H1/H4), signal detail, local notification alerts, signal history, manual outcome journal, descriptive research summary and walk-forward research action.
- FastAPI backend, authenticated WebSocket, protected REST endpoints, signal persistence, SQLite journal and research summaries.
- MT5 adapter for supported Windows MT5 terminal; configurable symbol mapping and per-symbol availability status.
- Deriv public WebSocket adapter with active-symbol discovery and tick subscription; Deriv data is isolated from MT5 price series.
- Trading Economics calendar, surprise comparison and policy-rate / 10-year yield retrieval adapters.
- Tick freshness, timestamp, candle-history, indicator warm-up, spread/ATR, news-risk and M15 confirmation gates.
- H4/H1/M30/M15 analysis, market-regime classification, structure/BOS, EMA/RSI/MACD/ATR/ADX/ROC, session logic, liquidity-pool/sweep and order-block candidate logic, carry context and cross-market correlations.
- Signal invalidation transition events, reference SL/TP and a score explicitly labelled as evidence rather than win probability.
- Historical walk-forward OHLC research for selected coded market/strategy combinations.
- GitHub Actions workflow for backend tests and Android Debug/Release APK artifacts using Ubuntu 22.04, Java 17 and Gradle 8.7.

## Must be completed/verified with deployment access

1. **MT5 live connection:** install MT5 on the intended Windows VPS, log into the intended data account, verify the five actual broker symbols and confirm ticks/candles remain fresh through market sessions and reconnects.
2. **Deriv live connection:** supply/register the application's Deriv app ID and configure exact active symbols. The current Deriv adapter captures and validates live ticks; it does not yet construct a separate full Deriv OHLC strategy-analysis pipeline.
3. **News and macro provider:** configure a valid Trading Economics subscription/API key, verify calendar currency fields and the exact policy-rate / 10-year yield indicator names/values for the subscribed plan, and verify update timestamps. Until the calendar is connected and fresh, confirmed signals are blocked.
4. **Carry trade:** verify provider policy rates, 10-year yield differentials and account-specific MT5 long/short swap values. Carry remains context only and never triggers an entry by itself.
5. **Push when app is terminated:** Android local sound/vibration notifications work while connected. Firebase Cloud Messaging requires a project-specific Android configuration and server credentials before reliable remote push can be enabled when the app is not running.
6. **Backtest realism:** current OHLC harness applies a supplied full-spread assumption and conservative stop-first same-bar handling. It does not yet model commissions, variable historical spread, slippage or financing/swap. These must be added before any performance claim.
7. **Research completeness:** MAE/MFE, larger sample score calibration, richer per-regime/per-session reports, robust bootstrap/significance checks and full multi-strategy portfolio correlation exposure remain to be completed and validated.
8. **Risk profile:** A227C has no broker account access and cannot read open positions or account drawdown. Daily loss, max-trade and account-exposure protections must be based on explicitly recorded user journal/position data or remain user-managed; the app must never pretend to know account exposure.
9. **Android release verification:** run the GitHub Actions workflow and install/test both APK artifacts on physical Android devices. This environment did not have a local Android SDK/Gradle installation, so no local APK build is claimed here.
10. **Security deployment:** replace the example token, deploy behind TLS/WSS, restrict host/network access, keep provider credentials outside source control and test unauthorized requests.

No item above may be silently treated as complete merely because the source compiles. No profitability, accuracy percentage or live connection is claimed until it is measured and observed.
