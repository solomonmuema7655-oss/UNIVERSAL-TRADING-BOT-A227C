# UNIVERSAL-TRADING-BOT-A227C — Product Specification

## Product identity and boundary

A227C is SIYOMA's final intended real-time algorithmic market-analysis and signal application. It is not a broker execution bot. It never places, modifies or closes orders, never logs into a broker for trading permissions, and never controls the user's account. The user manually decides whether to act on any signal through their own broker/platform.

The live decision system is deterministic/rule-based and statistically evaluated. It does not use an AI agent, LLM, AI-generated signal, machine-learning prediction or external AI confidence score. Prediction means a forward-looking market expectation calculated from current market data and validated analytical rules.

## Initial instruments and providers

Five initial markets: XAUUSD, USTECH100, GBPJPY, GBPUSD and USDJPY. MT5/Exness is one provider ecosystem; MT5 is the terminal/platform and Exness is the broker. Provider symbol names are configurable and must be verified against the account. Deriv has its own adapter and symbol namespace; a similarly named Deriv synthetic contract is not the same instrument as an Exness CFD or cash index.

The MT5 Python adapter requires an installed and logged-in supported MT5 terminal on a Windows host. Deriv uses its public market-data WebSocket. News/calendar and policy-rate context use a separately credentialed provider adapter. No credentials are stored in the Android package.

## Live-data lifecycle

Receive source tick → record provider symbol/source timestamp/receive timestamp → validate price, spread, freshness and source → detect missing/duplicate/out-of-order data → update provider-isolated time series → update completed OHLC bars → update indicators and structure → evaluate relevant strategy modules → apply macro/news/correlation/risk gates → calculate evidence score → decide BUY/SELL/WAIT → publish explainable snapshot → monitor invalidation.

The system distinguishes forming candles from completed candles. Closed-candle rules operate only on completed candles. H4/H1/M30/M15 are mandatory; M15 is the final entry-confirmation gate. Stale ticks, incomplete history, stale candles, unavailable news context and invalid spreads fail closed to WAIT.

## Markets and timeframe protocol

- H4: macro/broad market structure, trend, major levels and volatility.
- H1: primary directional confirmation and pullback context.
- M30: setup development, session and liquidity context.
- M15: final entry validation, rejection/continuation and invalidation.
- Timeframe conflicts must be displayed and explained. No timeframe is silently skipped.

## Strategy modules

### Pullback to support/resistance

Initial focus: USDJPY. Determine H4/H1 direction, identify confirmed swing/level context, detect a pullback toward the trend reference and require a completed M15 rejection/continuation confirmation. Macro policy divergence is contextual, not a substitute for technical confirmation.

### London/New York session breakout

Initial focus: GBPUSD and XAUUSD. Compute the Tokyo/Asian session range from timestamped provider candles. Require a qualifying close beyond the range, directional body/range expansion, and evaluate retest, spread, volatility, session and scheduled news. If the Asian range cannot be calculated, the module returns WAIT.

### Liquidity and SMC

Initial focus: XAUUSD. Use objective swing liquidity boundaries, equal-high/low pool candidates, sweep/reclaim, displacement, break-of-structure and retest conditions. The current detector identifies an objective last-opposite-candle zone candidate after displacement and requires a retest/reclaim. A mechanical detector cannot claim to know that a bank or institution placed an order; the order-block candidate still requires market-specific statistical validation.

### Carry trade

Initial focus: USDJPY. Use provider-sourced current policy-rate differential, government 10-year yield differential and MT5 broker-side long/short swap context, plus reversal/intervention/news risk. Carry is a macro directional/holding-context filter, never a standalone M15 trigger. The current implementation withholds carry confirmation if policy-rate/yield data or positive broker-side swap context is unavailable. Missing source data means carry context is unavailable, not guessed.

EURUSD and AUDJPY mentioned in strategy notes are not added to the initial five-market universe. GBPJPY and USTECH100 remain without a primary validated strategy assignment until research supports one.

## Analytical engines

Market regime; market structure HH/HL/LH/LL, BOS and structure shifts; EMA trend context; RSI/MACD/ROC momentum; ATR and volatility expansion/contraction; support/resistance and supply/demand; liquidity sweeps and break/retest; Asian/London/New York session calendar; economic calendar and surprise; central-bank policy/yield differentials; cross-market correlation; provider spread/data-quality filters; risk/reward and signal invalidation.

Indicators are evidence inputs, not autonomous signal generators. The engine must explain WHY BUY, WHY SELL or WHY WAIT.

## Signal contract

A signal snapshot records instrument/provider, timestamp, H4/H1/M30/M15 states, strategy evidence, market regime, news risk, spread/data health, evidence score, entry reference, invalidation, reference SL/TP, expected movement and holding window. SL/TP are reference analysis only. The score is not a probability unless a separate statistically sufficient calibration demonstrates that relationship. No confirmed signal may be issued without a defined protective invalidation/SL reference.

## Journaling and research

Persist immutable signal snapshots by market and completed M15 bar. Users can manually record WIN/LOSS/BREAKEVEN outcomes. Research summaries calculate statistics only from recorded outcomes; missing labels are not treated as losses or wins. The integrated research area includes a chronological 60/40 walk-forward OHLC harness for currently coded USDJPY trend-pullback, XAUUSD SMC and GBPUSD/XAUUSD session-breakout combinations. It requires a positive full-spread assumption and resolves same-candle stop/target ambiguity conservatively. Commissions, variable historical spread, slippage and financing are not yet modeled by this harness and must be included before treating results as deployment-grade validation. Research metrics also include recorded outcome expectancy, profit factor, drawdown, consecutive losses and score buckets; MAE/MFE and richer strategy/regime breakdowns remain future validation enhancements.

## Android and backend

The backend is the owner of continuous market capture, time-series, strategy evaluation, signal history and notifications. Android is the monitoring/control interface. It displays the actual feed state and timestamp, five-market status, signal details, history and manual outcome journal. It must not fabricate live prices or pretend to be connected when disconnected. The backend reconnects and backfills; mobile reconnects and requests a snapshot.

## Security and build

No broker execution endpoints or credentials. Store provider secrets server-side only. Require a strong API token and TLS/WSS for remote deployments. Use secure secret management in CI. GitHub Actions: Ubuntu 22.04, Java 17, Gradle 8.7; produce Debug and Release APK artifacts. Release APK remains unsigned until a deliberate secure signing configuration is supplied.

## Acceptance criteria

A227C is not accepted as live-operational until actual MT5 feed connection, five-symbol mapping, Deriv endpoint and symbol configuration, news/calendar credentials, policy-rate data, closed-candle integrity, reconnection/recovery, Android-to-backend secure communication and all five market statuses are demonstrated. Strategy profitability and signal calibration require independent market-specific empirical validation. A build artifact alone does not prove live connectivity or profitability.
