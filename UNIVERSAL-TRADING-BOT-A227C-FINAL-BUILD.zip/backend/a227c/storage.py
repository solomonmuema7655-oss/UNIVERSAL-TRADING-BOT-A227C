import json, os, sqlite3
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime, timezone
DB=Path(os.getenv('A227C_DB',str(Path(__file__).resolve().parents[1]/'a227c.sqlite3')))

def _db():
    DB.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('''CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY AUTOINCREMENT,symbol TEXT NOT NULL,bar_time TEXT NOT NULL,created_at TEXT NOT NULL,direction TEXT NOT NULL,score REAL NOT NULL,quality TEXT,source TEXT,data_health TEXT,payload TEXT NOT NULL,UNIQUE(symbol,bar_time,direction))''')
    c.execute('''CREATE TABLE IF NOT EXISTS outcomes(id INTEGER PRIMARY KEY AUTOINCREMENT,signal_id INTEGER NOT NULL UNIQUE,outcome TEXT NOT NULL,realized_r REAL,notes TEXT,recorded_at TEXT NOT NULL,FOREIGN KEY(signal_id) REFERENCES signals(id))''')
    c.commit(); return c

@contextmanager
def db():
    c=_db()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback(); raise
    finally: c.close()

def save_signal(s):
    bar=s.get('bar_timestamp') or s.get('timestamp') or datetime.now(timezone.utc).isoformat()
    with db() as c:
        c.execute('INSERT OR IGNORE INTO signals(symbol,bar_time,created_at,direction,score,quality,source,data_health,payload) VALUES(?,?,?,?,?,?,?,?,?)',
          (s.get('symbol',''),bar,s.get('timestamp',''),s.get('direction','WAIT'),float(s.get('score',0)),s.get('quality'),s.get('source'),s.get('data_health'),json.dumps(s,default=str)))
        row=c.execute('SELECT id FROM signals WHERE symbol=? AND bar_time=? AND direction=?',(s.get('symbol',''),bar,s.get('direction','WAIT'))).fetchone()
        return int(row['id']) if row else None

def history(limit=100):
    with db() as c: rows=c.execute('SELECT * FROM signals ORDER BY id DESC LIMIT ?', (max(1,min(int(limit),500)),)).fetchall()
    return [dict(r) for r in rows]

def record_outcome(signal_id,outcome,realized_r=None,notes=''):
    if outcome not in ('WIN','LOSS','BREAKEVEN'): raise ValueError('outcome must be WIN, LOSS or BREAKEVEN')
    with db() as c:
        row=c.execute('SELECT id FROM signals WHERE id=?',(int(signal_id),)).fetchone()
        if not row: raise LookupError('No matching A227C signal snapshot')
        c.execute('INSERT OR REPLACE INTO outcomes(signal_id,outcome,realized_r,notes,recorded_at) VALUES(?,?,?,?,?)',(row['id'],outcome,realized_r,notes,datetime.now(timezone.utc).isoformat()))

def research():
    with db() as c: rows=c.execute('SELECT s.symbol,s.score,o.outcome,o.realized_r FROM outcomes o JOIN signals s ON s.id=o.signal_id ORDER BY o.id').fetchall()
    by={}
    for r in rows: by.setdefault(r['symbol'],[]).append(r)
    result={}
    for sym,items in by.items():
        rs=[float(x['realized_r']) for x in items if x['realized_r'] is not None]
        wins=sum(x['outcome']=='WIN' for x in items); losses=sum(x['outcome']=='LOSS' for x in items)
        gains=sum(x for x in rs if x>0); downs=abs(sum(x for x in rs if x<0))
        streak=longest=0
        for item in items:
            if item['outcome']=='LOSS': streak+=1; longest=max(longest,streak)
            elif item['outcome']=='WIN': streak=0
        buckets={}
        for low,high in ((0,49),(50,59),(60,69),(70,79),(80,89),(90,100)):
            group=[x for x in items if low<=float(x['score'])<=high]
            if group: buckets[f'{low}-{high}']={'signals':len(group),'win_rate_pct':round(100*sum(x['outcome']=='WIN' for x in group)/len(group),2)}
        result[sym]={'closed_outcomes':len(items),'wins':wins,'losses':losses,'win_rate_pct':round(100*wins/len(items),2) if items else None,
          'average_realized_r':round(sum(rs)/len(rs),3) if rs else None,'expectancy_r':round(sum(rs)/len(rs),3) if rs else None,
          'profit_factor':round(gains/downs,3) if downs else (None if gains==0 else 'infinite'),'longest_consecutive_losses':longest,
          'score_calibration_buckets':buckets,'metrics_note':'Based only on manually recorded outcomes; sample size and selection bias must be considered. Not a forecast.'}
    return {'by_market':result,'total_recorded_outcomes':len(rows),'unlabeled_signals':max(0,len(history(500))-len(rows))}
