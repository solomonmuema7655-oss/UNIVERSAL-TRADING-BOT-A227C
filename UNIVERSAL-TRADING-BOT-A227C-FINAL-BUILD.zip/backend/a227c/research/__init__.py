"""Research and validation utilities; never connected to broker execution."""
