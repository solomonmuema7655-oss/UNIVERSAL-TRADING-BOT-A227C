from . import __doc__
from ..core.indicators import enrich
from ..core.strategies import trend_pullback, liquidity_smc, session_breakout
from ..core.sessions import session_name
from zoneinfo import ZoneInfo

def _metrics(trades):
    rs=[float(t['r_multiple']) for t in trades]
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<0]
    gross_win=sum(wins); gross_loss=abs(sum(losses))
    peak=0.0; equity=0.0; max_dd=0.0
    for r in rs:
        equity+=r; peak=max(peak,equity); max_dd=max(max_dd,peak-equity)
    streak=longest=0
    for r in rs:
        if r<0: streak+=1; longest=max(longest,streak)
        elif r>0: streak=0
    return {'trades':len(rs),'wins':len(wins),'losses':len(losses),'win_rate_pct':round(100*len(wins)/len(rs),2) if rs else None,
            'expectancy_r':round(sum(rs)/len(rs),3) if rs else None,'profit_factor':round(gross_win/gross_loss,3) if gross_loss else (None if not gross_win else 'infinite'),
            'max_drawdown_r':round(max_dd,3),'longest_consecutive_losses':longest}

def run_bar_backtest(frame,strategy,symbol,timeframe,spread_cost,max_holding_bars=48,start=205):
    """Conservative OHLC backtest. Entry is next bar; same-bar SL/TP ambiguity resolves to SL first."""
    if spread_cost is None or spread_cost<=0: raise ValueError('A positive full-spread cost assumption is required; zero-cost backtests are rejected')
    if len(frame)<start+max_holding_bars+2: raise ValueError('Insufficient bars for requested backtest window')
    if strategy=='TREND_PULLBACK' and symbol=='USDJPY' and timeframe in ('H1','H4'): evaluator=trend_pullback
    elif strategy=='LIQUIDITY_SMC' and symbol=='XAUUSD' and timeframe=='M15': evaluator=liquidity_smc
    elif strategy=='SESSION_BREAKOUT' and symbol in ('GBPUSD','XAUUSD') and timeframe in ('M15','M30'):
        def evaluator(hist):
            local=hist.index.tz_convert(ZoneInfo('Asia/Tokyo')); day=hist.index[-1].to_pydatetime().astimezone(ZoneInfo('Asia/Tokyo')).date()
            mask=(local.date==day)&(local.hour>=0)&(local.hour<8); asian=hist.loc[mask]
            if len(asian)<4: return {'direction':'WAIT','reason':'Asian range unavailable in historical window'}
            return session_breakout(hist,float(asian.high.max()),float(asian.low.min()),session_name(hist.index[-1].to_pydatetime()))
    else: raise ValueError('This market/timeframe/strategy combination has no implemented backtest rule')
    data=enrich(frame); trades=[]; i=start
    while i < len(data)-max_holding_bars-1:
        hist=data.iloc[:i+1]; signal=evaluator(hist); direction=signal['direction']
        if direction not in ('BUY','SELL'):
            i+=1; continue
        entry_bar=data.iloc[i+1]; atr=float(hist.iloc[-1].atr14)
        if atr<=0 or atr!=atr: i+=1; continue
        half=spread_cost/2.0
        entry=float(entry_bar.open)+(half if direction=='BUY' else -half)
        risk=1.5*atr; target=2.0*atr
        stop=entry-risk if direction=='BUY' else entry+risk
        take=entry+target if direction=='BUY' else entry-target
        exit_price=None; exit_index=None; exit_reason='TIME_EXIT'
        end=min(len(data)-1,i+1+max_holding_bars)
        for j in range(i+1,end+1):
            bar=data.iloc[j]
            if direction=='BUY':
                hit_stop=float(bar.low)<=stop; hit_take=float(bar.high)>=take
                if hit_stop: exit_price=stop-half; exit_index=j; exit_reason='STOP' if not hit_take else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if hit_take: exit_price=take-half; exit_index=j; exit_reason='TARGET'; break
            else:
                hit_stop=float(bar.high)>=stop; hit_take=float(bar.low)<=take
                if hit_stop: exit_price=stop+half; exit_index=j; exit_reason='STOP' if not hit_take else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if hit_take: exit_price=take+half; exit_index=j; exit_reason='TARGET'; break
        if exit_price is None:
            last=data.iloc[end]; exit_price=float(last.close)+(-half if direction=='BUY' else half); exit_index=end
        pnl=(exit_price-entry) if direction=='BUY' else (entry-exit_price)
        trades.append({'signal_time':str(data.index[i]),'entry_time':str(data.index[i+1]),'exit_time':str(data.index[exit_index]),'direction':direction,
                       'entry':entry,'stop':stop,'target':take,'exit':exit_price,'r_multiple':round(pnl/risk,4),'exit_reason':exit_reason,'strategy_reason':signal['reason']})
        i=exit_index+1
    return {'symbol':symbol,'timeframe':timeframe,'strategy':strategy,'spread_cost_assumption':spread_cost,'stop_atr':1.5,'target_atr':2.0,
            'same_bar_policy':'Conservative: stop assumed first when stop and target are both touched in one OHLC candle',
            'cost_limitations':'Full spread cost assumption is applied; commissions, variable historical spreads, slippage and swap are not modeled by this OHLC harness.',
            'overall':_metrics(trades),'trades':trades}

def walk_forward(frame,strategy,symbol,timeframe,spread_cost,train_fraction=0.6,max_holding_bars=48):
    split=int(len(frame)*train_fraction)
    if split<260 or len(frame)-split<260: raise ValueError('Need at least 260 bars in both chronological in-sample and out-of-sample windows')
    train=run_bar_backtest(frame.iloc[:split],strategy,symbol,timeframe,spread_cost,max_holding_bars)
    test=run_bar_backtest(frame.iloc[split:],strategy,symbol,timeframe,spread_cost,max_holding_bars)
    return {'symbol':symbol,'strategy':strategy,'timeframe':timeframe,'split_index':str(frame.index[split]),'in_sample':train['overall'],'out_of_sample':test['overall'],
            'out_of_sample_trades':test['trades'],'validation_note':'Fixed rules; no parameter tuning. Historical OHLC simulation only, not live execution or a profitability guarantee.'}
