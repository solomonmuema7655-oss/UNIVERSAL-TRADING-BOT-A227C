from datetime import datetime, timezone
import pandas as pd
try:
    import MetaTrader5 as mt5
except ImportError:
    mt5=None

class MT5Adapter:
    def __init__(self, symbols): self.symbols=symbols; self.connected=False; self.available_symbols=set(); self.symbol_errors={}
    def connect(self):
        if mt5 is None: raise RuntimeError('MetaTrader5 Python package is available only on a supported Windows MT5 host')
        if not mt5.initialize(): raise RuntimeError(f'MT5 initialize failed: {mt5.last_error()}')
        self.connected=True
        for symbol in self.symbols.values():
            if mt5.symbol_select(symbol,True): self.available_symbols.add(symbol)
            else: self.symbol_errors[symbol]=str(mt5.last_error())
        if not self.available_symbols: raise RuntimeError('No configured A227C symbols are available in MT5 Market Watch')
        return True
    def tick(self,symbol):
        t=mt5.symbol_info_tick(symbol)
        if t is None:return None
        ts=datetime.fromtimestamp(t.time_msc/1000,timezone.utc) if getattr(t,'time_msc',0) else datetime.fromtimestamp(t.time,timezone.utc)
        info=mt5.symbol_info(symbol)
        return {'symbol':symbol,'time':ts,'bid':float(t.bid),'ask':float(t.ask),'last':float(t.last),'volume':float(t.volume),
                'swap_long':float(info.swap_long) if info else None,'swap_short':float(info.swap_short) if info else None,
                'point':float(info.point) if info else None,'digits':int(info.digits) if info else None}
    def bars(self,symbol,timeframe,count=500,closed_only=True):
        tf={'M15':mt5.TIMEFRAME_M15,'M30':mt5.TIMEFRAME_M30,'H1':mt5.TIMEFRAME_H1,'H4':mt5.TIMEFRAME_H4}[timeframe]
        rates=mt5.copy_rates_from_pos(symbol,tf,1 if closed_only else 0,count)
        if rates is None or len(rates)==0:return pd.DataFrame()
        df=pd.DataFrame(rates); df['time']=pd.to_datetime(df['time'],unit='s',utc=True)
        return df.rename(columns={'tick_volume':'volume'}).set_index('time').sort_index()
    def shutdown(self):
        if mt5 is not None and self.connected: mt5.shutdown()
        self.connected=False
