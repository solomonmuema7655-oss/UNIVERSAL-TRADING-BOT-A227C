import time
from datetime import datetime, timezone
import pandas as pd
try:
    import MetaTrader5 as mt5
except ImportError:
    mt5=None

class MT5Adapter:
    def __init__(self, symbols): self.symbols=symbols; self.connected=False
    def connect(self):
        if mt5 is None: raise RuntimeError('MetaTrader5 package is available only on a Windows MT5 host')
        self.connected=bool(mt5.initialize())
        if not self.connected: raise RuntimeError(f'MT5 initialize failed: {mt5.last_error()}')
    def tick(self, symbol):
        t=mt5.symbol_info_tick(symbol)
        if t is None:return None
        return {'symbol':symbol,'time':datetime.fromtimestamp(t.time,timezone.utc),'bid':float(t.bid),'ask':float(t.ask),'last':float(t.last),'volume':float(t.volume)}
    def bars(self,symbol,timeframe,count=300):
        tf={'M15':mt5.TIMEFRAME_M15,'M30':mt5.TIMEFRAME_M30,'H1':mt5.TIMEFRAME_H1,'H4':mt5.TIMEFRAME_H4}[timeframe]
        rates=mt5.copy_rates_from_pos(symbol,tf,0,count)
        if rates is None:return pd.DataFrame()
        df=pd.DataFrame(rates); df['time']=pd.to_datetime(df['time'],unit='s',utc=True); return df.rename(columns={'tick_volume':'volume'}).set_index('time')
