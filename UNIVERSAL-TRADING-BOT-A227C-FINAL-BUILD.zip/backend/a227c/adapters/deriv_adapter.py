import asyncio, json, websockets
class DerivAdapter:
    def __init__(self, endpoint, symbols): self.endpoint=endpoint; self.symbols=symbols
    async def stream(self, on_tick):
        async with websockets.connect(self.endpoint, ping_interval=20, ping_timeout=20) as ws:
            for s in self.symbols:
                await ws.send(json.dumps({'ticks':s,'subscribe':1}))
            async for raw in ws:
                msg=json.loads(raw)
                tick=msg.get('tick')
                if tick: await on_tick(tick)
