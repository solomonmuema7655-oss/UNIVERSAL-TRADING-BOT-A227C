import asyncio, json, websockets

class DerivAdapter:
    """Public market-data only. Deriv contracts remain isolated from MT5 instruments."""
    def __init__(self, endpoint, symbols): self.endpoint=endpoint; self.symbols=symbols; self.connected=False; self.available=set()
    async def run(self,on_tick,on_status):
        delay=2
        while True:
            try:
                async with websockets.connect(self.endpoint,ping_interval=20,ping_timeout=20,open_timeout=15) as ws:
                    await ws.send(json.dumps({'active_symbols':'brief','product_type':'basic'}))
                    raw=await asyncio.wait_for(ws.recv(),timeout=20)
                    response=json.loads(raw)
                    if response.get('error'): raise RuntimeError(response['error'].get('message','Deriv active-symbol request failed'))
                    active=response.get('active_symbols') or []
                    self.available={item.get('symbol') for item in active if item.get('symbol')}
                    missing={internal:provider for internal,provider in self.symbols.items() if provider not in self.available}
                    for internal,provider in self.symbols.items():
                        if provider in self.available: await ws.send(json.dumps({'ticks':provider,'subscribe':1}))
                    self.connected=True; delay=2
                    await on_status({'state':'CONNECTED','available_symbols':sorted(self.available),'configured_missing':missing})
                    async for raw in ws:
                        msg=json.loads(raw)
                        if msg.get('error'):
                            await on_status({'state':'ERROR','message':msg['error'].get('message','Deriv API error')}); continue
                        tick=msg.get('tick')
                        if tick:
                            await on_tick({'internal_symbol':next((k for k,v in self.symbols.items() if v==tick.get('symbol')),'UNMAPPED'), 'provider_symbol':tick.get('symbol'),'epoch':tick.get('epoch'),'quote':tick.get('quote'),'source':'DERIV'})
            except asyncio.CancelledError: raise
            except Exception as exc:
                self.connected=False; await on_status({'state':'DISCONNECTED','message':str(exc)}); await asyncio.sleep(delay); delay=min(delay*2,60)
