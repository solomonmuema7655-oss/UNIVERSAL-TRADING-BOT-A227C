import requests
from datetime import datetime, timezone, timedelta
class TradingEconomicsNews:
    def __init__(self, api_key): self.key=api_key
    def upcoming(self, countries=('United States','United Kingdom','Japan'), importance=2):
        if not self.key:return []
        url='https://api.tradingeconomics.com/calendar'
        r=requests.get(url,params={'c':self.key,'importance':importance},timeout=10); r.raise_for_status()
        out=[]
        for e in r.json():
            if e.get('Country') in countries:
                out.append(e)
        return out
