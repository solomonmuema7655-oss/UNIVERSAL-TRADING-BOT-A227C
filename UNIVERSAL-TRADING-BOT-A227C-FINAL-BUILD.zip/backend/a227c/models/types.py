from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional

@dataclass
class Tick:
    symbol: str
    ts: datetime
    bid: float
    ask: float
    last: float = 0.0
    volume: float = 0.0
    source: str = "unknown"

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0 if self.bid and self.ask else self.last

@dataclass
class NewsEvent:
    ts: datetime
    country: str
    currency: str
    event: str
    importance: int
    actual: Optional[str] = None
    forecast: Optional[str] = None
    previous: Optional[str] = None

@dataclass
class AnalysisSnapshot:
    symbol: str
    ts: datetime
    direction: str = "WAIT"
    score: float = 0.0
    quality: str = "INSUFFICIENT"
    expected_move: str = "Unknown"
    holding_window: str = "Unknown"
    reasons: List[str] = field(default_factory=list)
    timeframe_state: Dict[str, str] = field(default_factory=dict)
    data_health: str = "UNKNOWN"
    news_risk: str = "UNKNOWN"
    strategy: str = "None"
    entry_zone: str = ""
    invalidation: str = ""
    reference_sl: str = ""
    reference_tp: str = ""
