import asyncio, json, os
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from .adapters.mt5_adapter import MT5Adapter
from .adapters.deriv_adapter import DerivAdapter
from .core.decision import analyze

BASE=Path(__file__).resolve().parents[1]
CONFIG=BASE/'config.json'
if CONFIG.exists(): cfg=json.loads(CONFIG.read_text())
else: cfg=json.loads((BASE/'config.example.json').read_text())

app=FastAPI(title='A227C Real-Time Market Engine')
clients=set(); state={}; frames={}
SYMBOLS=list(cfg['mt5']['symbols'].keys())

@app.get('/health')
async def health():
    return JSONResponse({'status':'ok','engine':'A227C','data_symbols':SYMBOLS,'clients':len(clients)})

async def broadcast(payload):
    dead=[]
    msg=json.dumps(payload)
    for ws in clients:
        try: await ws.send_text(msg)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)

async def mt5_loop():
    if not cfg['mt5']['enabled']: return
    adapter=MT5Adapter(cfg['mt5']['symbols'])
    adapter.connect()
    for internal, provider in cfg['mt5']['symbols'].items():
        frames[internal]={k:adapter.bars(provider,k,cfg['engine']['minimum_bars']) for k in ('M15','M30','H1','H4')}
    while True:
        for internal, provider in cfg['mt5']['symbols'].items():
            t=adapter.tick(provider)
            if not t: continue
            state[internal]={'tick':{k:(v.isoformat() if hasattr(v,'isoformat') else v) for k,v in t.items()},'source':'MT5','received_at':datetime.now(timezone.utc).isoformat()}
            # Refresh bars each cycle so the engine always has current closed/current bars.
            for k in ('M15','M30','H1','H4'): frames[internal][k]=adapter.bars(provider,k,cfg['engine']['minimum_bars'])
            result=analyze(internal,frames[internal],news_risk='UNKNOWN',threshold=cfg['engine']['signal_score_threshold'])
            result['tick']=state[internal]['tick']; await broadcast({'type':'signal','data':result})
        await asyncio.sleep(1.0)

@app.websocket('/ws')
async def ws(websocket:WebSocket):
    await websocket.accept(); clients.add(websocket)
    try:
        await websocket.send_text(json.dumps({'type':'hello','engine':'A227C','message':'Live analysis channel connected'}))
        while True: await websocket.receive_text()
    except WebSocketDisconnect: clients.discard(websocket)
    except Exception: clients.discard(websocket)

@app.on_event('startup')
async def startup():
    if cfg['mt5']['enabled']:
        asyncio.create_task(mt5_loop())
