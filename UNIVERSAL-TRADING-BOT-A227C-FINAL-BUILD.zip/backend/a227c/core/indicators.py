import numpy as np
import pandas as pd

def ema(s: pd.Series, n: int): return s.ewm(span=n, adjust=False).mean()
def rsi(s: pd.Series, n: int = 14):
    d=s.diff(); up=d.clip(lower=0); dn=-d.clip(upper=0)
    rs=up.ewm(alpha=1/n, adjust=False).mean()/dn.ewm(alpha=1/n, adjust=False).mean().replace(0,np.nan)
    return 100-(100/(1+rs))
def atr(df: pd.DataFrame, n: int = 14):
    pc=df.close.shift(1)
    tr=pd.concat([(df.high-df.low),(df.high-pc).abs(),(df.low-pc).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()
def macd(s: pd.Series):
    fast=ema(s,12); slow=ema(s,26); line=fast-slow; sig=ema(line,9)
    return line, sig, line-sig

def enrich(df: pd.DataFrame) -> pd.DataFrame:
    x=df.copy()
    x['ema20']=ema(x.close,20); x['ema50']=ema(x.close,50); x['ema200']=ema(x.close,200)
    x['rsi14']=rsi(x.close); x['atr14']=atr(x); x['macd'],x['macd_signal'],x['macd_hist']=macd(x.close)
    x['roc10']=x.close.pct_change(10)*100
    x['range']=x.high-x.low
    x['body']=(x.close-x.open).abs()
    return x
