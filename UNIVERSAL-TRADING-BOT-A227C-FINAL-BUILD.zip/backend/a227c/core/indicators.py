import numpy as np
import pandas as pd

def ema(s, n): return s.ewm(span=n, adjust=False).mean()
def rsi(s, n=14):
    d=s.diff(); up=d.clip(lower=0); down=-d.clip(upper=0)
    avg_up=up.ewm(alpha=1/n, adjust=False).mean(); avg_down=down.ewm(alpha=1/n, adjust=False).mean()
    rs=avg_up/avg_down.replace(0,np.nan); out=100-(100/(1+rs))
    out=out.mask((avg_down==0)&(avg_up>0),100.0).mask((avg_down==0)&(avg_up==0),50.0)
    return out
def atr(df, n=14):
    pc=df.close.shift(1)
    tr=pd.concat([(df.high-df.low),(df.high-pc).abs(),(df.low-pc).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n, adjust=False).mean()
def enrich(df):
    x=df.copy()
    for c in ('open','high','low','close'):
        x[c]=pd.to_numeric(x[c],errors='coerce')
    x=x.dropna(subset=['open','high','low','close'])
    x['ema20']=ema(x.close,20); x['ema50']=ema(x.close,50); x['ema200']=ema(x.close,200)
    x['rsi14']=rsi(x.close); x['atr14']=atr(x); fast=ema(x.close,12); slow=ema(x.close,26)
    x['macd']=fast-slow; x['macd_signal']=ema(x.macd,9); x['macd_hist']=x.macd-x.macd_signal
    x['roc10']=x.close.pct_change(10)*100; x['range']=x.high-x.low; x['body']=(x.close-x.open).abs()
    x['body_ratio']=x.body/x.range.replace(0,np.nan)
    up_move=x.high.diff(); down_move=-x.low.diff()
    plus_dm=up_move.where((up_move>down_move)&(up_move>0),0.0); minus_dm=down_move.where((down_move>up_move)&(down_move>0),0.0)
    tr=atr(x,14); plus_di=100*plus_dm.ewm(alpha=1/14,adjust=False).mean()/tr.replace(0,np.nan)
    minus_di=100*minus_dm.ewm(alpha=1/14,adjust=False).mean()/tr.replace(0,np.nan)
    dx=100*(plus_di-minus_di).abs()/(plus_di+minus_di).replace(0,np.nan)
    x['adx14']=dx.ewm(alpha=1/14,adjust=False).mean()
    return x.replace([np.inf,-np.inf],np.nan)
