def correlation_snapshot(symbol, all_frames):
    out={}
    base=all_frames.get(symbol,{}).get('H1')
    if base is None or len(base)<60:return out
    base_ret=base.close.pct_change().dropna().tail(100)
    for other,frames in all_frames.items():
        if other==symbol: continue
        df=frames.get('H1')
        if df is None or len(df)<60: continue
        other_ret=df.close.pct_change().dropna().tail(100)
        joined=base_ret.rename('a').to_frame().join(other_ret.rename('b'),how='inner').dropna()
        if len(joined)>=50: out[other]={'pearson_100h1':round(float(joined.a.corr(joined.b)),3),'observations':len(joined)}
    return out
