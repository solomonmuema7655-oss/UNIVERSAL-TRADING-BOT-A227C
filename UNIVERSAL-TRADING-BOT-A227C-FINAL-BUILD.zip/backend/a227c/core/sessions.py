from zoneinfo import ZoneInfo
from datetime import datetime

def asian_range(df):
    """Current Tokyo calendar-day range, using UTC-indexed completed bars."""
    if df is None or df.empty:return None
    tokyo=df.index.tz_convert(ZoneInfo('Asia/Tokyo'))
    today=datetime.now(ZoneInfo('Asia/Tokyo')).date()
    mask=(tokyo.date==today)&(tokyo.hour>=0)&(tokyo.hour<8)
    x=df.loc[mask]
    if len(x)<4:return None
    return {'asian_high':float(x.high.max()),'asian_low':float(x.low.min()),'bars':len(x),'date':today.isoformat()}

def session_name(now=None):
    now=now or datetime.now(ZoneInfo('UTC'))
    london=now.astimezone(ZoneInfo('Europe/London')); ny=now.astimezone(ZoneInfo('America/New_York'))
    l=london.hour*60+london.minute; n=ny.hour*60+ny.minute
    if 7*60<=l<16*60 and 8*60<=n<17*60:return 'LONDON_NEW_YORK_OVERLAP'
    if 7*60<=l<16*60:return 'LONDON'
    if 8*60<=n<17*60:return 'NEW_YORK'
    return 'ASIAN_OR_OFF_SESSION'
