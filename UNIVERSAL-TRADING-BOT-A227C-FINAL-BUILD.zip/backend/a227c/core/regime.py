def classify_regime(df):
    if df is None or len(df)<120: return {'name':'UNKNOWN','reason':'Insufficient history for regime classification'}
    x=df.iloc[-1]; atrs=df.atr14.dropna().tail(100)
    if len(atrs)<50: return {'name':'UNKNOWN','reason':'ATR regime sample incomplete'}
    pct=float((atrs<=float(x.atr14)).mean())
    adx=float(x.adx14) if 'adx14' in df.columns and x.adx14==x.adx14 else 0.0
    if adx>=25 and x.ema20>x.ema50>x.ema200: name='TRENDING_UP'
    elif adx>=25 and x.ema20<x.ema50<x.ema200: name='TRENDING_DOWN'
    elif pct>=0.85: name='HIGH_VOLATILITY'
    elif adx<18 and pct<0.50: name='RANGING'
    elif adx<18: name='CONSOLIDATING'
    else: name='TRANSITIONAL'
    return {'name':name,'adx14':round(adx,2),'atr_percentile':round(pct,2),'reason':'Rule-based regime estimate; thresholds require market-specific validation'}
