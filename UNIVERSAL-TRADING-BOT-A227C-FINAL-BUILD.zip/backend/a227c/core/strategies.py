from .structure import structure_state

def trend_strategy(df):
    x=df.iloc[-1]; st=structure_state(df)
    if x.ema20>x.ema50>x.ema200 and x.rsi14>52 and st['state']=='BULLISH': return ('BUY',3,'Trend structure + MA alignment + momentum')
    if x.ema20<x.ema50<x.ema200 and x.rsi14<48 and st['state']=='BEARISH': return ('SELL',3,'Trend structure + MA alignment + momentum')
    return ('WAIT',0,'Trend conditions not fully aligned')

def breakout_strategy(df):
    if len(df)<25:return ('WAIT',0,'Insufficient breakout history')
    x=df.iloc[-1]; prev=df.iloc[-21:-1]
    hi,lo=prev.high.max(),prev.low.min()
    if x.close>hi and x.close>x.open and x.range>prev.range.mean()*1.2:return ('BUY',3,'Range breakout with displacement')
    if x.close<lo and x.close<x.open and x.range>prev.range.mean()*1.2:return ('SELL',3,'Range breakdown with displacement')
    return ('WAIT',0,'No validated breakout')

def smc_liquidity(df):
    if len(df)<15:return ('WAIT',0,'Insufficient liquidity history')
    x=df.iloc[-1]; prev=df.iloc[-11:-1]; hi,lo=prev.high.max(),prev.low.min()
    swept_high=x.high>hi and x.close<hi
    swept_low=x.low<lo and x.close>lo
    if swept_low and x.close>x.open:return ('BUY',3,'Sell-side liquidity sweep and bullish rejection')
    if swept_high and x.close<x.open:return ('SELL',3,'Buy-side liquidity sweep and bearish rejection')
    return ('WAIT',0,'No qualifying liquidity sweep')

def strategy_for(symbol, dfs):
    h4,h1,m30,m15=dfs
    if symbol=='USDJPY':
        a=trend_strategy(h4); b=trend_strategy(h1)
        return [a,b]
    if symbol in ('GBPUSD','XAUUSD'):
        a=breakout_strategy(m30); b=breakout_strategy(m15)
        c=smc_liquidity(m15) if symbol=='XAUUSD' else ('WAIT',0,'SMC not primary')
        return [a,b,c]
    return [('WAIT',0,'No validated primary strategy assigned yet for this market')]
