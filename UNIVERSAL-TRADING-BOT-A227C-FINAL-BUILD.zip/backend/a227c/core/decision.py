from datetime import datetime, timezone
from .indicators import enrich
from .structure import structure_state
from .strategies import strategy_for

def tf_bias(df):
    x=df.iloc[-1]; st=structure_state(df)
    if x.ema20>x.ema50 and st['state']=='BULLISH' and x.rsi14>=50:return 'BULLISH'
    if x.ema20<x.ema50 and st['state']=='BEARISH' and x.rsi14<=50:return 'BEARISH'
    return 'MIXED'

def analyze(symbol, frames, news_risk='UNKNOWN', threshold=75):
    required=('H4','H1','M30','M15')
    if any(k not in frames or len(frames[k])<60 for k in required):
        return {'symbol':symbol,'ts':datetime.now(timezone.utc).isoformat(),'direction':'WAIT','score':0,'quality':'INSUFFICIENT','data_health':'INSUFFICIENT_HISTORY','news_risk':news_risk,'reasons':['Insufficient multi-timeframe history']}
    enriched={k:enrich(frames[k]) for k in required}
    biases={k:tf_bias(enriched[k]) for k in required}
    votes={'BUY':sum(v=='BULLISH' for v in biases.values()),'SELL':sum(v=='BEARISH' for v in biases.values())}
    # M15 hard gate
    if biases['M15']=='BULLISH': base='BUY'
    elif biases['M15']=='BEARISH': base='SELL'
    else: base='WAIT'
    strat=strategy_for(symbol,[enriched[k] for k in required])
    s_buy=sum(score for d,score,_ in strat if d=='BUY'); s_sell=sum(score for d,score,_ in strat if d=='SELL')
    direction=base
    if direction=='BUY' and s_buy==0: direction='WAIT'
    if direction=='SELL' and s_sell==0: direction='WAIT'
    score=min(100, 40 + 12*max(votes['BUY'],votes['SELL']) + 8*max(s_buy,s_sell)) if direction!='WAIT' else 35
    reasons=[f'{k}: {v}' for k,v in biases.items()]
    reasons += [r for _,_,r in strat if 'No ' not in r and 'not fully' not in r]
    if news_risk=='HIGH': direction='WAIT'; score=min(score,59); reasons.append('High-impact news risk gate active')
    quality='VERY HIGH' if score>=90 else 'HIGH' if score>=80 else 'MEDIUM' if score>=70 else 'WAIT'
    if direction!='WAIT' and score<threshold: direction='WAIT'; reasons.append('Score below confirmed-signal threshold')
    last=enriched['M15'].iloc[-1]; atr=float(last.atr14)
    expected='Bullish continuation' if direction=='BUY' else 'Bearish continuation' if direction=='SELL' else 'No confirmed directional expectation'
    return {'symbol':symbol,'ts':datetime.now(timezone.utc).isoformat(),'direction':direction,'score':round(score,1),'quality':quality,
            'data_health':'LIVE_ENGINE_DATA','news_risk':news_risk,'strategy':symbol+' validated strategy set','expected_move':expected,
            'holding_window':'Calculated after volatility/ATR calibration' if direction!='WAIT' else 'N/A','timeframe_state':biases,
            'reasons':reasons,'reference_sl':f'{atr:.5f} ATR reference','reference_tp':f'{atr*2:.5f} ATR reference',
            'invalidation':'M15 thesis invalidation / structure failure','entry_zone':'Calculated from current M15 structure'}
