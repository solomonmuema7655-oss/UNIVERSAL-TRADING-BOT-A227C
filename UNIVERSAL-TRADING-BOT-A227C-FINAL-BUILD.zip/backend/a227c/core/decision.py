from datetime import datetime, timezone
from .indicators import enrich
from .structure import structure_state
from .strategies import evaluate_strategies
from .regime import classify_regime

TIMEFRAMES=('H4','H1','M30','M15')

def _bias(df):
    x=df.iloc[-1]; st=structure_state(df)
    if x.ema20>x.ema50 and x.rsi14>=52 and st['state']=='BULLISH' and x.macd_hist>0: return 'BULLISH'
    if x.ema20<x.ema50 and x.rsi14<=48 and st['state']=='BEARISH' and x.macd_hist<0: return 'BEARISH'
    return 'MIXED'

def analyze(symbol, frames, *, tick=None, source='UNKNOWN', news_risk='UNKNOWN', news_events=None, session=None, macro=None, correlations=None, threshold=75, min_bars=205, max_spread_atr_fraction=0.05):
    now=datetime.now(timezone.utc).isoformat(); reasons=[]
    if any(k not in frames or frames[k] is None or len(frames[k])<min_bars for k in TIMEFRAMES):
        return {'symbol':symbol,'timestamp':now,'direction':'WAIT','score':0,'quality':'INSUFFICIENT','data_health':'INSUFFICIENT_HISTORY','source':source,'news_risk':news_risk,'reasons':['Insufficient history: 205 bars are required on every timeframe before analysis']}
    # Reject stale closed-candle histories relative to the current provider tick.
    if isinstance(tick,dict) and tick.get('time'):
        try:
            tick_time=datetime.fromisoformat(str(tick['time']).replace('Z','+00:00'))
            if tick_time.tzinfo is None: tick_time=tick_time.replace(tzinfo=timezone.utc)
            limits={'M15':1800,'M30':3600,'H1':7200,'H4':28800}
            for tf in TIMEFRAMES:
                idx=frames[tf].index[-1]
                bar_time=idx.to_pydatetime() if hasattr(idx,'to_pydatetime') else idx
                if bar_time.tzinfo is None: bar_time=bar_time.replace(tzinfo=timezone.utc)
                age=(tick_time-bar_time).total_seconds()
                if age>limits[tf]:
                    return {'symbol':symbol,'timestamp':now,'direction':'WAIT','score':0,'quality':'DATA WARNING','data_health':'STALE_CANDLE_HISTORY','source':source,'news_risk':news_risk,'reasons':[f'{tf} closed-candle history is stale relative to the live tick ({age:.0f}s)']}
        except (ValueError,TypeError,IndexError):
            return {'symbol':symbol,'timestamp':now,'direction':'WAIT','score':0,'quality':'DATA WARNING','data_health':'INVALID_TIMESTAMPS','source':source,'news_risk':news_risk,'reasons':['Unable to validate provider/candle timestamps']}
    enriched={k:enrich(frames[k]) for k in TIMEFRAMES}
    if any(len(enriched[k])<min_bars or enriched[k].iloc[-1][['ema200','atr14','rsi14']].isna().any() for k in TIMEFRAMES):
        return {'symbol':symbol,'timestamp':now,'direction':'WAIT','score':0,'quality':'INSUFFICIENT','data_health':'INDICATOR_WARMUP','source':source,'news_risk':news_risk,'reasons':['Indicators are not fully warmed up']}
    biases={k:_bias(enriched[k]) for k in TIMEFRAMES}
    structures={k:structure_state(enriched[k]) for k in TIMEFRAMES}
    regime=classify_regime(enriched['H1'])
    strategies=evaluate_strategies(symbol,enriched,session=session,macro=macro)
    strategy_directions={s['direction'] for s in strategies if s.get('direction') in ('BUY','SELL')}
    # Mandatory M15 gate and no countertrend bypass.
    direction={'BULLISH':'BUY','BEARISH':'SELL'}.get(biases['M15'],'WAIT')
    higher=[biases[k] for k in ('H4','H1','M30')]
    if direction=='BUY' and any(v=='BEARISH' for v in higher): direction='WAIT'; reasons.append('Higher-timeframe bearish conflict')
    if direction=='SELL' and any(v=='BULLISH' for v in higher): direction='WAIT'; reasons.append('Higher-timeframe bullish conflict')
    if len(strategy_directions)>1:
        direction='WAIT'; reasons.append('Applicable strategy modules conflict: '+', '.join(sorted(strategy_directions)))
    carry=[s for s in strategies if s.get('name')=='CARRY_CONTEXT']
    if direction!='WAIT' and carry and carry[0]['direction'] in ('BUY','SELL') and carry[0]['direction']!=direction:
        direction='WAIT'; reasons.append('Carry/macro directional filter conflicts with technical direction')
    matching=[s for s in strategies if s['direction']==direction and direction!='WAIT']
    if direction!='WAIT' and not matching: direction='WAIT'; reasons.append('No applicable strategy confirmed this direction')
    # Score is an evidence score only; it is not a probability. Do not fabricate a high baseline.
    aligned=sum(1 for v in biases.values() if v==('BULLISH' if direction=='BUY' else 'BEARISH')) if direction!='WAIT' else 0
    strategy_points=sum(s['points'] for s in matching)
    score=min(100, aligned*12 + strategy_points*8 + (8 if news_risk=='LOW' else 0)) if direction!='WAIT' else 0
    if news_risk in ('HIGH','UNKNOWN','STALE'):
        direction='WAIT'; reasons.append(f'Fundamental/news gate: {news_risk}; no confirmed signal without current risk context')
    if tick is None: direction='WAIT'; reasons.append('No current tick received from the selected provider')
    elif isinstance(tick,dict):
        live_spread=float(tick.get('ask',0))-float(tick.get('bid',0))
        spread_limit=float(max_spread_atr_fraction)*float(enriched['M15'].iloc[-1].atr14)
        if live_spread<0 or live_spread>spread_limit:
            direction='WAIT'; reasons.append(f'Spread filter failed: spread {live_spread:g} exceeds {spread_limit:g} ATR-based limit')
    if direction!='WAIT' and score<threshold: direction='WAIT'; reasons.append(f'Evidence score below configured threshold ({threshold})')
    reasons += [f'{k}: {v}' for k,v in biases.items()]
    reasons += [s['reason'] for s in strategies]
    last=enriched['M15'].iloc[-1]; atr=float(last.atr14); close=float(last.close)
    if direction=='BUY': sl=close-1.5*atr; tp=close+2.0*atr
    elif direction=='SELL': sl=close+1.5*atr; tp=close-2.0*atr
    else: sl=tp=None
    quality=('VERY HIGH' if score>=90 else 'HIGH' if score>=80 else 'MEDIUM') if direction!='WAIT' else 'WAIT'
    return {'symbol':symbol,'timestamp':now,'direction':direction,'score':round(score,1),'score_meaning':'Evidence score, not win probability','quality':quality,
      'data_health':'VALIDATED' if tick is not None else 'NO_LIVE_TICK','source':source,'live_quote':({'bid':tick.get('bid'),'ask':tick.get('ask'),'last':tick.get('last'),'provider_timestamp':tick.get('time')} if isinstance(tick,dict) else None),'news_risk':news_risk,'news_events':news_events or [],
      'timeframe_state':biases,'timeframe_structure':structures,'market_regime':regime,'cross_market_correlations':correlations or {},'strategies':strategies,'expected_move':('Bullish continuation hypothesis' if direction=='BUY' else 'Bearish continuation hypothesis' if direction=='SELL' else 'No confirmed directional expectation'),
      'entry_reference':close if direction!='WAIT' else None,'reference_sl':sl,'reference_tp':tp,'risk_reward_reference':round((2.0/1.5),2) if direction!='WAIT' else None,'atr_m15':atr,'invalidation':'M15 structure invalidation; reassess on each completed candle',
      'holding_window':'Not assigned until instrument/strategy-specific forward-duration calibration exists','reasons':reasons}
