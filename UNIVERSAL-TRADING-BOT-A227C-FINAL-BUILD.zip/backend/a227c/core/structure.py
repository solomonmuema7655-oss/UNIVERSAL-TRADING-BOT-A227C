import pandas as pd

def confirmed_pivots(df,lookback=60):
    x=df.tail(lookback); z=x.iloc[:-2]
    ph=z.high[(z.high.shift(1)<z.high)&(z.high.shift(-1)<z.high)].dropna()
    pl=z.low[(z.low.shift(1)>z.low)&(z.low.shift(-1)>z.low)].dropna()
    return ph,pl

def liquidity_pools(df,lookback=60,tolerance=None):
    if len(df)<lookback:return {'equal_highs':[],'equal_lows':[]}
    ph,pl=confirmed_pivots(df,lookback); atr=float(df.iloc[-1].get('atr14',0) or 0)
    tol=tolerance if tolerance is not None else max(atr*.12,1e-9)
    def clusters(series):
        values=list(map(float,series.tail(12).tolist())); result=[]
        for value in values:
            group=[v for v in values if abs(v-value)<=tol]
            if len(group)>=2:
                level=sum(group)/len(group)
                if not any(abs(level-z)<=tol for z in result): result.append(level)
        return result[-4:]
    return {'equal_highs':clusters(ph),'equal_lows':clusters(pl)}

def structure_state(df, lookback=60):
    if df is None or len(df)<lookback: return {'state':'INSUFFICIENT','hh':False,'hl':False,'lh':False,'ll':False,'swing_high':None,'swing_low':None,'bos_bullish':False,'bos_bearish':False}
    ph,pl=confirmed_pivots(df,lookback); hh=hl=lh=ll=False
    if len(ph)>=2: hh=float(ph.iloc[-1])>float(ph.iloc[-2]); lh=not hh
    if len(pl)>=2: hl=float(pl.iloc[-1])>float(pl.iloc[-2]); ll=not hl
    state='BULLISH' if hh and hl else 'BEARISH' if lh and ll else 'MIXED'
    last=df.iloc[-1]; swing_high=float(ph.iloc[-1]) if len(ph) else None; swing_low=float(pl.iloc[-1]) if len(pl) else None
    return {'state':state,'hh':hh,'hl':hl,'lh':lh,'ll':ll,'swing_high':swing_high,'swing_low':swing_low,
            'bos_bullish':swing_high is not None and float(last.close)>swing_high,
            'bos_bearish':swing_low is not None and float(last.close)<swing_low}
