import pandas as pd

def structure_state(df: pd.DataFrame, lookback: int = 30) -> dict:
    if len(df) < max(10, lookback): return {"state":"INSUFFICIENT","score":0,"reason":"Insufficient bars"}
    x=df.tail(lookback); last=x.iloc[-1]
    highs=x.high.rolling(3,center=True).max(); lows=x.low.rolling(3,center=True).min()
    swing_highs=x.high[highs.eq(x.high)].dropna(); swing_lows=x.low[lows.eq(x.low)].dropna()
    hh=hl=lh=ll=False
    if len(swing_highs)>=2: hh=swing_highs.iloc[-1]>swing_highs.iloc[-2]; lh=not hh
    if len(swing_lows)>=2: hl=swing_lows.iloc[-1]>swing_lows.iloc[-2]; ll=not hl
    if hh and hl: state='BULLISH'
    elif lh and ll: state='BEARISH'
    else: state='MIXED'
    return {"state":state,"score":1 if state in ('BULLISH','BEARISH') else 0,"hh":hh,"hl":hl,"lh":lh,"ll":ll,
            "swing_high":float(swing_highs.iloc[-1]) if len(swing_highs) else None,
            "swing_low":float(swing_lows.iloc[-1]) if len(swing_lows) else None}
