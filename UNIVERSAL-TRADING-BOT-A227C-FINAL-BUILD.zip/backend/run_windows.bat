@echo off
setlocal
cd /d %~dp0
if not exist .venv python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist config.json copy config.example.json config.json
echo.
echo IMPORTANT: Edit config.json, set your own security.api_token, confirm MT5 symbols,
echo enable/configure your news provider, and log in to the MT5 terminal first.
echo.
python -m uvicorn a227c.server:app --host 0.0.0.0 --port 8765
