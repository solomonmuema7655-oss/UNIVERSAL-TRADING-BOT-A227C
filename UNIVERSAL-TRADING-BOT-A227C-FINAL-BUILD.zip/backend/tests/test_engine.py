import numpy as np
import pandas as pd
from a227c.core.indicators import rsi
from a227c.core.decision import analyze
from a227c.core.strategies import session_breakout, evaluate_strategies

def frames_fixture():
    now=pd.Timestamp.now(tz='UTC'); out={}
    for tf,mins in [('M15',15),('M30',30),('H1',60),('H4',240)]:
        idx=pd.date_range(end=now-pd.Timedelta(minutes=mins),periods=260,freq=f'{mins}min')
        close=np.linspace(100,110,len(idx))+np.sin(np.arange(len(idx))/4)*.1
        out[tf]=pd.DataFrame({'open':close-.03,'high':close+.1,'low':close-.1,'close':close,'tick_volume':100},index=idx)
    return out,now

def test_rsi_handles_zero_losses():
    s=pd.Series(np.arange(1,80,dtype=float))
    assert rsi(s).iloc[-1] == 100.0

def test_breakout_fails_closed_without_asian_range():
    f,_=frames_fixture()
    from a227c.core.indicators import enrich
    result=session_breakout(enrich(f['M15']),active_session='LONDON')
    assert result['direction']=='WAIT'
    assert 'Asian range' in result['reason']

def test_unassigned_market_does_not_get_fabricated_strategy():
    f,_=frames_fixture()
    from a227c.core.indicators import enrich
    enriched={k:enrich(v) for k,v in f.items()}
    result=evaluate_strategies('GBPJPY',enriched)
    assert result[0]['direction']=='WAIT'
    assert result[0]['name']=='UNASSIGNED'

def test_missing_news_context_blocks_confirmed_signal():
    f,now=frames_fixture()
    tick={'time':now.isoformat(),'bid':109.999,'ask':110.001}
    result=analyze('USDJPY',f,tick=tick,source='TEST',news_risk='UNKNOWN',threshold=75,min_bars=205)
    assert result['direction']=='WAIT'
    assert any('news gate' in x.lower() for x in result['reasons'])

def test_signal_journal_and_research_metrics(tmp_path, monkeypatch):
    from a227c import storage
    monkeypatch.setattr(storage, 'DB', tmp_path/'journal.sqlite3')
    signal={'symbol':'XAUUSD','bar_timestamp':'2026-11-21T00:00:00+00:00','timestamp':'2026-11-21T00:15:00+00:00',
            'direction':'BUY','score':82,'quality':'HIGH','source':'TEST','data_health':'VALIDATED'}
    signal_id=storage.save_signal(signal)
    assert signal_id is not None
    storage.record_outcome(signal_id,'WIN',1.5,'manual test result')
    report=storage.research()
    assert report['by_market']['XAUUSD']['wins']==1
    assert report['by_market']['XAUUSD']['expectancy_r']==1.5

def test_backtest_requires_cost_assumption_and_uses_chronological_split():
    from a227c.research.backtest import walk_forward
    idx=pd.date_range('2026-01-01',periods=700,freq='h',tz='UTC')
    close=np.linspace(100,105,700)+np.sin(np.arange(700)/5)*.15
    df=pd.DataFrame({'open':close-.02,'high':close+.12,'low':close-.12,'close':close,'tick_volume':100},index=idx)
    import pytest
    with pytest.raises(ValueError): walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0)
    report=walk_forward(df,'TREND_PULLBACK','USDJPY','H1',0.01)
    assert report['in_sample'] is not None and report['out_of_sample'] is not None
    assert 'not a forecast' not in report['validation_note'].lower()

def test_carry_context_requires_rate_yield_and_positive_swap():
    from a227c.core.strategies import carry_context
    incomplete={'rate_differential_available':True,'base_minus_quote_rate':3.0,'yield_differential':1.0}
    assert carry_context(incomplete)['direction']=='WAIT'
    complete={**incomplete,'broker_swap_long':2.5}
    assert carry_context(complete)['direction']=='BUY'


def test_stale_higher_timeframe_candle_blocks_analysis():
    now=pd.Timestamp.now(tz='UTC'); frames,_=frames_fixture()
    old=frames['H4'].copy(); old.index=old.index-pd.Timedelta(hours=12); frames['H4']=old
    result=analyze('USDJPY',frames,tick={'time':now.isoformat(),'bid':109.99,'ask':109.991},source='TEST',news_risk='LOW',threshold=75,min_bars=205)
    assert result['direction']=='WAIT'
    assert result['data_health']=='STALE_CANDLE_HISTORY'
