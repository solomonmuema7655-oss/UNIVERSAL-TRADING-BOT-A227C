# A227C implementation and deployment gates

Revision 1.5 — 21 November 2026

## Revision 1.5 additions

- Added an Exness historical bid/ask tick ZIP/CSV importer for the official archive format (`Exness,Symbol,Timestamp,Bid,Ask`). It validates quote integrity, UTC timestamps, crossed markets, duplicates, records archive and output hashes, and resamples separate BID/ASK bars for M15/M30/H1/H4.
- Research backtesting now supports paired historical bid/ask bars: BUY entry at ask / exit at bid; SELL entry at bid / exit at ask. It retains conservative stop-first handling for same-bar ambiguity and explicitly states that this is not tick-sequence execution simulation.
- Research runner prefers paired Exness bid/ask bars when available; otherwise it requires a positive documented spread assumption.
- Added generic FRED/ALFRED vintage acquisition using output_type=2. It requires a registered API key and reviewed series configuration. Vintage dates are shifted to the next UTC day as a conservative availability timestamp because the vintage date does not establish an intraday release time.
- Carry research blocks stale macro (>120 days) or broker swap (>7 days) records by default.
- MT5 export manifest includes a timestamped current broker symbol-contract metadata snapshot; it is explicitly not represented as historical contract data.
- Research runs now require explicit commission/slippage assumptions and evidence-basis notes; unknown costs are not silently treated as zero.
- MT5 export manifest includes a timestamped current broker symbol-contract metadata snapshot; it is explicitly not represented as historical contract data.
- Research runs now require explicit commission/slippage assumptions and evidence-basis notes; unknown costs are not silently treated as zero.
- Chronological evaluation now reserves a separate final 15% holdout, excluded from development-fold aggregate metrics. Added deterministic bootstrap confidence intervals for expectancy (descriptive only).

## Verification

- Backend tests: 28 passed (3 non-fatal deprecation/future warnings).
- Python compilation: passed.
- Source ZIP integrity: pending final packaging verification.
- Tests use synthetic fixtures solely for software correctness. No real Exness archive, FRED key, Japanese macro vintage, broker swap archive, live market feed, VPS or physical Android device was available here.

## External evidence and remaining gates

Exness Tick History is a valid alternate historical quote acquisition route to logged-in MT5 terminal export. Exness describes its archive as indicative historical bid/ask prices; its Help Center specifies CSV columns `Exness,Symbol,Timestamp,Bid,Ask` and notes server-source differences. It does not establish actual trade execution records.

FRED/ALFRED supports vintage-date observations, but U.S. series alone do not provide a complete Japan policy/yield dataset. Japanese policy/yield observations must use reviewed BOJ or other primary sources with publication-time provenance. Treasury yield observations need conservative availability-time treatment.

Still not complete or verified: full tick-by-tick strategy replay with intra-bar event sequencing, provider commission conversion and account-currency valuation, actual broker swap archive and triple-swap rules, complete point-in-time Japan/US macro set, PBO/Deflated Sharpe multiple-testing diagnostics, real-data strategy validation, live shadow observation, provider live-feed verification, deployed backend/WSS, Android CI artifact verification and physical-device acceptance.

A227C remains signal-only and must never place or manage broker trades. A generated ZIP/APK is not production acceptance.
