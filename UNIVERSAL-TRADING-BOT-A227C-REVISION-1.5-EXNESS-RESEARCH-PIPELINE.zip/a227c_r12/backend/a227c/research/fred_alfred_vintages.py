"""Acquire FRED/ALFRED point-in-time observations for configured macro series.

Requires a registered FRED API key in FRED_API_KEY. Series are operator-configured;
this module deliberately does not guess country/instrument mappings. Vintage dates are
conservatively made available at 00:00 UTC on the following calendar day because the
API's vintage date alone does not establish an intraday publication time.
"""
from __future__ import annotations
import argparse, json, os
from pathlib import Path
import requests
import pandas as pd

BASE='https://api.stlouisfed.org/fred/series/observations'

def fetch_vintages(series_id: str, api_key: str, observation_start='1990-01-01', observation_end=None, session=None) -> pd.DataFrame:
    if not api_key: raise ValueError('FRED_API_KEY is required')
    if not series_id or not series_id.replace('_','').isalnum(): raise ValueError('Invalid FRED series identifier')
    client=session or requests.Session(); params={'series_id':series_id,'api_key':api_key,'file_type':'json',
        'output_type':2,'observation_start':observation_start,'limit':100000,'sort_order':'asc'}
    if observation_end: params['observation_end']=observation_end
    response=client.get(BASE,params=params,timeout=45); response.raise_for_status(); payload=response.json()
    if 'error_code' in payload: raise RuntimeError(f"FRED API error {payload.get('error_code')}: {payload.get('error_message')}")
    observations=payload.get('observations')
    if observations is None: raise ValueError('FRED response did not contain observations')
    rows=[]
    for item in observations:
        try: value=float(item['value'])
        except (TypeError,ValueError,KeyError): continue
        vintage=pd.Timestamp(item.get('realtime_start'))
        if pd.isna(vintage): continue
        available=(vintage+pd.Timedelta(days=1)).tz_localize('UTC')
        rows.append({'series_id':series_id,'observation_date':item.get('date'),
                     'vintage_date':vintage.date().isoformat(),'available_at':available.isoformat(),
                     'value':value,'realtime_end':item.get('realtime_end')})
    if not rows: raise ValueError(f'No numeric vintage observations returned for {series_id}')
    out=pd.DataFrame(rows).drop_duplicates(['observation_date','vintage_date']).sort_values(['available_at','observation_date'])
    out['observation_date']=pd.to_datetime(out.observation_date,errors='raise')
    return out

def acquire(config_path: Path, output: Path, api_key=None, session=None):
    config=json.loads(config_path.read_text(encoding='utf-8')); key=api_key or os.getenv('FRED_API_KEY')
    results=[]; output.mkdir(parents=True,exist_ok=True)
    for item in config.get('series',[]):
        sid=item['series_id']; frame=fetch_vintages(sid,key,item.get('observation_start','1990-01-01'),item.get('observation_end'),session)
        dest=output/f'{sid}_alfred_vintages.csv'; frame.to_csv(dest,index=False)
        results.append({'series_id':sid,'role':item.get('role'),'rows':len(frame),'file':dest.name,
                        'first_available_at':frame.available_at.min(),'last_available_at':frame.available_at.max(),
                        'note':'Vintage date shifted to following UTC day to avoid assuming intraday availability.'})
    manifest={'provider':'Federal Reserve Bank of St. Louis FRED/ALFRED','series':results,
              'limitations':'Series mapping and economic meaning require independent review. FRED/ALFRED coverage is not a substitute for direct central-bank releases or broker swap history.'}
    (output/'fred_alfred_manifest.json').write_text(json.dumps(manifest,indent=2,default=str),encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--config',required=True); p.add_argument('--output',default='research_data/macro_alfred')
    a=p.parse_args(); print(json.dumps(acquire(Path(a.config),Path(a.output)),indent=2,default=str))
if __name__=='__main__': main()
