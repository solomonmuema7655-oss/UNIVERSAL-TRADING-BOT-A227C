"""Run the fixed A227C strategy matrix against real MT5-exported CSV datasets.

No synthetic fallback exists. Missing datasets or uncalibrated positive cost assumptions
are reported as blocked, never replaced with generated prices.
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import pandas as pd
from .mt5_history_export import validate_ohlc
from .backtest import walk_forward

MATRIX = (
    ('USDJPY','H1','TREND_PULLBACK'), ('USDJPY','H4','TREND_PULLBACK'),
    ('XAUUSD','M15','LIQUIDITY_SMC'),
    ('GBPUSD','M15','SESSION_BREAKOUT'), ('GBPUSD','M30','SESSION_BREAKOUT'),
    ('XAUUSD','M15','SESSION_BREAKOUT'), ('XAUUSD','M30','SESSION_BREAKOUT'),
)

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def load_dataset(path: Path) -> pd.DataFrame:
    frame=pd.read_csv(path)
    if 'time_utc' not in frame.columns: raise ValueError('CSV must contain time_utc column')
    frame['time_utc']=pd.to_datetime(frame['time_utc'],utc=True,errors='raise')
    frame=frame.set_index('time_utc').sort_index()
    if frame.index.has_duplicates: raise ValueError('Duplicate timestamps are not allowed')
    validate_ohlc(frame)
    return frame

def run(data_dir: Path, output: Path, costs: dict, train_fraction=.6, folds=4):
    results=[]; datasets={}
    for symbol,tf,strategy in MATRIX:
        path=data_dir/f'{symbol}_{tf}.csv'
        key=f'{symbol}_{tf}'
        bid_path=data_dir/f'{symbol}_{tf}_BID.csv'; ask_path=data_dir/f'{symbol}_{tf}_ASK.csv'
        has_quotes=bid_path.exists() and ask_path.exists()
        if not path.exists() and not has_quotes:
            results.append({'symbol':symbol,'timeframe':tf,'strategy':strategy,'status':'BLOCKED_MISSING_REAL_DATASET'})
            continue
        try:
            cost=costs.get(key,{})
            required_cost_fields=('commission_round_turn_price_units','slippage_round_turn_price_units','commission_basis','slippage_basis')
            missing_cost=[field for field in required_cost_fields if field not in cost or cost[field] in ('',None)]
            if missing_cost: raise ValueError(f'Explicit commission/slippage assumptions and their evidence basis are required: {missing_cost}')
            ask_frame=None; spread=None; quote_source='FIXED_SPREAD_ASSUMPTION'
            if bid_path.exists() and ask_path.exists():
                frame=load_dataset(bid_path); ask_frame=load_dataset(ask_path)
                if not frame.index.equals(ask_frame.index): raise ValueError('Exness bid/ask files do not have identical timestamps')
                datasets[key]={'bid_sha256':sha256(bid_path),'ask_sha256':sha256(ask_path),'bars':len(frame),
                               'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}
                quote_source='EXNESS_HISTORICAL_BID_ASK_ARCHIVE'
            else:
                frame=load_dataset(path)
                datasets[key]={'path':path.name,'sha256':sha256(path),'bars':len(frame),
                               'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}
                spread=float(cost.get('spread_price_units',0))
                if spread<=0: raise ValueError('Provide Exness BID/ASK quote bars or a calibrated positive spread_price_units assumption')
            report=walk_forward(frame,strategy,symbol,tf,spread,train_fraction=train_fraction,folds=folds,
                commission_price_units=float(cost.get('commission_round_turn_price_units',0)),
                slippage_price_units=float(cost.get('slippage_round_turn_price_units',0)),ask_frame=ask_frame)
            results.append({'symbol':symbol,'timeframe':tf,'strategy':strategy,'status':'SIMULATED_REAL_HISTORY',
                            'quote_source':quote_source,'dataset':datasets[key], 'cost_assumptions':cost,'report':report})
        except Exception as exc:
            results.append({'symbol':symbol,'timeframe':tf,'strategy':strategy,'status':'BLOCKED_INVALID_OR_INSUFFICIENT_DATA',
                            'error':str(exc)})
    payload={'schema_version':2,'research_type':'FIXED_RULES_HISTORICAL_OHLC_OR_EXNESS_BID_ASK_QUOTE_BARS_NOT_LIVE_EXECUTION',
        'created_at_utc':pd.Timestamp.now(tz='UTC').isoformat(),'datasets':datasets,'results':results,
        'policy':'No synthetic fallback. Missing costs/data block a run. Synthetic fixtures are permitted only in unit tests.',
        'not_a_profitability_claim':True}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(payload,indent=2,default=str),encoding='utf-8')
    return payload

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',required=True,help='Directory containing MT5 OHLC CSV or Exness SYMBOL_TF_BID/ASK.csv files')
    p.add_argument('--costs',required=True,help='JSON file with per-symbol/timeframe cost assumptions')
    p.add_argument('--output',default='research_data/a227c_research_report.json')
    p.add_argument('--folds',type=int,default=4)
    a=p.parse_args()
    costs=json.loads(Path(a.costs).read_text(encoding='utf-8'))
    report=run(Path(a.data),Path(a.output),costs,folds=a.folds)
    print(json.dumps({'output':a.output,'dataset_count':len(report['datasets']),
                      'result_statuses':{x['status']:sum(y['status']==x['status'] for y in report['results']) for x in report['results']}},indent=2))
if __name__=='__main__': main()
