from . import __doc__
from ..core.indicators import enrich
from ..core.strategies import trend_pullback, liquidity_smc, session_breakout
from ..core.sessions import session_name
from zoneinfo import ZoneInfo
import numpy as np

def _metrics(trades):
    rs=[float(t['r_multiple']) for t in trades]
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<0]
    gross_win=sum(wins); gross_loss=abs(sum(losses))
    peak=0.0; equity=0.0; max_dd=0.0
    for r in rs:
        equity+=r; peak=max(peak,equity); max_dd=max(max_dd,peak-equity)
    streak=longest=0
    for r in rs:
        if r<0: streak+=1; longest=max(longest,streak)
        elif r>0: streak=0
    ci=None
    if len(rs)>=2:
        rng=np.random.default_rng(20261121); samples=rng.choice(np.asarray(rs,dtype=float),(2000,len(rs)),replace=True).mean(axis=1)
        ci=[round(float(np.quantile(samples,.025)),4),round(float(np.quantile(samples,.975)),4)]
    return {'trades':len(rs),'wins':len(wins),'losses':len(losses),'win_rate_pct':round(100*len(wins)/len(rs),2) if rs else None,
            'expectancy_r_bootstrap_95pct_ci':ci, 'bootstrap_method':'2000 deterministic resamples of trade R-multiples; descriptive, not a correction for selection bias',
            'expectancy_r':round(sum(rs)/len(rs),3) if rs else None,'profit_factor':round(gross_win/gross_loss,3) if gross_loss else (None if not gross_win else 'infinite'),
            'max_drawdown_r':round(max_dd,3),'longest_consecutive_losses':longest,
            'average_mae_r':round(sum(float(t.get('mae_r',0)) for t in trades)/len(trades),3) if trades else None,
            'average_mfe_r':round(sum(float(t.get('mfe_r',0)) for t in trades)/len(trades),3) if trades else None,
            'average_holding_bars':round(sum(int(t.get('holding_bars',0)) for t in trades)/len(trades),2) if trades else None}

def run_bar_backtest(frame,strategy,symbol,timeframe,spread_cost=None,max_holding_bars=48,start=205,
                     end=None,commission_price_units=0.0,slippage_price_units=0.0,ask_frame=None):
    """OHLC research simulation. With ask_frame, use actual resampled Exness bid/ask bars.

    Signals are evaluated on bid bars. BUY enters at ask and exits on bid; SELL enters
    at bid and exits on ask. Same-bar stop/target ambiguity is resolved stop-first.
    Without ask_frame, a positive fixed full-spread assumption is mandatory.
    """
    if ask_frame is None and (spread_cost is None or spread_cost<=0):
        raise ValueError('A positive full-spread assumption or aligned ask_frame is required')
    if ask_frame is not None:
        if not frame.index.equals(ask_frame.index): raise ValueError('Bid and ask bar indexes must match exactly')
        if not {'open','high','low','close'}.issubset(ask_frame.columns): raise ValueError('Ask frame missing OHLC columns')
        if (ask_frame[['open','high','low','close']]<=0).any().any(): raise ValueError('Ask OHLC must be positive')
        if (ask_frame.high < ask_frame[['open','close','low']].max(axis=1)).any() or (ask_frame.low > ask_frame[['open','close','high']].min(axis=1)).any(): raise ValueError('Invalid ask OHLC geometry')
    if len(frame)<start+2: raise ValueError('Insufficient bars before requested backtest start')
    end = len(frame)-1 if end is None else min(int(end),len(frame)-1)
    if end <= start: raise ValueError('Backtest end must be after start')
    if commission_price_units < 0 or slippage_price_units < 0: raise ValueError('Commission and slippage costs cannot be negative')
    if strategy=='TREND_PULLBACK' and symbol=='USDJPY' and timeframe in ('H1','H4'): evaluator=trend_pullback
    elif strategy=='LIQUIDITY_SMC' and symbol=='XAUUSD' and timeframe=='M15': evaluator=liquidity_smc
    elif strategy=='SESSION_BREAKOUT' and symbol in ('GBPUSD','XAUUSD') and timeframe in ('M15','M30'):
        def evaluator(hist):
            local=hist.index.tz_convert(ZoneInfo('Asia/Tokyo')); day=hist.index[-1].to_pydatetime().astimezone(ZoneInfo('Asia/Tokyo')).date()
            mask=(local.date==day)&(local.hour>=0)&(local.hour<8); asian=hist.loc[mask]
            if len(asian)<4: return {'direction':'WAIT','reason':'Asian range unavailable in historical window'}
            return session_breakout(hist,float(asian.high.max()),float(asian.low.min()),session_name(hist.index[-1].to_pydatetime()))
    else: raise ValueError('This market/timeframe/strategy combination has no implemented backtest rule')
    data=enrich(frame); asks=ask_frame; trades=[]; i=start
    while i < min(end,len(data)-1):
        hist=data.iloc[:i+1]; signal=evaluator(hist); direction=signal['direction']
        if direction not in ('BUY','SELL'):
            i+=1; continue
        entry_bar=data.iloc[i+1]; ask_entry=asks.iloc[i+1] if asks is not None else None
        atr=float(hist.iloc[-1].atr14)
        if atr<=0 or atr!=atr: i+=1; continue
        half=float(spread_cost)/2.0 if asks is None else 0.0
        if direction=='BUY':
            entry=float(ask_entry.open if asks is not None else entry_bar.open+half)+slippage_price_units/2
        else:
            entry=float(entry_bar.open-half if asks is None else entry_bar.open)-slippage_price_units/2
        risk=1.5*atr; stop=entry-risk if direction=='BUY' else entry+risk
        take=entry+2.0*atr if direction=='BUY' else entry-2.0*atr
        exit_price=None; exit_index=None; exit_reason='TIME_EXIT'; mae=0.0; mfe=0.0
        trade_end=min(end,i+1+max_holding_bars)
        for j in range(i+1,trade_end+1):
            bar=data.iloc[j]; q=asks.iloc[j] if asks is not None else None
            if direction=='BUY':
                adverse=float(bar.low); favorable=float(bar.high)
                mae=max(mae,max(0.0,entry-adverse)/risk); mfe=max(mfe,max(0.0,favorable-entry)/risk)
                hit_stop=adverse<=stop; hit_take=favorable>=take
                if hit_stop:
                    exit_price=stop-slippage_price_units/2; exit_index=j; exit_reason='STOP' if not hit_take else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if hit_take:
                    exit_price=take-slippage_price_units/2; exit_index=j; exit_reason='TARGET'; break
                if j==trade_end: exit_price=float(bar.close)-slippage_price_units/2; exit_index=j
            else:
                adverse=float(q.high if q is not None else bar.high+2*half); favorable=float(q.low if q is not None else bar.low-2*half)
                mae=max(mae,max(0.0,adverse-entry)/risk); mfe=max(mfe,max(0.0,entry-favorable)/risk)
                hit_stop=adverse>=stop; hit_take=favorable<=take
                if hit_stop:
                    exit_price=stop+slippage_price_units/2; exit_index=j; exit_reason='STOP' if not hit_take else 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'; break
                if hit_take:
                    exit_price=take+slippage_price_units/2; exit_index=j; exit_reason='TARGET'; break
                if j==trade_end: exit_price=float(q.close if q is not None else bar.close+2*half)+slippage_price_units/2; exit_index=j
        if exit_price is None:
            q=asks.iloc[trade_end] if asks is not None else None; last=data.iloc[trade_end]
            exit_price=float(last.close if direction=='BUY' else (q.close if q is not None else last.close+2*half)) + (-slippage_price_units/2 if direction=='BUY' else slippage_price_units/2); exit_index=trade_end
        pnl=((exit_price-entry) if direction=='BUY' else (entry-exit_price))-commission_price_units
        trades.append({'signal_time':str(data.index[i]),'entry_time':str(data.index[i+1]),'exit_time':str(data.index[exit_index]),'direction':direction,
                       'entry':entry,'stop':stop,'target':take,'exit':exit_price,'r_multiple':round(pnl/risk,4),'mae_r':round(mae,4),'mfe_r':round(mfe,4),'holding_bars':int(exit_index-i),
                       'commission_price_units':commission_price_units,'slippage_price_units':slippage_price_units,'exit_reason':exit_reason,'strategy_reason':signal['reason']})
        i=exit_index+1
    return {'symbol':symbol,'timeframe':timeframe,'strategy':strategy,'spread_cost_assumption_price_units':spread_cost if asks is None else 'OBSERVED_FROM_EXNESS_BID_ASK',
            'commission_round_turn_price_units':commission_price_units,'slippage_round_turn_price_units':slippage_price_units,'stop_atr':1.5,'target_atr':2.0,
            'execution_model':'Bid/ask OHLC quote-side model' if asks is not None else 'Fixed full-spread OHLC approximation',
            'same_bar_policy':'Conservative: stop assumed first when stop and target are both touched in one OHLC candle',
            'cost_limitations':'Bid/ask OHLC uses observed quote bars but not tick-sequence path within each bar. Commission and slippage remain explicit price-unit inputs; financing, market impact and execution latency are not modeled.',
            'overall':_metrics(trades),'trades':trades}

def walk_forward(frame,strategy,symbol,timeframe,spread_cost,train_fraction=0.6,max_holding_bars=48,
                 commission_price_units=0.0,slippage_price_units=0.0,folds=4,ask_frame=None,holdout_fraction=0.15):
    """Expanding chronological folds plus a separate final holdout segment.

    The final holdout is excluded from fold development metrics. Once inspected, it is
    no longer untouched for subsequent strategy changes; a new later period is required.
    """
    if ask_frame is not None and not frame.index.equals(ask_frame.index): raise ValueError('Bid and ask histories must have identical timestamps')
    if not 0.5 <= train_fraction < 0.9: raise ValueError('train_fraction must be in [0.5, 0.9)')
    if not 0.05 <= holdout_fraction <= 0.25: raise ValueError('holdout_fraction must be in [0.05, 0.25]')
    if folds < 2: raise ValueError('At least two out-of-sample folds are required')
    if len(frame) < 650: raise ValueError('Need at least 650 bars for warm-up, folds and final holdout')
    holdout_start=int(len(frame)*(1.0-holdout_fraction))
    first_test=max(205,int(len(frame)*train_fraction))
    if holdout_start-first_test < folds*30: raise ValueError('Insufficient development-period bars for requested OOS folds')
    remaining=holdout_start-first_test
    boundaries=[first_test + (remaining*i)//folds for i in range(folds+1)]
    in_sample_report=run_bar_backtest(frame.iloc[:first_test],strategy,symbol,timeframe,spread_cost,
        max_holding_bars,commission_price_units=commission_price_units,
        slippage_price_units=slippage_price_units,ask_frame=ask_frame.iloc[:first_test] if ask_frame is not None else None)
    fold_reports=[]; all_trades=[]
    for n in range(folds):
        lo,hi=boundaries[n],boundaries[n+1]
        report=run_bar_backtest(frame,strategy,symbol,timeframe,spread_cost,max_holding_bars,
            start=lo,end=hi-1,commission_price_units=commission_price_units,
            slippage_price_units=slippage_price_units,ask_frame=ask_frame)
        fold_reports.append({'fold':n+1,'test_start':str(frame.index[lo]),'test_end':str(frame.index[hi-1]),
                             'metrics':report['overall'],'trades':report['trades']})
        all_trades.extend(report['trades'])
    holdout=run_bar_backtest(frame,strategy,symbol,timeframe,spread_cost,max_holding_bars,
        start=holdout_start,end=len(frame)-1,commission_price_units=commission_price_units,
        slippage_price_units=slippage_price_units,ask_frame=ask_frame)
    return {'symbol':symbol,'strategy':strategy,'timeframe':timeframe,
        'initial_history_fraction':train_fraction,'in_sample':in_sample_report['overall'],
        'development_out_of_sample':_metrics(all_trades),'out_of_sample':_metrics(all_trades),'out_of_sample_folds':fold_reports,
        'final_holdout':{'start':str(frame.index[holdout_start]),'end':str(frame.index[-1]),
                         'metrics':holdout['overall'],'trades':holdout['trades'],
                         'status':'SEPARATE_FINAL_HOLDOUT_NOT_USED_IN_FOLD_METRICS'},
        'validation_note':'Fixed rules; expanding chronological development folds plus a separate final holdout. No parameter fitting. The final holdout must be retired after inspection if strategy rules are changed. Historical OHLC simulation is not live execution or a profitability guarantee.'}
