"""Import Exness historical bid/ask tick ZIP/CSV archives into validated quote bars.

The public archive is downloaded by the operator from Exness Tick History. This tool
never guesses instruments or fabricates prices. It preserves the original archive hash
and emits separate BID and ASK OHLC bars so spread is observable per bar.
"""
from __future__ import annotations
import argparse, hashlib, json, zipfile
from pathlib import Path
from io import BytesIO
import pandas as pd

REQUIRED = {"Timestamp", "Bid", "Ask"}

def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _read_csv_bytes(raw: bytes) -> pd.DataFrame:
    # Exness archive files may have a provider/instrument prefix before the header.
    from io import StringIO
    text = raw.decode("utf-8-sig", errors="strict")
    lines = text.splitlines()
    header = next((i for i, line in enumerate(lines) if all(k in line for k in ("Timestamp", "Bid", "Ask"))), None)
    if header is None:
        raise ValueError("No Exness tick CSV header containing Timestamp, Bid and Ask was found")
    frame = pd.read_csv(StringIO("\n".join(lines[header:])))
    frame.columns = [str(c).strip().strip('"') for c in frame.columns]
    missing = REQUIRED.difference(frame.columns)
    if missing: raise ValueError(f"Tick CSV missing columns: {sorted(missing)}")
    return frame

def load_exness_archive(path: Path) -> tuple[pd.DataFrame, dict]:
    raw = path.read_bytes(); source_hash = _sha256(raw); pieces=[]
    if zipfile.is_zipfile(BytesIO(raw)):
        with zipfile.ZipFile(BytesIO(raw)) as z:
            names=[n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX/')]
            if not names: raise ValueError("ZIP contains no CSV tick files")
            for name in names: pieces.append((name,_read_csv_bytes(z.read(name))))
    elif path.suffix.lower()=='.csv':
        pieces.append((path.name,_read_csv_bytes(raw)))
    else: raise ValueError("Input must be an Exness ZIP archive or CSV")
    frames=[]; source_files=[]
    for name, part in pieces:
        x=part.copy()
        x['timestamp']=pd.to_datetime(x['Timestamp'],utc=True,errors='coerce')
        x['bid']=pd.to_numeric(x['Bid'],errors='coerce'); x['ask']=pd.to_numeric(x['Ask'],errors='coerce')
        x=x.dropna(subset=['timestamp','bid','ask'])
        if x.empty: raise ValueError(f"No valid tick rows in {name}")
        if (x[['bid','ask']]<=0).any().any(): raise ValueError(f"Non-positive quote in {name}")
        if (x.ask<x.bid).any(): raise ValueError(f"Crossed market (ask < bid) in {name}")
        x=x[['timestamp','bid','ask']].sort_values('timestamp')
        frames.append(x); source_files.append({'name':name,'valid_ticks':len(x)})
    ticks=pd.concat(frames,ignore_index=True).sort_values('timestamp')
    duplicate_count=int(ticks.timestamp.duplicated(keep='last').sum())
    ticks=ticks.drop_duplicates('timestamp',keep='last').set_index('timestamp')
    if not ticks.index.is_monotonic_increasing or ticks.index.has_duplicates: raise ValueError('Tick timestamps are not unique and ordered')
    ticks['spread']=ticks.ask-ticks.bid
    if (ticks.spread<=0).any(): raise ValueError('Non-positive spread encountered')
    meta={'source':'Exness public historical tick archive','archive_file':path.name,'archive_sha256':source_hash,
          'source_files':source_files,'ticks':len(ticks),'duplicates_removed':duplicate_count,
          'first_tick_utc':ticks.index[0].isoformat(),'last_tick_utc':ticks.index[-1].isoformat(),
          'spread_price_units':{'median':float(ticks.spread.median()),'p90':float(ticks.spread.quantile(.90)),
                                'p95':float(ticks.spread.quantile(.95)),'max':float(ticks.spread.max())},
          'limitations':'Indicative provider bid/ask quotes; not individual execution records. Confirm archive instrument identity and date coverage.'}
    return ticks,meta

def resample_quote_bars(ticks: pd.DataFrame, timeframe: str) -> tuple[pd.DataFrame,pd.DataFrame,pd.DataFrame]:
    rule={'M15':'15min','M30':'30min','H1':'1h','H4':'4h'}.get(timeframe)
    if not rule: raise ValueError('Unsupported timeframe; use M15, M30, H1 or H4')
    def bars(series):
        o=series.resample(rule,closed='left',label='left').ohlc().dropna()
        o.columns=['open','high','low','close']; return o
    bid=bars(ticks.bid); ask=bars(ticks.ask)
    common=bid.index.intersection(ask.index); bid=bid.loc[common]; ask=ask.loc[common]
    spread=pd.DataFrame({'spread_open':ask.open-bid.open,'spread_close':ask.close-bid.close,
                         'spread_high':ask.high-bid.low,'spread_low':ask.low-bid.high},index=common)
    if (spread[['spread_open','spread_close']]<=0).any().any(): raise ValueError('Invalid resampled bid/ask spread')
    return bid,ask,spread

def import_archive(path: Path, output: Path, symbol: str, timeframes=('M15','M30','H1','H4')) -> dict:
    ticks,meta=load_exness_archive(path); output.mkdir(parents=True,exist_ok=True); outputs={}
    for tf in timeframes:
        bid,ask,spread=resample_quote_bars(ticks,tf)
        if bid.empty: raise ValueError(f'No {tf} bars were generated')
        for label,frame in [('BID',bid),('ASK',ask),('SPREAD',spread)]:
            dest=output/f'{symbol}_{tf}_{label}.csv'; frame.to_csv(dest,index_label='time_utc')
            outputs[dest.name]={'rows':len(frame),'sha256':_sha256(dest.read_bytes()),
                                'first_utc':frame.index[0].isoformat(),'last_utc':frame.index[-1].isoformat()}
    manifest={**meta,'internal_symbol':symbol,'timeframes':list(timeframes),'outputs':outputs,
              'bar_construction':'UTC-aligned left-closed, left-labelled resampling of source ticks'}
    (output/f'{symbol}_EXNESS_TICK_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--archive',required=True); p.add_argument('--symbol',required=True,choices=['XAUUSD','USTECH100','GBPJPY','GBPUSD','USDJPY']); p.add_argument('--output',default='research_data/exness_ticks')
    a=p.parse_args(); result=import_archive(Path(a.archive),Path(a.output),a.symbol); print(json.dumps(result,indent=2))
if __name__=='__main__': main()
