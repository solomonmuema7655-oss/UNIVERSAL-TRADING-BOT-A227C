"""Point-in-time carry-context study requiring historical macro and broker swap inputs.

Input frames must use UTC timestamps and contain `available_at` (when the value became
knowable), not merely the period the statistic describes. This prevents look-ahead.
"""
from __future__ import annotations
import pandas as pd
from ..core.strategies import carry_context

REQUIRED_MACRO = ("available_at", "base_rate", "quote_rate", "base_yield_10y", "quote_yield_10y")
REQUIRED_SWAP = ("available_at", "swap_long", "swap_short", "swap_mode")

def point_in_time_carry_study(price_times, macro: pd.DataFrame, swaps: pd.DataFrame, max_macro_age_days=120, max_swap_age_days=7) -> pd.DataFrame:
    if macro.empty or swaps.empty: raise ValueError("Historical point-in-time macro and broker swap records are both required")
    for name, frame, required in (("macro",macro,REQUIRED_MACRO),("swaps",swaps,REQUIRED_SWAP)):
        missing=[c for c in required if c not in frame.columns]
        if missing: raise ValueError(f"{name} input missing columns: {missing}")
        if not isinstance(frame["available_at"].dtype, pd.DatetimeTZDtype):
            raise ValueError(f"{name}.available_at must be timezone-aware UTC timestamps")
        if frame.available_at.isna().any(): raise ValueError(f"{name}.available_at contains missing timestamps")
    left=pd.DataFrame({"timestamp":pd.to_datetime(price_times,utc=True)}).sort_values("timestamp")
    m=macro.copy(); s=swaps.copy()
    m["available_at"]=pd.to_datetime(m.available_at,utc=True); s["available_at"]=pd.to_datetime(s.available_at,utc=True)
    m=m.sort_values("available_at"); s=s.sort_values("available_at")
    joined=pd.merge_asof(left,m,left_on="timestamp",right_on="available_at",direction="backward")
    joined=joined.rename(columns={"available_at":"macro_available_at"})
    joined=pd.merge_asof(joined.sort_values("timestamp"),s,left_on="timestamp",right_on="available_at",direction="backward")
    joined=joined.rename(columns={"available_at":"swap_available_at"})
    rows=[]
    for row in joined.to_dict("records"):
        ready=all(pd.notna(row.get(k)) for k in ("base_rate","quote_rate","base_yield_10y","quote_yield_10y","swap_long","swap_short","swap_mode"))
        macro_age=((row["timestamp"]-row["macro_available_at"]).total_seconds()/86400 if pd.notna(row.get("macro_available_at")) else None)
        swap_age=((row["timestamp"]-row["swap_available_at"]).total_seconds()/86400 if pd.notna(row.get("swap_available_at")) else None)
        if not ready:
            decision={"direction":"WAIT","points":0,"reason":"Point-in-time macro or broker swap history unavailable"}
        elif macro_age > max_macro_age_days or swap_age > max_swap_age_days:
            decision={"direction":"WAIT","points":0,"reason":"Macro or broker swap observation is stale; carry context withheld"}
        else:
            decision=carry_context({"rate_differential_available":True,
                "base_minus_quote_rate":float(row["base_rate"])-float(row["quote_rate"]),
                "yield_differential":float(row["base_yield_10y"])-float(row["quote_yield_10y"]),
                "broker_swap_long":float(row["swap_long"]),"broker_swap_short":float(row["swap_short"]),
                "broker_swap_mode":row["swap_mode"]})
        rows.append({"timestamp":row["timestamp"],"macro_available_at":row.get("macro_available_at"),
                     "swap_available_at":row.get("swap_available_at"),"direction":decision["direction"],
                     "reason":decision["reason"],"macro_age_hours":(macro_age*24 if macro_age is not None else None),
                     "swap_age_hours":(swap_age*24 if swap_age is not None else None)})
    return pd.DataFrame(rows)
