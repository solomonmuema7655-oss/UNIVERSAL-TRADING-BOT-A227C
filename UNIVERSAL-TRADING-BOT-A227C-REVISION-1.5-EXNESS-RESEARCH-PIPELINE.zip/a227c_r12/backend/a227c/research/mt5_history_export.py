"""Export real, provider-specific MT5 OHLC history for reproducible A227C research.

Run on the Windows host where the intended MT5 terminal is installed and logged in.
This module reads market data only; it contains no order/trading calls.
"""
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
from ..adapters.mt5_adapter import MT5Adapter

TIMEFRAMES = ("M15", "M30", "H1", "H4")
REQUIRED = ("open", "high", "low", "close")

def validate_ohlc(frame: pd.DataFrame) -> dict:
    if frame is None or frame.empty:
        raise ValueError("No historical bars returned by MT5")
    missing = [c for c in REQUIRED if c not in frame.columns]
    if missing: raise ValueError("Missing OHLC columns: " + ", ".join(missing))
    if not isinstance(frame.index, pd.DatetimeIndex) or frame.index.tz is None:
        raise ValueError("Bar index must be timezone-aware UTC timestamps")
    if not frame.index.is_monotonic_increasing or frame.index.has_duplicates:
        raise ValueError("Bar timestamps must be strictly increasing and unique")
    values = frame[list(REQUIRED)].astype(float)
    if not values.notna().all().all() or not (values > 0).all().all():
        raise ValueError("OHLC contains missing, non-finite or non-positive values")
    bad = (values.high < values[["open", "close", "low"]].max(axis=1)) | (values.low > values[["open", "close", "high"]].min(axis=1))
    if bad.any(): raise ValueError(f"Invalid OHLC candle geometry in {int(bad.sum())} rows")
    return {"bars": int(len(frame)), "first_bar_utc": frame.index[0].isoformat(),
            "last_bar_utc": frame.index[-1].isoformat(), "duplicate_timestamps": 0,
            "ohlc_geometry": "VALID", "source_timezone": "UTC"}

def export_history(symbol_map: dict[str,str], output_dir: Path, bars: int = 20000) -> dict:
    if bars < 500: raise ValueError("At least 500 bars are required for indicator warm-up and research")
    adapter = MT5Adapter(symbol_map); results = {}; output_dir.mkdir(parents=True, exist_ok=True)
    try:
        adapter.connect()
        for internal, provider in symbol_map.items():
            if provider not in adapter.available_symbols:
                results[internal] = {"status":"SYMBOL_UNAVAILABLE", "provider_symbol":provider,
                                     "error":adapter.symbol_errors.get(provider,"Not selected in MT5")}
                continue
            results[internal + "_CURRENT_SYMBOL_METADATA"] = adapter.symbol_metadata(provider)
            for tf in TIMEFRAMES:
                frame = adapter.bars(provider, tf, bars, closed_only=True)
                validation = validate_ohlc(frame)
                frame.to_csv(output_dir / f"{internal}_{tf}.csv", index_label="time_utc")
                results[f"{internal}_{tf}"] = {"status":"EXPORTED", "internal_symbol":internal,
                    "provider_symbol":provider, "timeframe":tf, **validation}
    finally: adapter.shutdown()
    manifest = {"created_at_utc":datetime.now(timezone.utc).isoformat(), "source":"MetaTrader 5 terminal",
                "note":"Real provider history; verify broker symbol identity and history coverage before research.",
                "metadata_warning":"Symbol contract/swap metadata is a current snapshot only; never backfill it as historical terms.",
                "exports":results}
    raw=json.dumps(manifest,indent=2).encode(); manifest["manifest_sha256"] = hashlib.sha256(raw).hexdigest()
    (output_dir/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--symbols", required=True, help="JSON object mapping internal symbols to exact MT5 broker symbols")
    p.add_argument("--output", default="research_data/mt5")
    p.add_argument("--bars", type=int, default=20000)
    a=p.parse_args(); mapping=json.loads(a.symbols)
    result=export_history(mapping,Path(a.output),a.bars)
    print(json.dumps(result,indent=2))
    if not any(v.get("status")=="EXPORTED" for v in result["exports"].values()): raise SystemExit(2)
if __name__ == "__main__": main()
