import requests
from datetime import datetime, timezone

class TradingEconomicsCalendar:
    def __init__(self,api_key):
        self.api_key=api_key
        self.session=requests.Session()
        self.session.headers.update({'User-Agent':'SIYOMA-A227C/1.1','Accept':'application/json'})
    def upcoming(self,countries=('United States','United Kingdom','Japan'),importance=2):
        if not self.api_key: raise RuntimeError('Trading Economics API key is not configured')
        r=self.session.get('https://api.tradingeconomics.com/calendar',params={'c':self.api_key,'importance':importance},timeout=20); r.raise_for_status()
        events=[]
        for e in r.json():
            if e.get('Country') not in countries: continue
            raw=e.get('Date') or e.get('date')
            try: ts=datetime.fromisoformat(str(raw).replace('Z','+00:00'))
            except Exception:
                ts=None
                for fmt in ('%m/%d/%Y %H:%M:%S','%m/%d/%Y %I:%M:%S %p','%m/%d/%Y'):
                    try: ts=datetime.strptime(str(raw),fmt).replace(tzinfo=timezone.utc); break
                    except ValueError: pass
                if ts is None: continue
            if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
            actual=e.get('Actual'); forecast=e.get('Forecast'); surprise=None; surprise_state='UNAVAILABLE'
            try:
                av=float(str(actual).replace(',','')); fv=float(str(forecast).replace(',','')); surprise=av-fv
                surprise_state='ABOVE_FORECAST' if surprise>0 else 'BELOW_FORECAST' if surprise<0 else 'INLINE'
            except (TypeError,ValueError): pass
            currency=e.get('Currency') or {'United States':'USD','United Kingdom':'GBP','Japan':'JPY'}.get(e.get('Country'))
            events.append({'timestamp':ts.astimezone(timezone.utc).isoformat(),'country':e.get('Country'),'event':e.get('Event'),'importance':e.get('Importance'),'currency':currency,'actual':actual,'forecast':forecast,'previous':e.get('Previous'),'surprise':surprise,'surprise_state':surprise_state,'source':'Trading Economics'})
        return events


    def indicator_catalog(self,country):
        """Return provider-listed indicator categories for a country for exact mapping checks."""
        if not self.api_key: raise RuntimeError('Trading Economics API key is not configured')
        url=f'https://api.tradingeconomics.com/indicators/{country}'
        response=self.session.get(url,params={'c':self.api_key},timeout=20); response.raise_for_status()
        rows=response.json()
        if isinstance(rows,dict): rows=[rows]
        return {str(row.get('Category') or row.get('Title') or '').strip() for row in rows if isinstance(row,dict)} - {''}

    def latest_indicator(self,country,indicator):
        """Fetch the provider's latest observation; never substitute a guessed value."""
        url=f'https://api.tradingeconomics.com/country/{country}/{indicator}'
        r=self.session.get(url,params={'c':self.api_key},timeout=20); r.raise_for_status(); data=r.json()
        if isinstance(data,dict): data=[data]
        if not data: raise RuntimeError(f'No {indicator} observation returned for {country}')
        def observation_time(row):
            raw=row.get('LatestValueDate') or row.get('DateTime') or row.get('Date')
            if not raw: return datetime.min.replace(tzinfo=timezone.utc)
            try:
                parsed=datetime.fromisoformat(str(raw).replace('Z','+00:00'))
                return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)
            except ValueError:
                for fmt in ('%m/%d/%Y %H:%M:%S','%m/%d/%Y %I:%M:%S %p','%m/%d/%Y'):
                    try: return datetime.strptime(str(raw),fmt).replace(tzinfo=timezone.utc)
                    except ValueError: pass
                return datetime.min.replace(tzinfo=timezone.utc)
        data=sorted(data,key=observation_time,reverse=True)
        item=data[0]
        value=item.get('LatestValue',item.get('Value'))
        date=item.get('LatestValueDate',item.get('DateTime',item.get('Date')))
        if value is None or date is None: raise RuntimeError(f'Incomplete {indicator} observation for {country}')
        return {'country':country,'indicator':indicator,'value':float(value),'observation_date':str(date),'last_update':item.get('LastUpdate'),'unit':item.get('Unit'),'frequency':item.get('Frequency'),'source':'Trading Economics'}
