from datetime import datetime, timezone
import pandas as pd
try:
    import MetaTrader5 as mt5
except ImportError:
    mt5=None

class MT5Adapter:
    def __init__(self, symbols): self.symbols=symbols; self.connected=False; self.available_symbols=set(); self.symbol_errors={}
    def connect(self):
        if mt5 is None: raise RuntimeError('MetaTrader5 Python package is available only on a supported Windows MT5 host')
        if not mt5.initialize(): raise RuntimeError(f'MT5 initialize failed: {mt5.last_error()}')
        self.connected=True
        for symbol in self.symbols.values():
            if mt5.symbol_select(symbol,True): self.available_symbols.add(symbol)
            else: self.symbol_errors[symbol]=str(mt5.last_error())
        if not self.available_symbols: raise RuntimeError('No configured A227C symbols are available in MT5 Market Watch')
        return True
    def symbol_metadata(self,symbol):
        """Return broker symbol contract metadata for audit; current values are not historical."""
        info=mt5.symbol_info(symbol)
        if info is None: return None
        fields=('name','description','path','digits','point','trade_contract_size','trade_tick_size',
                'trade_tick_value','trade_tick_value_profit','trade_tick_value_loss','trade_calc_mode',
                'currency_base','currency_profit','currency_margin','trade_stops_level','trade_freeze_level',
                'volume_min','volume_max','volume_step','swap_long','swap_short','swap_mode',
                'swap_rollover3days','swap_day')
        result={}
        for field in fields:
            value=getattr(info,field,None)
            if value is not None and isinstance(value,(int,float,str,bool)): result[field]=value
        result['swap_mode_name']=self._swap_mode_name(info.swap_mode)
        result['metadata_as_of_utc']=datetime.now(timezone.utc).isoformat()
        result['historical_validity']='CURRENT_SNAPSHOT_ONLY_NOT_HISTORICAL'
        return result

    def tick(self,symbol):
        t=mt5.symbol_info_tick(symbol)
        if t is None:return None
        ts=datetime.fromtimestamp(t.time_msc/1000,timezone.utc) if getattr(t,'time_msc',0) else datetime.fromtimestamp(t.time,timezone.utc)
        info=mt5.symbol_info(symbol)
        return {'symbol':symbol,'time':ts,'bid':float(t.bid),'ask':float(t.ask),'last':float(t.last),'volume':float(t.volume),
                'swap_long':float(info.swap_long) if info else None,'swap_short':float(info.swap_short) if info else None,
                'swap_mode':int(info.swap_mode) if info else None,
                'swap_mode_name':self._swap_mode_name(info.swap_mode) if info else 'UNKNOWN',
                'point':float(info.point) if info else None,'digits':int(info.digits) if info else None}
    def bars(self,symbol,timeframe,count=500,closed_only=True):
        tf={'M15':mt5.TIMEFRAME_M15,'M30':mt5.TIMEFRAME_M30,'H1':mt5.TIMEFRAME_H1,'H4':mt5.TIMEFRAME_H4}[timeframe]
        rates=mt5.copy_rates_from_pos(symbol,tf,1 if closed_only else 0,count)
        if rates is None or len(rates)==0:return pd.DataFrame()
        df=pd.DataFrame(rates); df['time']=pd.to_datetime(df['time'],unit='s',utc=True)
        return df.rename(columns={'tick_volume':'volume'}).set_index('time').sort_index()
    @staticmethod
    def _swap_mode_name(mode):
        if mt5 is None: return 'UNKNOWN'
        names = ('DISABLED','POINTS','CURRENCY_SYMBOL','CURRENCY_MARGIN','CURRENCY_DEPOSIT','CURRENCY_PROFIT','INTEREST_CURRENT','INTEREST_OPEN','REOPEN_CURRENT','REOPEN_BID')
        for name in names:
            constant = getattr(mt5, 'SYMBOL_SWAP_MODE_' + name, None)
            if constant is not None and int(mode) == int(constant): return name
        return 'UNKNOWN'

    def shutdown(self):
        if mt5 is not None and self.connected: mt5.shutdown()
        self.connected=False
