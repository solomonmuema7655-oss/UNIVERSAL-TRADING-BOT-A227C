"""Deriv public market-data adapter (no account authentication or trading actions)."""
import asyncio
import json
import math
import websockets


PUBLIC_MARKET_DATA_ENDPOINT = "wss://api.derivws.com/trading/v1/options/ws/public"


def extract_active_symbols(message):
    """Return validated provider symbol identifiers from an active_symbols response."""
    if message.get("error"):
        error = message["error"]
        raise RuntimeError(error.get("message", "Deriv active-symbol request failed"))
    rows = message.get("active_symbols") or []
    return {row.get("symbol") for row in rows if isinstance(row, dict) and row.get("symbol")}


def normalize_tick(tick, symbol_map):
    """Normalize a public Deriv tick; reject malformed, non-finite or non-positive quotes."""
    if not isinstance(tick, dict):
        return None
    provider_symbol = tick.get("symbol")
    try:
        quote = float(tick.get("quote"))
        epoch = int(tick.get("epoch"))
    except (TypeError, ValueError, OverflowError):
        return None
    if not provider_symbol or not math.isfinite(quote) or quote <= 0 or epoch <= 0:
        return None
    return {
        "internal_symbol": next((k for k, v in symbol_map.items() if v == provider_symbol), "UNMAPPED"),
        "provider_symbol": provider_symbol,
        "epoch": epoch,
        "quote": quote,
        "source": "DERIV",
    }


class DerivAdapter:
    """Public market-data only. Deriv contracts remain isolated from MT5 instruments."""
    def __init__(self, endpoint, symbols):
        self.endpoint = endpoint or PUBLIC_MARKET_DATA_ENDPOINT
        self.symbols = symbols
        self.connected = False
        self.available = set()

    async def run(self, on_tick, on_status):
        delay = 2
        while True:
            try:
                async with websockets.connect(self.endpoint, ping_interval=20, ping_timeout=20, open_timeout=15) as ws:
                    await ws.send(json.dumps({"active_symbols": "brief", "req_id": 1}))
                    raw = await asyncio.wait_for(ws.recv(), timeout=20)
                    response = json.loads(raw)
                    self.available = extract_active_symbols(response)
                    missing = {internal: provider for internal, provider in self.symbols.items() if provider not in self.available}
                    for request_id, provider in enumerate(self.symbols.values(), start=2):
                        if provider in self.available:
                            await ws.send(json.dumps({"ticks": provider, "subscribe": 1, "req_id": request_id}))
                    self.connected = True
                    delay = 2
                    await on_status({"state": "CONNECTED", "endpoint": self.endpoint, "available_symbols": sorted(self.available), "configured_missing": missing})
                    async for raw in ws:
                        msg = json.loads(raw)
                        if msg.get("error"):
                            error = msg["error"]
                            await on_status({"state": "ERROR", "message": error.get("message", "Deriv API error")})
                            continue
                        tick = msg.get("tick")
                        if tick:
                            normalized = normalize_tick(tick, self.symbols)
                            if normalized is not None:
                                await on_tick(normalized)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.connected = False
                await on_status({"state": "DISCONNECTED", "message": str(exc)})
                await asyncio.sleep(delay)
                delay = min(delay * 2, 60)
