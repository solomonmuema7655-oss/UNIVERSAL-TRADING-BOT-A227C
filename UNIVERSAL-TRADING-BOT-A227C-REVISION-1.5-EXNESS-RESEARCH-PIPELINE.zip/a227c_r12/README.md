# SIYOMA UNIVERSAL-TRADING-BOT-A227C

**A227C is a real-time market-analysis and signal product. It is not an order-execution bot.** It never places, modifies or closes broker trades. The user independently decides whether to execute a signal through their own broker/platform.

## Product boundary and signal integrity

- No AI agent, LLM or machine-learning-generated live decisions.
- No broker order/execution adapter or broker trading credentials.
- BUY / SELL / WAIT; WAIT is a first-class outcome.
- Strict H4 → H1 → M30 → M15 analysis. M15 is the final confirmation gate.
- A signal is blocked when live tick freshness, closed-bar history, indicator warm-up, spread, news-risk or strategy evidence is insufficient.
- The score is an evidence score, **not** a probability of winning.
- No strategy is represented as statistically profitable until instrument-specific backtesting, out-of-sample and walk-forward validation support that claim.

## Included application

- Android monitoring app with the approved A227C logo embedded as the actual app identity and launcher icon.
- Backend API, WebSocket market stream, health endpoint and snapshot endpoint.
- MT5 / Exness-via-MT5 adapter for a supported Windows MT5 terminal.
- Separate Deriv public WebSocket adapter. Deriv instruments remain source-isolated and are not silently mapped to the five MT5 markets.
- Trading Economics calendar adapter (server-side credentials only).
- Technical indicators, confirmed swing structure, trend/pullback, session-breakout, liquidity-sweep and carry-context evaluators.
- Market data health checks, stale candle checks, spread-to-ATR filter, event/news risk gate and explainable signal snapshots.

## Initial market universe

XAUUSD, USTECH100, GBPJPY, GBPUSD, USDJPY. Provider symbols must be confirmed against the actual account/feed. The sample USTEC mapping is only a placeholder and must be checked in MT5 Market Watch.

## Deployment topology

The MT5 Python integration requires a supported desktop MT5 terminal and should run on a Windows VPS/dedicated Windows host. The Android app is a monitoring client; it is not the always-on data engine. A reverse proxy with TLS should expose the backend as `wss://.../ws` and `https://.../health`.

## Windows backend setup

1. Install a supported MetaTrader 5 terminal and log into the intended account. Confirm all five instruments are visible and receiving quotes.
2. Copy `backend/config.example.json` to `backend/config.json`.
3. Set the `A227C_API_TOKEN` environment variable to a long random secret (preferred), or change `security.api_token` in the ignored local `config.json`. Never commit `config.json` or `.env`.
4. Confirm provider-specific symbol names in `mt5.symbols`.
5. Configure a valid Trading Economics key through the server environment variable `TRADING_ECONOMICS_API_KEY` and set `news.enabled` to `true`. Until current news-risk data is available, confirmed signals are deliberately blocked.
6. Run `backend/run_windows.bat` or install `backend/requirements.txt` and start `uvicorn a227c.server:app --host 0.0.0.0 --port 8765` from the backend directory.
7. Check `/health` and `/snapshot`. The backend must show MT5 CONNECTED, news CONNECTED, fresh ticks and healthy histories before signal generation is enabled.

Deriv is disabled by default until you explicitly enable it and configure exact instrument mappings. The current public market-data endpoint is `wss://api.derivws.com/trading/v1/options/ws/public`; public ticks do not require account authentication. Set `deriv.enabled` and populate `deriv.symbols`. Deriv symbols remain isolated from MT5 instruments. Deriv ticks are displayed in a separate namespace and do not become XAUUSD/USTECH100/FX quotes by name similarity.

## Strategy implementation notes

- USDJPY: trend pullback evaluated on H4/H1; carry is macro context only and is not an entry trigger.
- GBPUSD and XAUUSD: London/New York breakout module requires an observed Tokyo/Asian range. If range levels are unavailable, that strategy returns WAIT.
- XAUUSD: liquidity sweep/reclaim module uses objective prior-range boundaries and directional displacement. It is a mechanical candidate detector, not a claim that an institution placed an order.
- GBPJPY and USTECH100: no unvalidated primary strategy is fabricated; they remain WAIT until market-specific strategy rules pass validation.

The current calendar adapter applies a high-impact event window and fails closed if the feed is missing/stale. The current carry evaluator requires verified rate-differential input; no fabricated policy-rate values are included. Broker swap and yield data integrations still require their own verified provider sources.

## Android client configuration

Open the app, enter the backend WebSocket URL (prefer `wss://.../ws`) and the same API token configured on the backend. The app does not store the token persistently. The Android client displays the five agreed MT5 markets, provider status, signal evidence and invalidation/SL/TP references.

## Research and integration blueprint

See `docs/RESEARCH_AND_INTEGRATION_BLUEPRINT.md` for the researched provider contracts, deployment topology, event-driven data lifecycle, strategy assignments, security requirements and operational acceptance gates.

## Validation and release status

This source includes the actual backend and Android implementation, but **a successful CI build is not proof of a working live provider connection or a profitable strategy**. Before public deployment, complete Windows-host MT5 integration tests, Deriv endpoint/app-ID verification, calendar credentials, provider symbol verification, historical data validation, market-specific backtests, out-of-sample/walk-forward tests, and live shadow observation. Do not lower the data/news gates to make the app display signals.

## Build

GitHub Actions uses Ubuntu 22.04, Java 17 and Gradle 8.7 to assemble Android Debug and Release APK artifacts. Release APK is unsigned unless a signing configuration is added securely through GitHub Secrets.

## Signal history, research and charting

- `/market/{symbol}/candles?timeframe=M15&limit=100` returns stored, completed MT5 candles for the Android candlestick chart (authenticated).
- `/signals/history` returns persisted snapshots.
- `/journal/outcome` records a user's manually observed WIN/LOSS/BREAKEVEN result and optional realized R multiple against a specific signal ID.
- `/research/performance` summarizes recorded outcomes, expectancy where R values exist, profit factor, losing streaks and score buckets. It is a descriptive journal report, not a backtest result or a forecast.
- Android shows completed-candle charts for M15/M30/H1/H4, signal details, provider status, local high-priority notifications for BUY/SELL transitions and invalidation events, and manual outcome recording. Android local alerts require the app to be connected to the backend; reliable push while the app is terminated requires a separately configured Firebase Cloud Messaging project and server credentials.

## API security

The WebSocket and protected REST routes require the configured token via `X-A227C-Token` header. The server reads `A227C_API_TOKEN` from the environment first, then falls back to the ignored local config file. The example placeholder token is intentionally rejected. Set a unique long random token in `backend/config.json`. Use TLS/WSS through a reverse proxy for remote access; do not expose the backend's plain HTTP port directly to the public internet.
- `/research/backtest` runs a chronological 60/40 in-sample/out-of-sample OHLC walk-forward simulation for currently coded combinations: USDJPY trend pullback on H1/H4, XAUUSD liquidity/SMC on M15, and GBPUSD/XAUUSD session breakout on M15/M30. It requires a positive full-spread cost assumption in quote-price units. Stop/target same-bar ambiguity resolves conservatively to stop-first. This harness does not yet model commissions, variable historical spread, slippage, financing/swap, or all broker-specific execution conditions; its results must not be treated as verified profitability.

## Windows host provisioning (revision 1.2)

See `deploy/DEPLOYMENT_RUNBOOK.md`. `deploy/windows/Install-A227C.ps1` installs the backend dependencies and stores the A227C token and optional Trading Economics key encrypted with Windows DPAPI for the current Windows user. `Start-A227C.ps1` launches the API on loopback only. `deploy/caddy/Caddyfile.example` provides the TLS/WSS reverse-proxy template. A real domain, VPS, logged-in MT5 terminal and valid provider credentials are still required; no repository can safely invent those resources.

Carry context is deliberately blocked unless the MT5 broker reports swap in `CURRENCY_DEPOSIT` mode and the value is positive for the relevant side. Other swap calculation modes are not treated as directly comparable cash amounts. Trading Economics macro indicator names are configurable under `news.macro_indicators`; confirm exact identifiers and plan entitlement against the account before enabling live fundamental gates.
