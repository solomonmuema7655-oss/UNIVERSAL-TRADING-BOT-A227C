$ErrorActionPreference = 'Stop'
$script = Join-Path $PSScriptRoot 'Start-A227C.ps1'
if (!(Test-Path $script)) { throw 'Run Install-A227C.ps1 first.' }
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$script`""
$trigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable
Register-ScheduledTask -TaskName 'SIYOMA A227C Backend' -Action $action -Trigger $trigger -Settings $settings -Description 'Starts the A227C signal-only analysis backend in the MT5 user session.' -Force | Out-Null
Write-Host 'A227C backend will start at this Windows user logon and restart after failures.' -ForegroundColor Green
Write-Host 'The MT5 terminal must also be configured to start and remain logged in for the same user.'
