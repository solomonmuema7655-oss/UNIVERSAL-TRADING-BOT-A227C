# A227C deployment runbook (Windows MT5 host)

This package automates the application-side setup but cannot create a VPS, register a domain, purchase a Trading Economics subscription, or log in to a user's MT5 account. Those require account-holder actions and credentials. No secrets belong in GitHub or the APK.

## Host prerequisites

- Windows 10/11 or supported Windows Server on a continuously available VPS.
- 64-bit Python supported by the installed MetaTrader5 package (use Python 3.11 for the pinned dependency set).
- MetaTrader 5 desktop terminal installed and logged into the intended Exness account. Keep the terminal running in the same Windows user session as the backend.
- Confirm the exact broker symbol names for XAUUSD, USTECH100, GBPJPY, GBPUSD and USDJPY in Market Watch. The sample `USTEC` mapping is not guaranteed.
- A domain name with DNS pointing to the VPS, and Caddy installed for automatic TLS.
- Windows firewall/network rules allowing inbound TCP 80 and 443 only; do not expose port 8765 publicly.

## Install backend

Run PowerShell as the same Windows user that owns the MT5 terminal:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\deploy\windows\Install-A227C.ps1
```

The installer creates a Python virtual environment and stores API secrets encrypted with Windows DPAPI for the current user. The generated `Start-A227C.ps1` must be run as that same Windows user. A user-scoped DPAPI secret cannot be decrypted by another account or machine.

## Configure provider symbols

Edit `backend/config.json` locally (it is ignored by Git). Confirm each symbol using MT5 `symbol_info` and a fresh `symbol_info_tick`; do not assume a broker's USTECH100 symbol is `USTEC`. Set the exact values under `mt5.symbols`. The server must report each symbol available and fresh before its signal can leave WAIT.

## Trading Economics

The installer asks for the API key and stores it locally using DPAPI. The key must belong to an active plan with calendar and indicator access. A key's presence is not proof of entitlement. Verify `/health`, event counts, observation dates, and all four configured macro observations (US/JP policy rates and 10Y yields). If a country/indicator route is not entitled or returns no observation, macro status remains unavailable and carry context remains WAIT. Do not substitute guessed values.

## TLS / WSS

1. Copy `deploy/caddy/Caddyfile.example` to the Caddy configuration directory.
2. Replace the example host with the real DNS name.
3. Start Caddy with that configuration. Caddy must successfully obtain a trusted certificate.
4. Start the backend with `deploy/windows/Start-A227C.ps1`.
5. Verify `https://YOUR-DOMAIN/health` and then configure the Android client with `wss://YOUR-DOMAIN/ws` plus the API token.
6. Verify invalid tokens are rejected and the Android client reconnects after a brief network interruption.

Do not connect Android to `ws://`, `http://`, a raw public port 8765, or a self-signed production certificate.

## Live shadow acceptance

Before calling the system operational, keep it in signal-only shadow mode. Record provider/source timestamps, quote age, candle timestamps, spread, strategy evidence, decision, invalidation and subsequent price excursion. Do not send broker orders. A physical Android test must confirm authenticated WSS, reconnect, REST candle/history requests, and stale-feed WAIT behavior.
