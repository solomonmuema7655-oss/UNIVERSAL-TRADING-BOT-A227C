import asyncio, json, os, time
from datetime import datetime, timezone
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from .adapters.mt5_adapter import MT5Adapter
from .adapters.deriv_adapter import DerivAdapter
from .adapters.news_adapter import TradingEconomicsCalendar
from .core.decision import analyze
from .core.sessions import asian_range, session_name
from .storage import save_signal, history as signal_history, research as research_metrics, record_outcome
from .core.correlation import correlation_snapshot
from .core.ranking import rank_opportunities
from .research.backtest import walk_forward

BASE=Path(__file__).resolve().parents[1]
config_path=Path(os.getenv('A227C_CONFIG',str(BASE/'config.json')))
cfg=json.loads(config_path.read_text()) if config_path.exists() else json.loads((BASE/'config.example.json').read_text())
app=FastAPI(title='SIYOMA UNIVERSAL TRADING BOT A227C',version='1.0.0')
clients=set(); snapshots={}; market_frames={}; health_state={'mt5':'DISABLED','deriv':'DISABLED','news':'UNKNOWN','macro':'UNKNOWN','last_error':None,'started_at':datetime.now(timezone.utc).isoformat(),'emergency_stop':False,'signal_stream':'STARTING'}
mt5_adapter=None; news_events=[]; news_updated=0; policy_rates={}; macro_updated=0; last_bar_refresh=0; last_tick_epoch={}
SYMBOLS=list(cfg.get('mt5',{}).get('symbols',{}).keys())

def validate_production_config():
    if os.getenv('A227C_ENV','').lower()!='production': return
    token=_configured_token()
    if not token or len(token)<32: raise RuntimeError('Production A227C requires a strong API token; refusing to start with a placeholder.')
    if not cfg.get('security',{}).get('public_read_only_stream',True):
        raise RuntimeError('Production public read-only stream setting must be explicitly reviewed before disabling it.')
    if len(SYMBOLS)!=5 or set(SYMBOLS)!={'XAUUSD','USTECH100','GBPJPY','GBPUSD','USDJPY'}:
        raise RuntimeError('Production A227C must configure exactly the five agreed MT5 analysis markets.')
    if not cfg.get('news',{}).get('enabled'): raise RuntimeError('Production A227C requires the news/macro gate to be enabled; no silent bypass is allowed.')


def _json_tick(t): return {k:(v.isoformat() if hasattr(v,'isoformat') else v) for k,v in t.items()}
def _macro_for_symbol(symbol):
    if symbol!='USDJPY' or not policy_rates: return None
    usd=policy_rates.get('United States'); jpy=policy_rates.get('Japan')
    uy=policy_rates.get('United States 10Y'); jy=policy_rates.get('Japan 10Y')
    if not all((usd,jpy,uy,jy)): return None
    def age_days(item):
        raw=item.get('observation_date')
        try:
            dt=datetime.fromisoformat(str(raw).replace('Z','+00:00'))
        except ValueError:
            try: dt=datetime.strptime(str(raw),'%m/%d/%Y %H:%M:%S').replace(tzinfo=timezone.utc)
            except ValueError:
                try: dt=datetime.strptime(str(raw),'%m/%d/%Y %I:%M:%S %p').replace(tzinfo=timezone.utc)
                except ValueError:
                    try: dt=datetime.strptime(str(raw),'%m/%d/%Y').replace(tzinfo=timezone.utc)
                    except ValueError: return float('inf')
        if dt.tzinfo is None: dt=dt.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc)-dt.astimezone(timezone.utc)).total_seconds()/86400
    if age_days(usd)>550 or age_days(jpy)>550 or age_days(uy)>10 or age_days(jy)>10: return None
    return {'rate_differential_available':True,'base_minus_quote_rate':usd['value']-jpy['value'],
            'yield_differential':uy['value']-jy['value'],'source':'Trading Economics','updated_at':datetime.fromtimestamp(macro_updated,timezone.utc).isoformat()}

def _relevant_news(symbol):
    currencies={'XAUUSD':{'USD'},'USTECH100':{'USD'},'GBPJPY':{'GBP','JPY'},'GBPUSD':{'GBP','USD'},'USDJPY':{'USD','JPY'}}.get(symbol,set())
    now=datetime.now(timezone.utc); selected=[]
    for event in news_events:
        if event.get('currency') not in currencies: continue
        try: ts=datetime.fromisoformat(event['timestamp'])
        except Exception: continue
        if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
        if abs((ts-now).total_seconds())<=86400: selected.append(event)
    return selected[:20]

def _news_risk(symbol):
    global news_events
    if not cfg.get('news',{}).get('enabled'): return 'UNKNOWN'
    if time.time()-news_updated>int(cfg.get('news',{}).get('max_age_seconds',1800)): return 'STALE'
    currencies={'XAUUSD':{'USD'},'USTECH100':{'USD'},'GBPJPY':{'GBP','JPY'},'GBPUSD':{'GBP','USD'},'USDJPY':{'USD','JPY'}}.get(symbol,set())
    now=datetime.now(timezone.utc)
    for e in news_events:
        try: ts=datetime.fromisoformat(e['timestamp'])
        except Exception: continue
        if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
        if e.get('currency') in currencies and -int(cfg['news'].get('post_event_minutes',20))*60 <= (ts-now).total_seconds() <= int(cfg['news'].get('pre_event_minutes',30))*60:
            return 'HIGH'
    return 'LOW'

async def broadcast(payload):
    dead=[]; msg=json.dumps(payload,default=str)
    for ws in list(clients):
        try: await ws.send_text(msg)
        except Exception: dead.append(ws)
    for ws in dead: clients.discard(ws)

@app.get('/health')
async def health():
    return JSONResponse({'product':'A227C','status':'running','market_symbols':SYMBOLS,'providers':health_state,
      'connected_clients':len(clients),'signal_count':len(snapshots),'trade_execution':'SIGNAL_ONLY_BY_DESIGN',
      'security_configured':_configured_token() is not None,'public_read_only_stream':bool(cfg.get('security',{}).get('public_read_only_stream',True)),
      'emergency_stop':bool(health_state.get('emergency_stop'))})

@app.get('/bootstrap')
async def bootstrap():
    # Read-only bootstrap contains no secrets. It lets the Android client discover the
    # currently deployed WSS/HTTPS endpoints without embedding a credential in the APK.
    return {'product':'A227C','protocol_version':'2.0','status':'running',
      'ws_path':'/ws','https_base':'/','public_read_only_stream':bool(cfg.get('security',{}).get('public_read_only_stream',True)),
      'markets':SYMBOLS,'signal_only':True,'trade_execution':False}

@app.get('/public/snapshot')
async def public_snapshot():
    return {'engine':'A227C','updated_at':datetime.now(timezone.utc).isoformat(),
      'providers':health_state,'signals':list(snapshots.values()),'ranking':rank_opportunities(snapshots)}

@app.get('/public/market/{symbol}/candles')
async def public_candles(symbol:str,timeframe:str='M15',limit:int=100):
    if timeframe not in ('M15','M30','H1','H4'): raise HTTPException(status_code=400,detail='Unsupported timeframe')
    frame=market_frames.get(symbol,{}).get(timeframe)
    if frame is None or frame.empty: return {'symbol':symbol,'timeframe':timeframe,'candles':[],'data_health':'NO_HISTORY'}
    rows=[]
    for idx,row in frame.tail(max(1,min(limit,500))).iterrows():
        rows.append({'time':idx.isoformat(),'open':float(row.open),'high':float(row.high),'low':float(row.low),'close':float(row.close),'volume':float(row.get('tick_volume',row.get('volume',0)))})
    return {'symbol':symbol,'timeframe':timeframe,'candles':rows,'data_health':'CLOSED_CANDLES','source':'MT5'}

@app.post('/admin/emergency-stop')
async def emergency_stop(x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token); health_state['emergency_stop']=True; health_state['signal_stream']='EMERGENCY_STOPPED'
    for symbol in SYMBOLS:
        snapshots[symbol]={'symbol':symbol,'timestamp':datetime.now(timezone.utc).isoformat(),'direction':'WAIT','score':0,'quality':'EMERGENCY STOP','data_health':'CONTROLLED_STOP','source':'A227C','reasons':['Emergency signal stop is active; no directional signal may be issued']}
    await broadcast({'type':'emergency_stop','active':True})
    return {'active':True}

@app.post('/admin/resume')
async def resume_engine(x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token); health_state['emergency_stop']=False; health_state['signal_stream']='RUNNING'; return {'active':False}

def _configured_token():
    # Environment secret takes precedence so production tokens need not be stored in config.json.
    value=os.getenv('A227C_API_TOKEN') or cfg.get('security',{}).get('api_token','')
    return value if value and not value.startswith('CHANGE_THIS') else None

def check_api_token(x_a227c_token):
    expected=_configured_token()
    if not expected: raise HTTPException(status_code=503,detail='A227C server token is not configured')
    if x_a227c_token!=expected: raise HTTPException(status_code=401,detail='Invalid A227C API token')

@app.get('/snapshot')
async def snapshot(x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token); return {'engine':'A227C','updated_at':datetime.now(timezone.utc).isoformat(),'providers':health_state,'signals':list(snapshots.values())}

@app.get('/market/{symbol}/candles')
async def get_candles(symbol:str,timeframe:str='M15',limit:int=100,x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token)
    if timeframe not in ('M15','M30','H1','H4'): raise HTTPException(status_code=400,detail='Unsupported timeframe')
    frame=market_frames.get(symbol,{}).get(timeframe)
    if frame is None or frame.empty: return {'symbol':symbol,'timeframe':timeframe,'candles':[],'data_health':'NO_HISTORY'}
    rows=[]
    for idx,row in frame.tail(max(1,min(limit,500))).iterrows():
        rows.append({'time':idx.isoformat(),'open':float(row.open),'high':float(row.high),'low':float(row.low),'close':float(row.close),'volume':float(row.get('tick_volume',row.get('volume',0)))})
    return {'symbol':symbol,'timeframe':timeframe,'candles':rows,'data_health':'CLOSED_CANDLES','source':'MT5'}

@app.get('/signals/history')
async def get_history(limit:int=100,x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token); return {'signals':signal_history(limit)}

@app.get('/public/signals/history')
async def public_history(limit:int=100):
    return {'signals':signal_history(limit)}

@app.get('/public/research/performance')
async def public_research():
    return research_metrics()

@app.get('/research/performance')
async def get_research(x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token); return research_metrics()


class BacktestInput(BaseModel):
    symbol:str; timeframe:str; strategy:str; spread_cost:float; train_fraction:float=0.6; max_holding_bars:int=48

@app.post('/research/backtest')
async def run_backtest(item:BacktestInput,x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token)
    if item.timeframe not in ('M15','M30','H1','H4'): raise HTTPException(status_code=400,detail='Unsupported timeframe')
    frame=market_frames.get(item.symbol,{}).get(item.timeframe)
    if frame is None or frame.empty: raise HTTPException(status_code=409,detail='No historical candle data currently loaded for this market/timeframe')
    try:
        return await asyncio.to_thread(walk_forward,frame,item.strategy,item.symbol,item.timeframe,item.spread_cost,item.train_fraction,item.max_holding_bars)
    except ValueError as exc: raise HTTPException(status_code=400,detail=str(exc))

@app.post('/public/research/backtest')
async def public_run_backtest(item:BacktestInput):
    if item.timeframe not in ('M15','M30','H1','H4'): raise HTTPException(status_code=400,detail='Unsupported timeframe')
    frame=market_frames.get(item.symbol,{}).get(item.timeframe)
    if frame is None or frame.empty: raise HTTPException(status_code=409,detail='No historical candle data currently loaded for this market/timeframe')
    try:
        return await asyncio.to_thread(walk_forward,frame,item.strategy,item.symbol,item.timeframe,item.spread_cost,item.train_fraction,item.max_holding_bars)
    except ValueError as exc: raise HTTPException(status_code=400,detail=str(exc))

class OutcomeInput(BaseModel):
    signal_id:int; outcome:str; realized_r:float|None=None; notes:str=''

@app.post('/journal/outcome')
async def journal_outcome(item:OutcomeInput,x_a227c_token:str|None=Header(default=None)):
    check_api_token(x_a227c_token)
    try: record_outcome(item.signal_id,item.outcome,item.realized_r,item.notes)
    except (ValueError,LookupError) as exc: raise HTTPException(status_code=400,detail=str(exc))
    return {'saved':True,'message':'Manual outcome recorded; this does not change past signals'}

@app.websocket('/ws')
async def ws(websocket:WebSocket):
    # Public stream is intentionally read-only: it exposes analysis/signals only and
    # never exposes provider credentials or execution endpoints. Admin/REST mutation
    # routes remain token protected. This allows the APK to auto-connect without a
    # secret embedded in the application package.
    public_stream=bool(cfg.get('security',{}).get('public_read_only_stream',True))
    token=_configured_token()
    if not public_stream and (not token or websocket.headers.get('x-a227c-token')!=token):
        await websocket.close(code=1008); return
    await websocket.accept(); clients.add(websocket); health_state['signal_stream']='RUNNING'
    try:
        await websocket.send_text(json.dumps({'type':'snapshot','data':{'providers':health_state,'signals':list(snapshots.values()),'ranking':rank_opportunities(snapshots)}},default=str))
        while True: await websocket.receive_text()
    except WebSocketDisconnect: clients.discard(websocket)
    except Exception: clients.discard(websocket)

async def news_loop():
    global news_events,news_updated,policy_rates,macro_updated
    if not cfg.get('news',{}).get('enabled'):
        health_state['news']='NOT_CONFIGURED'; return
    provider=TradingEconomicsCalendar(os.getenv('TRADING_ECONOMICS_API_KEY') or cfg['news'].get('tradingeconomics_api_key',''))
    while True:
        try:
            events=await asyncio.to_thread(provider.upcoming)
            news_events=events; news_updated=time.time(); health_state['news']='CONNECTED'
            try:
                mapping=cfg.get('news',{}).get('macro_indicators',{})
                # Validate configured labels against each country's live provider catalog before using them.
                catalogs={}
                for country in mapping:
                    await asyncio.sleep(0.21)
                    catalogs[country]=await asyncio.to_thread(provider.indicator_catalog,country)
                specs=[(country,detail['policy_rate'],country) for country,detail in mapping.items() if detail.get('policy_rate')] + [(country,detail['yield_10y'],country+' 10Y') for country,detail in mapping.items() if detail.get('yield_10y')]
                invalid=[f'{country}: {indicator}' for country,indicator,_ in specs if indicator not in catalogs.get(country,set())]
                if invalid: raise RuntimeError('Trading Economics indicator mapping not found in provider catalog: '+', '.join(invalid))
                rates=[]
                for country,indicator,_ in specs:
                    rates.append(await asyncio.to_thread(provider.latest_indicator,country,indicator))
                    await asyncio.sleep(0.21)  # provider documents a 5-requests/second general limit
                policy_rates={label:r for r,(_,_,label) in zip(rates,specs)}; macro_updated=time.time()
                health_state['macro']='CONNECTED' if all(k in policy_rates for k in ('United States','Japan','United States 10Y','Japan 10Y')) else 'MAPPING_INCOMPLETE'
            except Exception as macro_exc:
                health_state['macro']='UNAVAILABLE'; health_state['last_error']='MACRO: '+str(macro_exc)
            await broadcast({'type':'news_status','status':'CONNECTED','events_count':len(events),'macro_status':health_state['macro']})
        except Exception as exc:
            health_state['news']='ERROR'; health_state['last_error']='NEWS: '+str(exc)
        await asyncio.sleep(int(cfg['news'].get('refresh_seconds',300)))

async def mt5_loop():
    global mt5_adapter,last_bar_refresh
    settings=cfg.get('mt5',{})
    if not settings.get('enabled'): health_state['mt5']='DISABLED'; return
    mt5_adapter=MT5Adapter(settings.get('symbols',{})); frames={s:{} for s in settings.get('symbols',{})}; tick_cache={}
    while True:
        try:
            if not mt5_adapter.connected:
                await asyncio.to_thread(mt5_adapter.connect); health_state['mt5']='CONNECTED' if len(mt5_adapter.available_symbols)==len(settings.get('symbols',{})) else 'PARTIAL'; health_state['mt5_symbols']={'available':sorted(mt5_adapter.available_symbols),'unavailable':mt5_adapter.symbol_errors,'required':sorted(settings.get('symbols',{}))}
                last_bar_refresh=0
            now=time.time()
            if health_state.get('emergency_stop'):
                await asyncio.sleep(float(cfg['engine'].get('tick_poll_seconds',1))); continue
            if now-last_bar_refresh>=int(cfg['engine'].get('bar_refresh_seconds',15)):
                for internal,provider in settings['symbols'].items():
                    frames[internal]={tf:await asyncio.to_thread(mt5_adapter.bars,provider,tf,int(cfg['engine'].get('history_bars',600)),True) for tf in ('M15','M30','H1','H4')}
                    market_frames[internal]=frames[internal]
                last_bar_refresh=now
            for internal,provider in settings['symbols'].items():
                if provider not in mt5_adapter.available_symbols:
                    snap={'symbol':internal,'timestamp':datetime.now(timezone.utc).isoformat(),'direction':'WAIT','score':0,'quality':'SYMBOL UNAVAILABLE','data_health':'PROVIDER_SYMBOL_UNAVAILABLE','source':'MT5','reasons':[mt5_adapter.symbol_errors.get(provider,'Provider symbol is not selected in MT5')]}
                    snapshots[internal]=snap; await broadcast({'type':'market_update','data':snap,'providers':health_state,'ranking':rank_opportunities(snapshots)}); continue
                tick=await asyncio.to_thread(mt5_adapter.tick,provider)
                if not tick: continue
                tick['source']='MT5'; tick['internal_symbol']=internal; tick['received_at']=datetime.now(timezone.utc).isoformat()
                tick_age=(datetime.now(timezone.utc)-tick['time']).total_seconds()
                max_age=float(cfg['engine'].get('max_tick_age_seconds',5))
                spread=tick['ask']-tick['bid']
                valid=tick['bid']>0 and tick['ask']>=tick['bid'] and -2<=tick_age<=max_age and spread>=0
                if not valid:
                    snap={'symbol':internal,'timestamp':datetime.now(timezone.utc).isoformat(),'direction':'WAIT','score':0,'quality':'DATA WARNING','data_health':'STALE_OR_INVALID_TICK','source':'MT5','tick_age_seconds':round(tick_age,2),'reasons':['Tick failed price, spread or freshness validation']}
                else:
                    risk=_news_risk(internal)
                    ranges={internal:asian_range(frames[internal].get('M30')),'active_session':session_name(tick['time'])}
                    macro=_macro_for_symbol(internal)
                    if macro is not None: macro.update({'broker_swap_long':tick.get('swap_long') if tick.get('swap_mode_name')=='CURRENCY_DEPOSIT' else None,'broker_swap_short':tick.get('swap_short') if tick.get('swap_mode_name')=='CURRENCY_DEPOSIT' else None,'broker_swap_mode':tick.get('swap_mode_name')})
                    snap=analyze(internal,frames[internal],tick=_json_tick(tick),source='MT5 / Exness via MT5',news_risk=risk,news_events=_relevant_news(internal),session=ranges,macro=macro,correlations=correlation_snapshot(internal,frames),threshold=int(cfg['engine'].get('signal_score_threshold',75)),min_bars=int(cfg['engine'].get('minimum_bars',205)),max_spread_atr_fraction=float(cfg['engine'].get('max_spread_atr_fraction',0.05)))
                    snap['tick_age_seconds']=round(tick_age,2); snap['spread']=spread; snap['session']=session_name()
                    if internal=='USDJPY' and snap.get('strategies'):
                        for strategy in snap['strategies']:
                            if strategy.get('name')=='CARRY_CONTEXT': strategy['broker_swap_long']=tick.get('swap_long'); strategy['broker_swap_short']=tick.get('swap_short')
                if internal in frames and frames[internal].get('M15') is not None and not frames[internal]['M15'].empty:
                    snap['bar_timestamp']=frames[internal]['M15'].index[-1].isoformat()
                previous=snapshots.get(internal)
                if previous and previous.get('direction') in ('BUY','SELL') and snap.get('direction')=='WAIT' and snap.get('data_health')=='VALIDATED':
                    await broadcast({'type':'signal_invalidated','symbol':internal,'previous_direction':previous.get('direction'),'reason':snap.get('reasons',[]),'timestamp':snap.get('timestamp')})
                snapshots[internal]=snap
                snap['signal_id']=await asyncio.to_thread(save_signal,snap) if snap.get('bar_timestamp') else None
                await broadcast({'type':'market_update','data':snap,'providers':health_state,'ranking':rank_opportunities(snapshots)})
            await asyncio.sleep(float(cfg['engine'].get('tick_poll_seconds',1)))
        except asyncio.CancelledError: raise
        except Exception as exc:
            health_state['mt5']='ERROR'; health_state['last_error']='MT5: '+str(exc)
            try:
                if mt5_adapter: mt5_adapter.shutdown()
            except Exception: pass
            await asyncio.sleep(5)

async def deriv_loop():
    d=cfg.get('deriv',{})
    if not d.get('enabled'): health_state['deriv']='DISABLED'; return
    adapter=DerivAdapter(d['endpoint'],d.get('symbols',{}))
    async def on_tick(t):
        # Separate namespace: never merge Deriv symbols with MT5 market symbols.
        t['timestamp']=datetime.fromtimestamp(int(t['epoch']),timezone.utc).isoformat() if t.get('epoch') else None
        snapshots['DERIV:'+str(t['internal_symbol'])]={'symbol':t['internal_symbol'],'provider_symbol':t['provider_symbol'],'source':'DERIV','quote':t.get('quote'),'timestamp':t['timestamp'],'data_health':'LIVE_TICK_ONLY','direction':'WAIT','score':0,'reasons':['Deriv feed is isolated from the five MT5 strategy markets unless separately configured and validated']}
        await broadcast({'type':'deriv_tick','data':snapshots['DERIV:'+str(t['internal_symbol'])]})
    async def on_status(s): health_state['deriv']=s; await broadcast({'type':'provider_status','provider':'deriv','status':s})
    await adapter.run(on_tick,on_status)

@app.on_event('startup')
async def startup():
    validate_production_config()
    asyncio.create_task(mt5_loop()); asyncio.create_task(deriv_loop()); asyncio.create_task(news_loop())
